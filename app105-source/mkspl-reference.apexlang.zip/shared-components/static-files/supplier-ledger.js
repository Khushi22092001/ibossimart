(function(){
"use strict";
var D={},active="Overview",selectedSupplier="",supplierQuery="",scopeSeeded=false;
var tabs=["Overview","Full Ledger","Truck Chain","Rate & Quality","Landed Cost","Weight & Short","Payments","Pending & Advance","Advance Payment List","Exceptions","Data Update Status"];
function el(id){return document.getElementById(id)}
function n(v){v=Number(v);return isFinite(v)?v:0}
function e(v){return String(v==null?"":v).replace(/[&<>\"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;"}[c]})}
function fmt(v,d){return n(v).toLocaleString("en-IN",{minimumFractionDigits:d||0,maximumFractionDigits:d||0})}
function rs(v){return "₹"+n(v).toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2})}
function day(v){v=String(v||"");return v.length===8?v.slice(6)+"-"+v.slice(4,6)+"-"+v.slice(0,4):"—"}
function month(v){v=String(v||"");return v.length===6?["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][Number(v.slice(4))-1]+"-"+v.slice(2,4):"—"}
function sum(a,f){return (a||[]).reduce(function(s,x){return s+n(f?f(x):x)},0)}
function group(a,key){return (a||[]).reduce(function(o,x){var k=key(x);(o[k]||(o[k]=[])).push(x);return o},{})}
function pill(kind,label){return '<span class="sl-pill '+kind+'">'+e(label)+"</span>"}
function table(head,body){return '<div style="overflow:auto"><table class="sl-table"><thead><tr>'+head.map(function(x){return "<th>"+x+"</th>"}).join("")+"</tr></thead><tbody>"+(body.length?body.join(""):'<tr><td colspan="'+head.length+'" class="sl-empty">Selected filters ke liye ERP entry nahi mili.</td></tr>')+"</tbody></table></div>"}
function row(c){return "<tr>"+c.map(function(x){return "<td>"+x+"</td>"}).join("")+"</tr>"}
function card(title,body,desc){return '<section class="sl-card"><h2>'+e(title)+"</h2>"+(desc?'<p class="sl-note">'+desc+"</p>":"")+body+"</section>"}
function chosen(x){return !selectedSupplier||String(x.name||"")===selectedSupplier}
function bills(){return (D.bills||[]).filter(chosen)}
function grns(){return (D.grns||[]).filter(chosen)}
function payments(){return (D.payments||[]).filter(chosen)}
function stats(){
 var b=bills(),g=grns(),passed=sum(b,function(x){return x.passed}),paid=sum(b,function(x){return x.paid}),open=sum(b,function(x){return Math.max(0,n(x.passed)-n(x.paid))});
 return '<div class="sl-kpis">'+
  '<div class="sl-kpi"><span class="sl-card-label">Purchase bills</span><b>'+fmt(b.length)+'</b><i>'+fmt(sum(b,function(x){return x.qty}))+' Qty · '+rs(sum(b,function(x){return x.value}))+"</i></div>"+
  '<div class="sl-kpi amber"><span class="sl-card-label">Passed</span><b>'+rs(passed)+'</b><i>PB Pass source total</i></div>'+
  '<div class="sl-kpi '+(open?"warn":"good")+'"><span class="sl-card-label">Pass unpaid</span><b>'+rs(open)+'</b><i>PbPass paid amount basis</i></div>'+
  '<div class="sl-kpi good"><span class="sl-card-label">Payments</span><b>'+rs(sum(payments(),function(x){return x.amount}))+'</b><i>Direct payment vouchers</i></div>'+
  '<div class="sl-kpi"><span class="sl-card-label">GRN / vehicle</span><b>'+fmt(g.length)+'</b><i>'+fmt(new Set(g.map(function(x){return x.vehicle||x.grn})).size)+' vehicles</i></div>'+
  '<div class="sl-kpi '+(sum(g,function(x){return x.reject})?"warn":"good")+'"><span class="sl-card-label">Rejected qty</span><b>'+fmt(sum(g,function(x){return x.reject}),2)+'</b><i>GRN rejected quantity</i></div></div>'
}
function suppliers(allRows){
 var g=group(allRows||bills(),function(x){return x.party});
 return Object.keys(g).map(function(k){var a=g[k];return {code:k,name:a[0].name,bills:a.length,qty:sum(a,function(x){return x.qty}),value:sum(a,function(x){return x.value})}}).sort(function(a,b){return b.value-a.value})
}
function overview(){
 var s=suppliers(),m=Math.max.apply(null,s.map(function(x){return x.value}).concat([1])),b=bills().slice().sort(function(a,b){return n(b.dt)-n(a.dt)}).slice(0,12);
 var bars='<div class="sl-bars">'+s.slice(0,12).map(function(x){return '<div class="sl-bar-row"><b>'+e(x.name)+'</b><span class="sl-bar"><i style="width:'+Math.max(2,x.value/m*100)+'%"></i></span><strong>'+rs(x.value)+"</strong></div>"}).join("")+"</div>";
 var recent=table(["Bill date","Supplier","Bill","Qty","Value","Pass status"],b.map(function(x){var unpaid=Math.max(0,n(x.passed)-n(x.paid));var state=!n(x.passed)?pill("muted","Not passed"):unpaid?pill("warn","Passed / unpaid"):pill("good","Passed / settled");return row([day(x.dt),"<b>"+e(x.name)+"</b>",e(x.bill),fmt(x.qty),rs(x.value),state])}));
 return stats()+'<div class="sl-grid">'+card("Saari party · saari kharid",bars,"Supplier-wise PurchaseBill value in the selected ERP scope.")+card("Recent purchase bills",recent,"PurchaseBill and PbPass evidence; direct vouchers remain separately traceable.")+"</div>"
}
function ledger(){
 var b=bills().slice().sort(function(a,b){return n(b.dt)-n(a.dt)});
 return stats()+card("Full Ledger",table(["Date","Supplier","Bill","Purchase value","Passed","Paid on pass","Pass unpaid","Status"],b.map(function(x){var o=Math.max(0,n(x.passed)-n(x.paid));return row([day(x.dt),"<b>"+e(x.name)+"</b><small>"+e(x.party)+"</small>",e(x.bill),rs(x.value),rs(x.passed),rs(x.paid),rs(o),!n(x.passed)?pill("muted","Not passed"):o?pill("warn","Review"):pill("good","Settled on pass")])})),"Every row is a PurchaseBill. This pass status comes from PbPass; it does not allocate direct vouchers to individual bills.")
}
function truck(){
 var a=grns().slice().sort(function(a,b){return n(b.dt)-n(a.dt)}),b=bills(),paid=sum(b,function(x){return x.paid}),passed=sum(b,function(x){return x.passed}),vehicles=new Set(a.map(function(x){return x.vehicle||x.grn})).size;
 function mark(ok,known){return known===false?'<span class="sl-check na">—</span>':'<span class="sl-check '+(ok?'yes':'no')+'">'+(ok?'✓':'×')+'</span>'}
 var controls='<div class="sl-truck-filters"><label>DATE SE<input type="text" placeholder="dd-mm-yyyy" disabled></label><label>TAK<input type="text" placeholder="dd-mm-yyyy" disabled></label><label>PARTY<select disabled><option>'+(selectedSupplier?e(selectedSupplier):'sab party')+'</option></select></label><label>LOADING<select disabled><option>sab</option></select></label><label>CONDITION<select disabled><option>sab</option></select></label><label>KAGAZ<select disabled><option>sab</option></select></label><label>PAYMENT<select disabled><option>sab</option></select></label><label>FREIGHT<select disabled><option>sab</option></select></label></div>';
 var kpis='<div class="sl-truck-kpis"><div><span>GAADI</span><b>'+fmt(a.length)+'</b><i>'+fmt(vehicles)+' truck no.</i></div><div><span>MAAL</span><b>'+fmt(sum(a,function(x){return x.received}),2)+' <small>Qtl</small></b><i>is list ka</i></div><div class="bad"><span>PAYMENT BAAKI</span><b>'+rs(Math.max(0,passed-paid))+'</b><i>bill par</i></div><div class="amber"><span>WEIGHT SHORT</span><b>'+fmt(sum(a,function(x){return x.reject}),2)+' <small>Qtl</small></b><i>challan se kam</i></div><div class="amber"><span>KAGAZ ADHURE</span><b>'+fmt(a.filter(function(x){return !x.materialIn||!x.hasBill}).length)+'</b><i>inward / bill link</i></div></div>';
 var rows=a.map(function(x,idx){var settled=b.some(function(y){return y.name===x.name&&n(y.passed)>0&&n(y.paid)>=n(y.passed)});return '<tr class="sl-truck-row" data-sl-truck="'+idx+'"><td>'+day(x.dt)+'</td><td><b>'+e(x.name)+'</b></td><td><b>'+e(x.vehicle||'—')+'</b><small>'+e(x.grn||'')+'</small></td><td>'+mark(false,false)+'</td><td>'+mark(!!x.materialIn,true)+'</td><td>'+mark(true,true)+'</td><td>'+mark(false,false)+'</td><td>'+mark(!!x.hasBill,true)+'</td><td>'+mark(settled,true)+'</td><td class="sl-num">'+fmt(x.received,2)+' Qtl</td></tr>'});
 var body='<section class="sl-truck-card"><div class="sl-truck-title"><div><b>Saari gaadi · '+e((D.scope||{}).itemName||'selected items')+'</b><span>party chuniye to sirf uski gaadi · ERP me uplabdh evidence</span></div><strong>'+fmt(a.length)+'<small> GAADI</small></strong></div>'+kpis+controls+table(["Bill date","Party","Truck / GRN","PO","Inward","Kaanta / GRN","Quality","Bill","Paid","Quantity"],rows)+'</section>';
 return body;
}
function quality(){
 var q=(D.quality||[]).filter(chosen).slice().sort(function(a,b){return n(b.dt)-n(a.dt)}),b=bills(),rate=sum(b,function(x){return x.value})/Math.max(1,sum(b,function(x){return x.qty}));
 var rateCard='<div class="sl-stat"><div><span>Weighted bill rate</span><b>₹'+fmt(rate,2)+"</b></div><div><span>Lowest bill rate</span><b>₹"+fmt(Math.min.apply(null,b.map(function(x){return n(x.rate)}).concat([0])),2)+"</b></div><div><span>Highest bill rate</span><b>₹"+fmt(Math.max.apply(null,b.map(function(x){return n(x.rate)}).concat([0])),2)+"</b></div></div>";
 return stats()+'<div class="sl-grid">'+card("Rate trend",rateCard+table(["Date","Supplier","Bill","Qty","Rate"],b.slice().sort(function(a,b){return n(b.rate)-n(a.rate)}).slice(0,18).map(function(x){return row([day(x.dt),e(x.name),e(x.bill),fmt(x.qty),"₹"+fmt(x.rate,2)])})),"PurchaseBillDetail Rate and Amount only.")+card("Rate & Quality",table(["Test date","Supplier","QC sample","Quality parameter","Result"],q.map(function(x){return row([day(x.dt),e(x.name),e(x.sample),e(x.quality),e(x.value)])})),"Results appear only where QualityTest, QCSample and QualityTestDetail records match the selected scope.")+"</div>"
}
function landed(){
 var b=bills(),f=sum(D.postedFreight||[],function(x){return x.amount}),qty=sum(b,function(x){return x.qty}),value=sum(b,function(x){return x.value}),by=group(b,function(x){return x.mon});
 var rows=Object.keys(by).sort().map(function(k){var x=by[k],q=sum(x,function(r){return r.qty}),v=sum(x,function(r){return r.value}),ff=sum((D.postedFreight||[]).filter(function(r){return r.mon===k}),function(r){return r.amount});return row([month(k),rs(v),fmt(q),rs(ff),"₹"+fmt(q?(v+ff)/q:0,2)])});
 var head='<div class="sl-stat"><div><span>Purchase bill rate</span><b>₹'+fmt(qty?value/qty:0,2)+"</b></div><div><span>Posted GRN freight</span><b>"+rs(f)+"</b></div><div><span>ERP landed cost</span><b>₹"+fmt(qty?(value+f)/qty:0,2)+"</b></div></div>";
 return stats()+card("Landed cost evidence",head+table(["Month","Bill value","Bill qty","Posted GRN freight","Indicative landed / Qty"],rows),"Landed cost is PurchaseBill line value plus posted GRN FreightAmount. Freight is not allocated per supplier or bill unless the ERP stores that link.")
}
function shortage(){
 var a=grns();return stats()+card("Weight & Short / receipt controls",table(["GRN date","Supplier","Vehicle","GRN","Received","Rejected","Control"],a.map(function(x){return row([day(x.dt),e(x.name),e(x.vehicle||"—"),e(x.grn),fmt(x.received,2),fmt(x.reject,2),n(x.reject)>0?pill("bad","Rejected quantity"):pill("good","Accepted quantity")])})),"This verified receipt source provides received and rejected quantities. It does not invent a challan-versus-received shortage when the required comparable ERP values are unavailable.")
}
function payRows(title,advance){
 var a=payments().slice().sort(function(a,b){return n(b.dt)-n(a.dt)});return stats()+card(title,table(["Voucher date","Supplier","Voucher","Amount","Allocation status"],a.map(function(x){return row([day(x.dt),e(x.name),e(x.voucher),rs(x.amount),advance?pill("muted","Bill allocation not verified"):""])})),advance?"The voucher source confirms payment movement but no verified voucher-to-PurchaseBill allocation. This view does not call any payment an advance without source evidence.":"Payment vouchers use PAYMENT, CASHPAYMENT and BANKPAYMENT document types with a supplier account line.")
}
function pending(){
 var a=bills().filter(function(x){return !n(x.passed)||n(x.passed)>n(x.paid)}).sort(function(a,b){return Math.max(0,n(b.passed)-n(b.paid))-Math.max(0,n(a.passed)-n(a.paid))});
 return stats()+card("Pending & Advance",table(["Supplier","Bill","Bill value","Passed","Paid on pass","Open on pass","Meaning"],a.map(function(x){var o=Math.max(0,n(x.passed)-n(x.paid));return row(["<b>"+e(x.name)+"</b>",e(x.bill),rs(x.value),rs(x.passed),rs(x.paid),rs(o),!n(x.passed)?pill("muted","Not passed"):o?pill("warn","Pass has unpaid balance"):pill("good","Settled on pass")])})),"Open is PbPassAmount less PaidAmount. Direct voucher payments can be outside PbPass and therefore are not allocated to individual bills here.")
}
function exceptions(){
 var x=[];bills().forEach(function(b){if(!n(b.passed))x.push(["HIGH",b.dt,b.name,b.bill,b.value,"Purchase bill is not passed"])});grns().forEach(function(g){if(!g.hasBill)x.push(["MEDIUM",g.dt,g.name,g.grn,0,"Goods received without PurchaseBill-GRN link"]);if(n(g.reject)>0)x.push(["MEDIUM",g.dt,g.name,g.grn,0,"GRN has rejected quantity"])});
 return stats()+card("Exceptions & audit",table(["Severity","Date","Supplier","Document","Amount","Control finding"],x.map(function(r){return row([pill(r[0]==="HIGH"?"bad":"warn",r[0]),day(r[1]),e(r[2]),e(r[3]),rs(r[4]),e(r[5])])})),"Exceptions are calculated from the same selected-scope ERP records shown in the other tabs.")
}
function fresh(){
 var a=D.freshness||[];return stats()+card("Data Update Status",'<div class="sl-fresh">'+a.map(function(x){return '<div><span class="sl-card-label">'+e(x.source)+"</span><b>"+day(x.dt)+"</b><small>"+e(x.note)+"</small></div>"}).join("")+"</div>","Latest transaction date for each ERP source within the chosen period.")
}
function downloadRows(rows,name){var text=rows.map(function(r){return r.map(function(v){return '"'+String(v==null?"":v).replace(/"/g,'""')+'"'}).join(",")}).join("\r\n"),link=document.createElement("a");link.href=URL.createObjectURL(new Blob(["\ufeff"+text],{type:"text/csv;charset=utf-8"}));link.download=name;link.click();URL.revokeObjectURL(link.href)}
function supplierStatement(){var rows=[["SUPPLIER STATEMENT"],[selectedSupplier||(D.scope||{}).supplierName||"Saari party"],["Date","Document","Type","Quantity","Value","Passed","Paid"]];bills().forEach(function(x){rows.push([day(x.dt),x.bill,"Purchase Bill",x.qty,x.value,x.passed,x.paid])});payments().forEach(function(x){rows.push([day(x.dt),x.voucher,"Payment",0,-n(x.amount),0,x.amount])});downloadRows(rows,"Supplier-Statement-"+(selectedSupplier||"all-suppliers").replace(/[^a-z0-9]+/gi,"-")+".csv")}
function suppliersReport(){var rows=[["CHANA SUPPLIERS REPORT"],["Supplier","Bills","Quantity","Purchase value","Share %"]],a=suppliers(D.bills||[]),tot=sum(a,function(x){return x.value});a.forEach(function(x){rows.push([x.name,x.bills,x.qty,x.value,tot?x.value/tot*100:0])});downloadRows(rows,"Chana-Suppliers-Report.csv")}
function openTruck(i){var a=grns().slice().sort(function(a,b){return n(b.dt)-n(a.dt)}),x=a[i];if(!x)return;var q=(D.quality||[]).filter(function(z){return chosen(z)&&z.name===x.name}),old=el("slDetail");if(old)old.remove();var box=document.createElement("div");box.id="slDetail";box.className="sl-detail";box.innerHTML='<div class="sl-detail-box"><button type="button" data-sl-detail-close>×</button><header><span>TRUCK / RECEIPT DRILL</span><b>'+e(x.vehicle||x.grn||"Vehicle")+'</b><small>'+day(x.dt)+' · '+e(x.name)+'</small></header><div class="sl-detail-grid"><div><span>GRN</span><b>'+e(x.grn||"—")+'</b></div><div><span>Material In</span><b>'+e(x.materialIn||"—")+'</b></div><div><span>Received</span><b>'+fmt(x.received,2)+' Qtl</b></div><div><span>Rejected</span><b>'+fmt(x.reject,2)+' Qtl</b></div><div><span>Bill linked</span><b>'+(x.hasBill?"Yes":"No")+'</b></div><div><span>Supplier</span><b>'+e(x.name)+'</b></div></div><section><h3>Rate & quality evidence</h3>'+table(["Test date","Sample","Parameter","Result"],q.map(function(z){return row([day(z.dt),e(z.sample||"—"),e(z.quality),e(z.value)])}))+'</section></div>';document.body.appendChild(box)}
function report(){
 var a=suppliers(),t=sum(a,function(x){return x.value});return stats()+card("Suppliers Report",table(["#","Supplier","Bills","Qty","Purchase value","Share"],a.map(function(x,i){return row([i+1,"<b>"+e(x.name)+"</b><small>"+e(x.code)+"</small>",fmt(x.bills),fmt(x.qty),rs(x.value),fmt(t?x.value/t*100:0,1)+"%"])})),"Supplier-wise PurchaseBill summary. The CSV action downloads the current page’s exported source data.")
}
function pane(){
 if(active==="Full Ledger")return ledger();
 if(active==="Truck Chain")return truck();
 if(active==="Rate & Quality")return quality();
 if(active==="Landed Cost")return landed();
 if(active==="Weight & Short")return shortage();
 if(active==="Payments")return payRows("Payments",false);
 if(active==="Pending & Advance")return pending();
 if(active==="Advance Payment List")return payRows("Advance Payment List",true);
 if(active==="Exceptions")return exceptions();
 if(active==="Data Update Status")return fresh();
 return overview();
}
function download(){
 var a=[["Supplier Ledger — "+active],["Date","Supplier","Bill / GRN","Qty","Value","Passed","Paid"]];
 bills().forEach(function(x){a.push([day(x.dt),x.name,x.bill,x.qty,x.value,x.passed,x.paid])});
 var text=a.map(function(r){return r.map(function(v){return '"'+String(v==null?"":v).replace(/"/g,'""')+'"'}).join(",")}).join("\r\n");
 var link=document.createElement("a");link.href=URL.createObjectURL(new Blob([text],{type:"text/csv;charset=utf-8"}));link.download="supplier-ledger-"+active.toLowerCase().replace(/[^a-z0-9]+/g,"-")+".csv";link.click();URL.revokeObjectURL(link.href);
}
function supplierRail(){
 var all=suppliers(D.bills||[]),max=Math.max.apply(null,all.map(function(x){return x.qty}).concat([1])),q=supplierQuery.toLowerCase();
 var totalQty=sum(D.bills||[],function(x){return x.qty}),totalBills=(D.bills||[]).length;
 return '<aside class="sl-side"><div class="sl-side-title"><span>SUPPLIERS</span><b>'+fmt(all.length)+'</b></div><input class="sl-side-search" type="search" value="'+e(supplierQuery)+'" placeholder="Search supplier…"><button type="button" class="sl-supplier '+(!selectedSupplier?'is-on':'')+'" data-sl-supplier=""><em>ALL</em><span><b>Saari party · saari gaadi</b><small>'+fmt(totalBills)+' bill · '+fmt(totalQty,0)+' Qtl</small></span></button><div class="sl-side-list">'+all.filter(function(x){return !q||x.name.toLowerCase().indexOf(q)>=0}).map(function(x,i){var diff=totalQty?x.qty/totalQty*100:0;return '<button type="button" class="sl-supplier '+(selectedSupplier===x.name?'is-on':'')+'" data-sl-supplier="'+e(x.name)+'"><em class="'+(i%4===0?'good':i%4===1?'blue':'warn')+'">'+(diff>=10?fmt(diff,0):fmt(diff,1))+'%</em><span><b>'+e(x.name)+'</b><small>'+fmt(x.bills)+' bill · '+fmt(x.qty,0)+' Qtl · '+rs(x.value)+'</small></span><u style="width:'+Math.max(2,x.qty/max*100)+'%"></u></button>'}).join('')+'</div></aside>';
}
function ensureWorkspace(){
 var out=el("slPane"),nav=el("slTabs");if(!out||!nav)return;
 var layout=el("slWorkspace");
 if(!layout){layout=document.createElement("div");layout.id="slWorkspace";layout.className="sl-workspace";out.parentNode.insertBefore(layout,out);var side=document.createElement("div");side.id="slSideHost";layout.appendChild(side);var body=document.createElement("section");body.className="sl-work-body";layout.appendChild(body);body.appendChild(nav);body.appendChild(out);}
 el("slSideHost").innerHTML=supplierRail();
}
function render(){
 var data=el("slPayload");if(!data)return;try{D=JSON.parse(data.textContent||"{}")}catch(ignore){D={}}
 var s=D.scope||{},h=el("slTitle"),sub=el("slSubtitle"),nav=el("slTabs"),out=el("slPane");
 if(!scopeSeeded){scopeSeeded=true;if(s.supplierName&&s.supplierName!=="Saari party"&&(D.bills||[]).length)selectedSupplier=s.supplierName;else active="Truck Chain";}
 ensureWorkspace();
 if(h)h.textContent=selectedSupplier||s.supplierName||"Saari party · saari gaadi";
 if(sub)sub.textContent=(s.itemName||"All items")+" · bills, pass, GRN, quality, freight and payment evidence for the selected ERP scope.";
 if(nav){nav.innerHTML=tabs.map(function(x){return '<button type="button" class="sl-tab '+(x===active?"is-on":"")+'" data-sl-tab="'+e(x)+'">'+e(x)+"</button>"}).join("");nav.onclick=function(ev){var b=ev.target.closest("[data-sl-tab]");if(b){active=b.getAttribute("data-sl-tab");render()}}}
 if(out)out.innerHTML=pane();
}
document.addEventListener("click",function(ev){if(ev.target&&ev.target.id==="slExcel")download();if(ev.target&&ev.target.id==="slStatement")supplierStatement();if(ev.target&&ev.target.id==="slReport")suppliersReport();if(ev.target&&ev.target.closest&&ev.target.closest("[data-sl-detail-close]")){var d=el("slDetail");if(d)d.remove();return;}var t=ev.target&&ev.target.closest&&ev.target.closest("[data-sl-truck]");if(t){openTruck(+t.getAttribute("data-sl-truck"));return;}var b=ev.target&&ev.target.closest&&ev.target.closest("[data-sl-supplier]");if(b){selectedSupplier=b.getAttribute("data-sl-supplier")||"";active=selectedSupplier?"Overview":"Truck Chain";render()}});
document.addEventListener("input",function(ev){if(ev.target&&ev.target.classList.contains("sl-side-search")){supplierQuery=ev.target.value;var pos=ev.target.selectionStart;ensureWorkspace();var input=document.querySelector(".sl-side-search");if(input){input.focus();input.setSelectionRange(pos,pos)}}});
if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",render);else render();
})();

;(function(){
  function setupReferenceFilterDrawer(){
    var panel=document.getElementById("p735Filters");
    var opener=document.getElementById("slFiltersOpen");
    if(!panel||!opener||panel.classList.contains("ref-filter-drawer"))return;
    panel.classList.add("ref-filter-drawer");
    panel.setAttribute("aria-hidden","true");
    panel.insertAdjacentHTML("afterbegin",'<div class="ref-filter-head"><div><span>LIVE ERP SCOPE</span><b>Supplier Ledger Filters</b></div><button type="button" class="ref-filter-close" aria-label="Close filters">×</button></div>');
    var scrim=document.createElement("div");
    scrim.className="ref-filter-scrim";
    document.body.appendChild(scrim);
    function setOpen(on){
      panel.classList.toggle("is-open",on);
      scrim.classList.toggle("is-open",on);
      document.body.classList.toggle("ref-filter-open",on);
      panel.setAttribute("aria-hidden",String(!on));
      opener.setAttribute("aria-expanded",String(on));
      if(on){var focusable=panel.querySelector("select,input,button,a");if(focusable)window.setTimeout(function(){focusable.focus();},80);}
      else opener.focus();
    }
    opener.addEventListener("click",function(){setOpen(!panel.classList.contains("is-open"));});
    scrim.addEventListener("click",function(){setOpen(false);});
    panel.querySelector(".ref-filter-close").addEventListener("click",function(){setOpen(false);});
    var financialYear=document.getElementById("P735_FINYEAR");
    if(financialYear)financialYear.addEventListener("change",function(){
      var range=String(financialYear.value||"").split("|");
      if(range.length===2&&window.apex){apex.item("P735_FROMDATE").setValue(range[0]);apex.item("P735_TODATE").setValue(range[1]);}
    });
    document.addEventListener("keydown",function(event){
      if(event.key==="Escape"&&panel.classList.contains("is-open")){
        event.preventDefault();
        event.stopImmediatePropagation();
        setOpen(false);
      }
    },true);
  }
  if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",setupReferenceFilterDrawer);else setupReferenceFilterDrawer();
})();

