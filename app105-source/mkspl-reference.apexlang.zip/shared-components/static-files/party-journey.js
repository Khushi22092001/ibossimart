apex.jQuery(function () {
window.pksRealData = function () {
  function read(id) {
    var el = document.getElementById(id);
    if (!el) return [];
    try { return JSON.parse(el.textContent || "[]"); }
    catch (e) { console.error("Party Journey data", id, e); return []; }
  }
  var invoices = read("pksDataInvoices");
  var orders = read("pksDataOrders");
  var master = read("pksDataMaster");
  var byName = {};
  master.forEach(function (p) { byName[p.party] = p; });
  var demand = orders.map(function (o) {
    var p = byName[o.party] || {};
    return {dt:o.dt,item:o.item,party:o.party,broker:o.broker,state:p.state||"",city:p.city||"",qty:o.qty,rate:o.rate,why:""};
  });
  return {
    invoices: invoices,
    orders: orders,
    receipts: read("pksDataReceipts"),
    notes: read("pksDataNotes"),
    stock: read("pksDataSupply"),
    master: master,
    demand: demand,
    audit: []
  };
};
var pksFinancialYear = document.getElementById("P731_FINYEAR");
if (pksFinancialYear) {
  pksFinancialYear.addEventListener("change", function () {
    var parts = (this.value || "").split("|");
    if (parts.length === 2 && window.apex && apex.item) {
      apex.item("P731_FROMDATE").setValue(parts[0]);
      apex.item("P731_TODATE").setValue(parts[1]);
    }
  });
}
/* ============================================================
   PARTY KA SAFAR — engine
   Namespace: PKS  (BM FOODS ERP single-file convention)
   Asli data lagana ho to sirf PKS.DATA badliye (§1 ka dhaancha),
   baaki poora module waise hi chalega.
   ============================================================ */
var PKS = (function () {
  "use strict";

  /* ---------- 1. chhota deterministic rng (sirf demo data ke liye) ---------- */
  var _s = 20260911;
  function rnd() { _s = (_s * 1664525 + 1013904223) % 4294967296; return _s / 4294967296; }
  function ri(a, b) { return a + Math.floor(rnd() * (b - a + 1)); }
  function pick(a) { return a[Math.floor(rnd() * a.length)]; }

  /* ---------- 2. mahina helpers (yyyymm) ---------- */
  var MON_HI = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  function monLabel(m) { m = String(m); return MON_HI[+m.slice(4, 6) - 1] + " " + m.slice(2, 4); }
  function monAdd(m, n) {
    var y = Math.floor(m / 100), mm = m % 100 - 1 + n;
    y += Math.floor(mm / 12); mm = ((mm % 12) + 12) % 12;
    return y * 100 + mm + 1;
  }
  function monRange(a, b) { var out = [], c = a; while (c <= b) { out.push(c); c = monAdd(c, 1); } return out; }
  function monOf(dt) { return Math.floor(dt / 100); }           // yyyymmdd -> yyyymm
  function isApr(m) { return m % 100 === 4; }
  function fyOf(m) { var y = Math.floor(m / 100), mm = m % 100; return mm >= 4 ? y : y - 1; }

  /* ---------- 3. naam ka milaan (§1) ---------- */
  var DROP = { PVT:1, PRIVATE:1, LTD:1, LIMITED:1, LLP:1, COMPANY:1, AND:1, THE:1 };
  function clean(name) {
    if (!name) return "";
    var s = String(name).toUpperCase();
    s = s.replace(/\([^)]*\)/g, " ");          // bracket wala hissa
    s = s.replace(/[.,&\-/'"]/g, " ");          // chinh
    s = s.replace(/\s+/g, " ").trim();
    return s.split(" ").filter(function (w) { return w && !DROP[w]; }).join(" ");
  }

  /* ---------- 4. apni company (§9) ---------- */
  var INTERNAL_WORDS = ["MAA NARMADA","BM FOODS","BMF","AMBIKAH","APPL","JMD","GOYAL","KUDARGARHI",
    "MAA KUDARGARHI","RAJARAM FOOD","RAJA RAM FOOD","GOODLUCK SALES","FARMERS BRIDGE"];
  function isInternal(cleanName, masterFlag) {
    if (masterFlag === true) return true;        // Party Master ka nishaan sabse upar
    if (masterFlag === false) return false;
    for (var i = 0; i < INTERNAL_WORDS.length; i++) if (cleanName.indexOf(INTERNAL_WORDS[i]) >= 0) return true;
    return false;
  }

  /* ---------- 5. formatting ---------- */
  function nf(v, d) { if (!isFinite(v)) v = 0; return v.toLocaleString("en-IN", { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 }); }
  function qf(v) { return v ? nf(v, 0) : ""; }
  function rf(v) { if (!v) return ""; var a = Math.abs(v); if (a >= 10000000) return (v / 10000000).toFixed(2) + " Cr"; if (a >= 100000) return (v / 100000).toFixed(2) + " L"; return nf(v, 0); }
  function dcTag(v) { return v > 0 ? ' <span class="pks-dc">Dr</span>' : (v < 0 ? ' <span class="pks-dc">Cr</span>' : ""); }
  function dstr(d) { d = String(d); return d.slice(6, 8) + "-" + d.slice(4, 6) + "-" + d.slice(0, 4); }
  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]; }); }

  /* ============================================================
     6. DEMO DATA  —  asli register aane par is poore block ko
        hata kar PKS.DATA = { invoices, orders, receipts, notes,
        stock, master } set kar dijiye.
     ============================================================ */
  var ITEMS = ["CHANA DAL 70/30","BENGAL GRAM RAW","CHANA BESAN","CHANA DAL MOGAR","KABULI CHANA"];
  var STATES = { "RAIPUR":["492001","CHHATTISGARH"], "NAGPUR":["440018","MAHARASHTRA"], "INDORE":["452001","MADHYA PRADESH"],
    "KOLKATA":["700001","WEST BENGAL"], "DELHI":["110006","DELHI"], "JAIPUR":["302001","RAJASTHAN"],
    "HYDERABAD":["500001","TELANGANA"], "PATNA":["800001","BIHAR"], "RANCHI":["834001","JHARKHAND"],
    "AMBIKAPUR":["497001","CHHATTISGARH"], "BILASPUR":["495001","CHHATTISGARH"], "SURAT":["395003","GUJARAT"] };

  // [raw naam, broker, shehar, pattern]
  // pattern: chalu | nayi | dheemi | band | order_only | short | no_pay | stockless | item_mismatch | internal
  var PARTY_DEF = [
    ["WORLD LINK EXPORTS.", "LALIT PAREEK JI", "KOLKATA", "chalu"],
    ["WORLD LINK EXPORTS(LALIT PAREEK JI)", "LALIT PAREEK JI", "KOLKATA", "chalu"],
    ["SHREE BALAJI TRADING COMPANY", "R K AGRAWAL", "NAGPUR", "chalu"],
    ["MAHALAXMI DAL MILL PVT LTD", "R K AGRAWAL", "INDORE", "chalu"],
    ["ANNAPURNA FOODS & GRAINS", "SUNIL BAJAJ", "RAIPUR", "chalu"],
    ["JAI MATA DI TRADERS", "SUNIL BAJAJ", "BILASPUR", "chalu"],
    ["SRI VENKATESHWARA AGRO LLP", "P NARASIMHA", "HYDERABAD", "chalu"],
    ["RAMDEV PULSES PRIVATE LIMITED", "LALIT PAREEK JI", "JAIPUR", "nayi"],
    ["NAVKAR GRAINS", "MOHIT KHANDELWAL", "SURAT", "nayi"],
    ["EASTERN DAL UDYOG", "S BANERJEE", "PATNA", "nayi"],
    ["GANGA AGRO PRODUCTS", "R K AGRAWAL", "RANCHI", "dheemi"],
    ["SHIV SHAKTI TRADERS.", "SUNIL BAJAJ", "RAIPUR", "dheemi"],
    ["KRISHNA FOOD PRODUCTS LTD", "P NARASIMHA", "HYDERABAD", "dheemi"],
    ["BHARAT DAL MILL", "MOHIT KHANDELWAL", "INDORE", "band"],
    ["NEW AGE FOODS COMPANY", "S BANERJEE", "KOLKATA", "band"],
    ["SANKALP TRADERS & CO", "LALIT PAREEK JI", "DELHI", "band"],
    ["PARAS PULSES", "MOHIT KHANDELWAL", "JAIPUR", "band"],
    ["METRO GRAIN SUPPLIERS", "S BANERJEE", "DELHI", "order_only"],
    ["SAGAR AGRO INDUSTRIES", "P NARASIMHA", "NAGPUR", "order_only"],
    ["VISHNU DAL TRADERS", "R K AGRAWAL", "BILASPUR", "short"],
    ["OMKAR FOODS PVT. LTD.", "SUNIL BAJAJ", "RAIPUR", "short"],
    ["DEEPAK GRAIN STORE", "MOHIT KHANDELWAL", "PATNA", "stockless"],
    ["SUNRISE COMMODITIES", "S BANERJEE", "KOLKATA", "item_mismatch"],
    ["ADARSH DAL UDYOG", "P NARASIMHA", "INDORE", "no_pay"],
    ["MAHAVIR TRADING CO.", "LALIT PAREEK JI", "SURAT", "no_pay"],
    ["LAXMI NARAYAN AGRO", "SUNIL BAJAJ", "RANCHI", "no_pay"],
    ["BM FOODS & GRAINS PVT LTD", "—", "AMBIKAPUR", "internal"],
    ["JMD RICE MILL", "—", "AMBIKAPUR", "internal"],
    ["GOYAL RICE INDUSTRIES", "—", "AMBIKAPUR", "internal"],
    ["MAA KUDARGARHI AGRO", "—", "AMBIKAPUR", "internal"],
    ["GOODLUCK SALES CORPORATION", "—", "RAIPUR", "internal"]
  ];

  function buildDemo() {
    var MONTHS = monRange(202504, 202608);
    var last = MONTHS.length - 1;
    var invoices = [], orders = [], receipts = [], notes = [], stock = [], master = [];
    var invNo = 1, ordNo = 1;

    // stock sheet — har mahina har item
    MONTHS.forEach(function (m) {
      ITEMS.forEach(function (it) {
        var q = ri(1800, 11000);
        // jaan-boojh kar do mahine me CHANA BESAN ka production shoonya (stockless kaaran ke liye)
        if (it === "CHANA BESAN" && (m === 202511 || m === 202512)) q = 0;
        stock.push({ mon: m, item: it, qty: q });
      });
    });

    PARTY_DEF.forEach(function (p, idx) {
      var raw = p[0], broker = p[1], city = p[2], pat = p[3];
      var geo = STATES[city] || ["000000", "—"];
      master.push({ party: raw, broker: broker, internal: pat === "internal" ? true : null });

      var myItems = pat === "stockless" ? ["CHANA BESAN"]
                  : pat === "item_mismatch" ? ["CHANA DAL 70/30", "BENGAL GRAM RAW"]
                  : [pick(ITEMS), pick(ITEMS)];
      var months;
      if (pat === "nayi") months = MONTHS.slice(last - 2);
      else if (pat === "dheemi") months = MONTHS.slice(0, last - 1);
      else if (pat === "band") months = MONTHS.slice(0, last - ri(5, 8));
      else if (pat === "stockless") months = MONTHS.slice(0, last - 3);
      else months = MONTHS.slice(ri(0, 2));

      months.forEach(function (m) {
        if (pat === "chalu" && rnd() < 0.12) return;         // ek-aadh mahina chhoot jata hai
        if (pat === "internal" && rnd() < 0.3) return;
        var item = pick(myItems);
        var rate = ri(3900, 6400);
        var oq = ri(60, 900);
        orders.push({ ord: "SO/" + (fyOf(m) % 100) + "-" + ((fyOf(m) + 1) % 100) + "/" + String(ordNo++).padStart(4, "0"),
          dt: m * 100 + ri(1, 26), party: raw, broker: broker, item: item, qty: oq, rate: rate, amount: Math.round(oq * rate) });

        var ratio = 1;
        if (pat === "order_only") ratio = 0;
        else if (pat === "short" || pat === "stockless") ratio = (ri(25, 52) / 100);
        else if (pat === "item_mismatch") ratio = (ri(30, 55) / 100);
        else ratio = (ri(86, 104) / 100);
        var bq = Math.round(oq * ratio);
        if (bq <= 0) return;

        var billItem = (pat === "item_mismatch") ? "KABULI CHANA" : item;
        var brate = rate + ri(-90, 120);
        var amt = Math.round(bq * brate);
        // EX PLANT = bhaada grahak ka, bill me nahi. FOR = bhaada hamara, rate me chhupa hua.
        // Dono ka rate seedha jodna galat hai — isliye har bill par ye do khaane zaroori hain.
        var basis = rnd() < 0.82 ? "EX PLANT" : "FOR";
        var bhaada = basis === "FOR" ? ri(90, 420) : 0;
        invoices.push({ inv: "CC/" + (fyOf(m) % 100) + "-" + ((fyOf(m) + 1) % 100) + "/" + String(invNo++).padStart(4, "0"),
          dt: m * 100 + ri(2, 28), party: raw, item: billItem, qty: bq, rate: brate, total: amt,
          basis: basis, bhaada: bhaada,
          city: city, pincode: geo[0], state: geo[1] });

        // vasooli
        var payr = (pat === "no_pay") ? (ri(20, 48) / 100) : (ri(72, 100) / 100);
        var pay = Math.round(amt * payr);
        if (pay > 0) {
          var pm = rnd() < 0.65 ? m : monAdd(m, 1);
          if (pm <= MONTHS[last]) {
            receipts.push({ dt: pm * 100 + ri(3, 27), party: raw, amount: pay });
          }
        }
        // kaat
        var kism = pick(["CD","WEIGHT SHORTAGE","QUALITY CUT","TDS"]);
        var cut = Math.round(amt * (ri(3, 14) / 1000));
        if (cut > 0) notes.push({ dt: m * 100 + ri(5, 28), party: raw, kism: kism, amount: cut });
      });
    });

    /* ---- MAANG REGISTER ----
       Ye wo register hai jo abhi kisi ERP me nahi hai. Har din broker/sales jo maang bataye
       wo yahan darj hoti hai — chahe humne becha ho ya nahi. Isi se pata chalta hai ki
       "220 ki maang thi, humne 100 becha" wala 120 Qtl kahan gaya.
       Har line: tareekh, maal, party/broker, ilaaka, kitni maang, party kis rate par le rahi thi,
       aur agar nahi becha to kyun. */
    var demand = [];
    var WHY = ["Maal hi nahi tha", "Rate nahi bana", "Udhaari ki dikkat", "Gaadi nahi mili"];
    // mausam: chana/besan (sattu) garmi me chalta hai — Mar, Apr, May me maang oonchi
    var SEASON = { 3:1.9, 4:2.2, 5:1.7, 6:1.1, 7:0.8, 8:0.7, 9:0.8, 10:0.9, 11:1.0, 12:0.7, 1:0.8, 2:1.3 };
    MONTHS.forEach(function (m) {
      var mm = m % 100;
      ITEMS.forEach(function (it) {
        var seasonal = (it === "CHANA BESAN" || it === "CHANA DAL MOGAR") ? (SEASON[mm] || 1) : (0.9 + rnd() * 0.3);
        var lines = ri(3, 7);
        for (var i = 0; i < lines; i++) {
          var pd = PARTY_DEF[ri(0, PARTY_DEF.length - 1)];
          if (pd[3] === "internal") continue;
          var geo = STATES[pd[2]] || ["000000", "—"];
          var q = Math.round(ri(200, 1400) * seasonal);
          demand.push({
            dt: m * 100 + ri(1, 27), item: it, party: pd[0], broker: pd[1],
            state: geo[1], city: pd[2], qty: q,
            rate: ri(3800, 6400),
            why: rnd() < 0.45 ? WHY[ri(0, WHY.length - 1)] : ""
          });
        }
      });
    });

    // audit = ERP ka sanshodhan register (kisne, kab, kya badla). Asli system se aata hai;
    // demo me shuru me khaali rehta hai aur "Demo: rate badal kar dikhaiye" se bharta hai.
    return { invoices: invoices, orders: orders, receipts: receipts, notes: notes, stock: stock,
             master: master, demand: demand, audit: [] };
  }

  /* ============================================================
     7. AGGREGATION — ek hi jagah se (§12 ka doosra dhyan)
     ============================================================ */
  var IDX = null;   // { parties:{clean:{...}}, months:[], brokers:{}, stock:{} }

  function blankMon() { return { bq: 0, oq: 0, val: 0, oval: 0, pay: 0, cut: 0 }; }

  function buildIndex(D) {
    var P = {}, monSet = {}, stk = {};

    function party(raw) {
      var c = clean(raw);
      if (!P[c]) P[c] = { c: c, names: [], name: raw, broker: "", city: "", pin: "", state: "",
        m: {}, internal: null, oItems: {}, bItems: {} };
      var p = P[c];
      if (p.names.indexOf(raw) < 0) p.names.push(raw);
      if (String(raw).length > String(p.name).length) p.name = raw;   // sabse lamba poora naam
      return p;
    }
    function bucket(p, m) { monSet[m] = 1; if (!p.m[m]) p.m[m] = blankMon(); return p.m[m]; }

    (D.master || []).forEach(function (r) {
      var p = party(r.party);
      if (r.broker && r.broker !== "—") p.broker = r.broker;
      if (r.internal === true || r.internal === false) p.internal = r.internal;
    });
    (D.invoices || []).forEach(function (r) {
      var p = party(r.party), m = monOf(r.dt), b = bucket(p, m);
      b.bq += (+r.qty || 0); b.val += (+r.total || 0);
      p.bItems[r.item] = 1;
      if (!p.city && r.city) { p.city = r.city; p.pin = r.pincode || ""; p.state = r.state || ""; }
    });
    (D.orders || []).forEach(function (r) {
      var p = party(r.party), m = monOf(r.dt), b = bucket(p, m);
      b.oq += (+r.qty || 0); b.oval += (+r.amount || 0);
      p.oItems[r.item] = 1;
      if (!p.broker && r.broker && r.broker !== "—") p.broker = r.broker;
    });
    (D.receipts || []).forEach(function (r) {
      var p = party(r.party), m = monOf(r.dt); bucket(p, m).pay += (+r.amount || 0);
    });
    (D.notes || []).forEach(function (r) {
      var p = party(r.party), m = monOf(r.dt); bucket(p, m).cut += (+r.amount || 0);
    });
    (D.stock || []).forEach(function (r) { stk[r.mon + "|" + r.item] = (stk[r.mon + "|" + r.item] || 0) + (+r.qty || 0); });

    Object.keys(P).forEach(function (c) { P[c].internal = isInternal(c, P[c].internal); });

    var months = Object.keys(monSet).map(Number).sort(function (a, b) { return a - b; });
    IDX = { parties: P, months: months, stock: stk, raw: D };
    return IDX;
  }

  /* slice: chune hue samay ka jod */
  function sliceOf(p, months) {
    var t = blankMon(), lastAct = 0;
    months.forEach(function (m) {
      var b = p.m[m]; if (!b) return;
      t.bq += b.bq; t.oq += b.oq; t.val += b.val; t.oval += b.oval; t.pay += b.pay; t.cut += b.cut;
      if (b.bq > 0) lastAct = m;
    });
    t.last = lastAct;
    t.bakaya = t.val - t.pay - t.cut;
    t.exec = t.oq > 0 ? (t.bq / t.oq * 100) : (t.bq > 0 ? 100 : 0);
    t.payPct = t.val > 0 ? (t.pay / t.val * 100) : 0;
    return t;
  }

  /* gap = aakhri bikri se samay ke aakhir tak kitne mahine */
  function gapOf(p, months) {
    var end = months[months.length - 1], gap = 0, seen = false;
    for (var i = months.length - 1; i >= 0; i--) {
      var b = p.m[months[i]];
      if (b && b.bq > 0) { seen = true; break; }
      gap++;
    }
    return seen ? gap : 99;
  }

  /* pehli kharid kab hui (poore data me) */
  function firstSale(p) {
    var ks = Object.keys(p.m).map(Number).sort(function (a, b) { return a - b; });
    for (var i = 0; i < ks.length; i++) if (p.m[ks[i]].bq > 0) return ks[i];
    return 0;
  }

  /* ---------- 8. halat (§6) ---------- */
  var STATUS = {
    chalu:  { key:"chalu",  label:"Chalu hai",       color:"#1f6f6a", why:"pichhle mahine bhi maal gaya" },
    nayi:   { key:"nayi",   label:"Nayi party",      color:"#2f8f6b", why:"pehli kharid haal me hui" },
    dheemi: { key:"dheemi", label:"Dheemi pad gayi", color:"#c9a227", why:"2–3 mahine se kuch nahi" },
    band:   { key:"band",   label:"Band ho gayi",    color:"#a8422f", why:"4 mahine se zyada ho gaye" }
  };
  function statusOf(p, months) {
    var gap = gapOf(p, months), end = months[months.length - 1];
    var fs = firstSale(p);
    if (gap <= 1 && fs && monAdd(fs, 3) > end) return STATUS.nayi;
    if (gap <= 1) return STATUS.chalu;
    if (gap <= 3) return STATUS.dheemi;
    return STATUS.band;
  }

  /* ---------- 9. kaaran (§8) ---------- */
  var REASONS = [
    { id:1, text:"Order aaya, ek bhi bill nahi bana", color:"#a8422f", sev:5, doIt:"Order lene wale se poochhiye — sauda tuta, rate badla, ya order jhootha tha" },
    { id:2, text:"Order aaya par humne poora maal nahi bheja", color:"#b5703a", sev:4, doIt:"Galti hamari — despatch aur stock dekhiye" },
    { id:"2s", text:"Order aaya par us waqt plant me maal hi nahi tha", color:"#8a5a2b", sev:4, doIt:"Galti stock ki, despatch ki nahi — production planning dekhiye" },
    { id:"2i", text:"Order kuch aur maal ka tha, gaya kuch aur", color:"#8a5a2b", sev:4, doIt:"Item milaan kijiye — order aur bill ka maal alag hai" },
    { id:3, text:"Maal gaya par paisa poora nahi aaya", color:"#c9a227", sev:4, doIt:"Pehle vasooli, phir naya order" },
    { id:4, text:"Sab theek chala, phir bhi party ne lena band kiya", color:"#7a3f6d", sev:3, doIt:"Rate ya doosri mill ki wajah — khud baat kijiye" },
    { id:5, text:"Kaam dheema pad gaya", color:"#2c5f8a", sev:2, doIt:"Follow-up kijiye, rishta abhi tuta nahi" },
    { id:6, text:"Chal raha hai", color:"#1f6f6a", sev:0, doIt:"Kuch karne ki zaroorat nahi" }
  ];
  function R(id) { for (var i = 0; i < REASONS.length; i++) if (REASONS[i].id === id) return REASONS[i]; return REASONS[7]; }

  function reasonOf(p, months) {
    var t = sliceOf(p, months), gap = gapOf(p, months);
    var o = t.oq, b = t.bq, pay = t.pay, val = t.val;
    var ev = "";
    if (o > 0 && b === 0) { ev = "Order " + nf(o) + " Qtl · bill 0"; return { r: R(1), t: t, gap: gap, ev: ev }; }
    if (o > 0 && (b / o) < 0.60) {
      ev = "Order " + nf(o) + " Qtl me se gaya " + nf(b) + " Qtl (" + Math.round(b / o * 100) + "%)";
      // doosra daur — stock aur item
      var oi = Object.keys(p.oItems), bi = Object.keys(p.bItems);
      for (var i = 0; i < months.length; i++) {
        var bk = p.m[months[i]]; if (!bk || bk.oq <= 0) continue;
        if (bk.bq / bk.oq >= 0.6) continue;
        var dry = oi.filter(function (it) { return (IDX.stock[months[i] + "|" + it] || 0) === 0; });
        if (dry.length) return { r: R("2s"), t: t, gap: gap,
          ev: ev + " · " + monLabel(months[i]) + " me " + dry[0] + " ka production 0 tha" };
      }
      var same = bi.filter(function (it) { return oi.indexOf(it) >= 0; });
      if (bi.length && same.length === 0) return { r: R("2i"), t: t, gap: gap, ev: ev + " · order: " + oi.join(", ") + " · bill: " + bi.join(", ") };
      return { r: R(2), t: t, gap: gap, ev: ev };
    }
    if (val > 0 && (pay / val) < 0.60) {
      ev = "Bikri ₹" + rf(val) + " · vasooli ₹" + rf(pay) + " (" + Math.round(pay / val * 100) + "%)";
      return { r: R(3), t: t, gap: gap, ev: ev };
    }
    if (gap > 3 && t.exec >= 90) return { r: R(4), t: t, gap: gap, ev: "Execution " + Math.round(t.exec) + "% · " + gap + " mahine se bill nahi" };
    if (gap > 3) return { r: R(5), t: t, gap: gap, ev: gap + " mahine se bill nahi" };
    return { r: R(6), t: t, gap: gap, ev: "Aakhri bill " + (t.last ? monLabel(t.last) : "—") };
  }

  return { rnd:rnd, ri:ri, pick:pick, MON_HI:MON_HI, monLabel:monLabel, monAdd:monAdd, monRange:monRange,
    monOf:monOf, isApr:isApr, fyOf:fyOf, clean:clean, isInternal:isInternal, nf:nf, qf:qf, rf:rf,
    dcTag:dcTag, dstr:dstr, esc:esc, buildDemo:buildDemo, buildIndex:buildIndex, sliceOf:sliceOf,
    gapOf:gapOf, firstSale:firstSale, statusOf:statusOf, STATUS:STATUS, REASONS:REASONS, reasonOf:reasonOf,
    idx: function () { return IDX; } };
})();

/* ============================================================
   PARTY KA SAFAR — screen (UI)
   ============================================================ */
(function () {
  "use strict";
  var E = PKS.esc, nf = PKS.nf, qf = PKS.qf, rf = PKS.rf, ml = PKS.monLabel;

  var TABS = [
    { k: "safar",  t: "Party ka safar" },
    { k: "chhoot", t: "Kaun chhoot raha" },
    { k: "broker", t: "Broker ka safar" },
    { k: "apni",   t: "Apni company" },
    { k: "kyun",   t: "Rishta kyun bigda" },
    { k: "md",     t: "Ek nazar me" },
    { k: "bazaar", t: "Bazaar ka naksha" },
    { k: "maang",  t: "Maang aur maal" },
    { k: "ishaare", t: "Ishaare" },
    { k: "roz",    t: "Roz ka kaam" },
    { k: "chaal",  t: "Rate ki chaal" },
    { k: "khabar", t: "Bazaar ki khabar" }
  ];

  var FAM = { teal: [31,111,106], blue: [44,95,138], gold: [201,162,39], red: [168,66,47], green: [47,143,107] };

  var VIEWS = [
    { k:"inv",  t:"Bikri (invoice)", unit:"Qtl", fam:"teal",  get:function(b){return b.bq;},  fmt:qf },
    { k:"so",   t:"Sales Order",     unit:"Qtl", fam:"blue",  get:function(b){return b.oq;},  fmt:qf },
    { k:"ovi",  t:"Order vs Bikri",  unit:"%",   fam:"green", get:null,                       fmt:null },
    { k:"pay",  t:"Paisa aaya",      unit:"₹",   fam:"gold",  get:function(b){return b.pay;}, fmt:rf, money:true },
    { k:"cut",  t:"Kaat (CD)",       unit:"₹",   fam:"red",   get:function(b){return b.cut;}, fmt:rf, money:true },
    { k:"full", t:"Poora hisaab",    unit:"₹",   fam:"gold",  get:null,                       fmt:null, money:true }
  ];
  function V() { for (var i=0;i<VIEWS.length;i++) if (VIEWS[i].k===S.view) return VIEWS[i]; return VIEWS[0]; }

  var YEARS = [
    { k:"2025-26", a:202504, b:202603 },
    { k:"2026-27", a:202604, b:202703 },
    { k:"ALL",     a:0,      b:999999 }
  ];

  var S = { tab:"safar", view:"inv", year:"ALL", from:null, to:null, status:null, q:"", zoom:100, reason:null,
            dParty:null, dMon:null, dMode:"till", d1:null, d2:null };
  var IX = null, ALL = [];

  /* ---------- tareekh se chunav ----------
     Mahine wala chunav waise ka waisa hai. Tareekh lagate hi poora aankda un hi din ka ban
     jata hai — aadha mahina bhi. Mahine ke khaane tab bhi dikhte hain, par unme sirf chune
     hue din ka kaam hota hai. */
  function toISO(d) { d = String(d); return d.slice(0, 4) + "-" + d.slice(4, 6) + "-" + d.slice(6, 8); }
  function fromISO(s) { return s ? +String(s).replace(/-/g, "") : 0; }
  function dataSpan() {
    var lo = 0, hi = 0;
    ["invoices", "orders", "receipts", "notes"].forEach(function (k) {
      (PKS.DATA[k] || []).forEach(function (x) {
        if (!lo || x.dt < lo) lo = x.dt;
        if (x.dt > hi) hi = x.dt;
      });
    });
    return { lo: lo, hi: hi };
  }
  function rebuild() {
    var D = PKS.DATA;
    if (!S.d1 || !S.d2) { IX = PKS.buildIndex(D); return; }
    function cut(arr) { return (arr || []).filter(function (x) { return x.dt >= S.d1 && x.dt <= S.d2; }); }
    var m1 = Math.floor(S.d1 / 100), m2 = Math.floor(S.d2 / 100);
    IX = PKS.buildIndex({
      invoices: cut(D.invoices), orders: cut(D.orders), receipts: cut(D.receipts), notes: cut(D.notes),
      stock: (D.stock || []).filter(function (x) { return x.mon >= m1 && x.mon <= m2; }),
      demand: cut(D.demand), master: D.master, audit: D.audit
    });
  }

  function spanText() {
    var M = months();
    return S.d1 ? (PKS.dstr(S.d1) + " se " + PKS.dstr(S.d2) + " tak")
                : (ml(M[0]) + " se " + ml(M[M.length - 1]) + " tak");
  }

  /* ---------- samay ---------- */
  function months() {
    var a = S.from, b = S.to;
    if (!a || !b) { var y = YEARS.filter(function(x){return x.k===S.year;})[0]; a = y.a; b = y.b; }
    var out = ALL.filter(function (m) { return m >= a && m <= b; });
    return out.length ? out : ALL.slice();
  }

  /* ---------- rows ---------- */
  function baseParties(internal) {
    var P = IX.parties, out = [];
    Object.keys(P).forEach(function (c) { if (!!P[c].internal === !!internal) out.push(P[c]); });
    return out;
  }
  function rowsFor(tab) {
    var M = months(), out = [];
    if (tab === "broker") {
      var agg = {};
      baseParties(false).forEach(function (p) {
        var b = p.broker || "(broker nahi)";
        if (!agg[b]) agg[b] = { c:"B|"+b, name:b, broker:"", city:"", pin:"", state:"", m:{}, kids:[], isBroker:true, oItems:{}, bItems:{} };
        agg[b].kids.push(p);
        Object.keys(p.m).forEach(function (m) {
          if (!agg[b].m[m]) agg[b].m[m] = { bq:0, oq:0, val:0, oval:0, pay:0, cut:0 };
          var s = p.m[m], d = agg[b].m[m];
          d.bq+=s.bq; d.oq+=s.oq; d.val+=s.val; d.oval+=s.oval; d.pay+=s.pay; d.cut+=s.cut;
        });
        Object.keys(p.oItems).forEach(function(i){agg[b].oItems[i]=1;});
        Object.keys(p.bItems).forEach(function(i){agg[b].bItems[i]=1;});
      });
      out = Object.keys(agg).map(function (k) { return agg[k]; });
    } else if (tab === "apni") {
      out = baseParties(true);
    } else {
      out = baseParties(false);
    }
    out.forEach(function (p) { p._t = PKS.sliceOf(p, M); p._s = PKS.statusOf(p, M); });
    // sirf wahi party jinme chune samay me kuch hua ho
    out = out.filter(function (p) { var t=p._t; return t.bq||t.oq||t.pay||t.cut; });
    if (S.status) out = out.filter(function (p) { return p._s.key === S.status; });
    if (S.q) {
      var q = S.q.toUpperCase();
      out = out.filter(function (p) {
        return (p.name+" "+(p.broker||"")+" "+(p.city||"")+" "+(p.pin||"")+" "+(p.state||"")).toUpperCase().indexOf(q) >= 0;
      });
    }
    out.sort(function (a, b) { return (b._t.val||0) - (a._t.val||0) || (b._t.bq||0)-(a._t.bq||0); });
    return out;
  }

  /* ---------- cell value ---------- */
  function cellVal(b) {
    var v = V();
    if (!b) return 0;
    if (v.k === "ovi") return b.oq > 0 ? (b.bq / b.oq * 100) : 0;
    if (v.k === "full") return b.val - b.pay - b.cut;
    return v.get(b);
  }
  /* rang ki chamak aur do rangon ka farak — likhaayi padhne layak rahe */
  function _L(c) {
    var v = c.map(function (x) { x /= 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); });
    return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2];
  }
  function _ratio(f, b) { var x = _L(f), y = _L(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }

  function heat(v, max, fam) {
    if (!v || !max) return "";
    var a = 0.06 + 0.84 * Math.sqrt(Math.min(Math.abs(v) / max, 1));
    var c = FAM[fam];
    var dark = [Math.round(c[0] * 0.22), Math.round(c[1] * 0.22), Math.round(c[2] * 0.22)];
    // khaana kaagaz (#ffffff) par chadhta hai — pehle mila hua rang nikaalte hain, phir safed
    // aur gehre me se jo zyada saaf padhe wahi likhaayi banti hai. Beech ki gehraai par dono
    // dhundhle padte hain, to khaane ko thoda aur gehra kar dete hain jab tak saaf na ho jaye.
    var ink = "#ffffff";
    for (var i = 0; i < 8; i++) {
      var bg = [c[0] * a + 255 * (1 - a), c[1] * a + 255 * (1 - a), c[2] * a + 255 * (1 - a)];
      var rw = _ratio([255, 255, 255], bg), rd = _ratio(dark, bg);
      ink = rw > rd ? "#ffffff" : "rgb(" + dark[0] + "," + dark[1] + "," + dark[2] + ")";
      if (Math.max(rw, rd) >= 4.5 || a >= 0.95) break;
      a = Math.min(0.95, a + 0.025);
    }
    return "background:rgba(" + c[0] + "," + c[1] + "," + c[2] + "," + a.toFixed(3) + ");" +
           "color:" + ink + ";" + (a > 0.40 ? "font-weight:600;" : "");
  }
  function hexA(h, a) {
    var r = parseInt(h.slice(1,3),16), g = parseInt(h.slice(3,5),16), bl = parseInt(h.slice(5,7),16);
    return "rgba(" + r + "," + g + "," + bl + "," + a.toFixed(3) + ")";
  }
  /* Order vs Bikri ka rang: 90%+ hara, 60–90% sunehra, 60% se kam laal,
     bina order ki bikri neela */
  function oviBand(b) {
    var o = b.oq || 0, q = b.bq || 0;
    if (o <= 0 && q > 0) return { c:"#2c5f8a", pct:100, note:"bina order ke bill bana" };
    if (o > 0 && q <= 0) return { c:"#a8422f", pct:0, note:"order aaya, bill ek bhi nahi" };
    var e = o > 0 ? (q / o * 100) : 0, er = Math.round(e);
    return { c: er >= 90 ? "#1f6f6a" : er >= 60 ? "#c9a227" : "#a8422f",
             pct: Math.min(e, 100), note: er + "% nikla" };
  }
  /* Poora hisaab ka rang — paanch seedhi pattiyan. Lena baaki (Dr) sunehra, dena baaki (Cr)
     hara. Likhaayi har patti par gehri, isliye har aankda ek jaisa saaf padhta hai. */
  var FULL_DR = [["#fdf8ea","#4a3a08"],["#f4e9c8","#463607"],["#e9d69d","#403106"],["#dcc172","#3a2c05"],["#c9a63f","#332704"]];
  var FULL_CR = [["#f1f6f3","#123a31"],["#ddece5","#0f3529"],["#c3ded3","#0d2f25"],["#a4cbbc","#0b2920"],["#80b4a1","#08211a"]];
  function fullFill(bak, max) {
    if (!bak || !max) return "background:#ffffff;color:#3a4a5e;";
    var a = Math.sqrt(Math.min(Math.abs(bak) / max, 1));
    var i = a < 0.18 ? 0 : a < 0.38 ? 1 : a < 0.60 ? 2 : a < 0.80 ? 3 : 4;
    var s = (bak >= 0 ? FULL_DR : FULL_CR)[i];
    return "background:" + s[0] + ";color:" + s[1] + ";font-weight:600;";
  }
  function cellStyle(b, val, max, v) {
    if (v.k === "full") return fullFill(b ? (b.val - b.pay - b.cut) : 0, max);
    if (v.k !== "ovi") return heat(val, max, v.fam);
    if (!b || (!b.oq && !b.bq)) return "";
    var bd = oviBand(b), sz = Math.sqrt(Math.min(Math.max(b.oq, b.bq) / (max || 1), 1));
    return "background:" + hexA(bd.c, 0.06 + 0.17 * sz) + ";";
  }
  function cellHtml(b) {
    var v = V();
    if (!b) return '<span class="pks-cell empty">·</span>';
    if (v.k === "ovi") {
      if (!b.oq && !b.bq) return '<span class="empty">·</span>';
      var bd = oviBand(b);
      return '<span class="ov-o">' + (b.oq ? nf(b.oq) : "–") + '</span>' +
             '<span class="ov-b" style="color:' + bd.c + '">' + (b.bq ? nf(b.bq) : "–") + '</span>' +
             '<span class="ov-bar" title="' + bd.note + '"><i style="width:' + bd.pct.toFixed(0) + '%;background:' + bd.c + '"></i></span>';
    }
    if (v.k === "full") {
      var bak = b.val - b.pay - b.cut;
      if (!b.val && !b.pay && !b.cut) return '<span class="empty">·</span>';
      var base = b.val || (b.pay + b.cut), pw = base ? Math.min(100, b.pay / base * 100) : 0,
          kw = base ? Math.min(100 - pw, b.cut / base * 100) : 0;
      return '<span class="fh-b">' + rf(Math.abs(bak)) + '<i>' + (bak > 0 ? "Dr" : bak < 0 ? "Cr" : "") + '</i></span>' +
        '<span class="fh-bar" title="Bikri ₹' + rf(b.val) + ' · vasooli ₹' + rf(b.pay) + ' · kaat ₹' + rf(b.cut) + '">' +
        '<i class="p" style="width:' + pw.toFixed(1) + '%"></i><i class="k" style="width:' + kw.toFixed(1) + '%"></i></span>' +
        '<span class="fh-s">B ' + rf(b.val) + ' · aaya ' + Math.round(pw) + '%</span>';
    }
    var val = v.get(b);
    if (!val) return '<span class="empty">·</span>';
    return (v.money ? rf(val) : qf(val)) + (v.money ? PKS.dcTag(v.k === "cut" ? -val : val) : "");
  }

  /* ============================================================
     RENDER — sirnaam ke control
     ============================================================ */
  function paintBars() {
    document.getElementById("pksYear").innerHTML = YEARS.map(function (y) {
      return '<button data-y="' + y.k + '" class="' + (!S.from && S.year === y.k ? "on" : "") + '">' + y.k + '</button>';
    }).join("");
    document.getElementById("pksView").innerHTML = VIEWS.map(function (v) {
      return '<button data-v="' + v.k + '" class="' + (S.view === v.k ? "on" : "") + '">' + v.t + '</button>';
    }).join("");
    var M = months(), f = document.getElementById("pksFrom"), t = document.getElementById("pksTo");
    var opt = ALL.map(function (m) { return '<option value="' + m + '">' + ml(m) + '</option>'; }).join("");
    if (f.options.length !== ALL.length) { f.innerHTML = opt; t.innerHTML = opt; }
    f.value = M[0]; t.value = M[M.length - 1];
    document.getElementById("pksDtClear").hidden = !S.d1;
    document.body.classList.toggle("pks-bydate", !!S.d1);
    document.getElementById("pksScope").innerHTML = S.d1
      ? '<span class="pks-datenote">' + PKS.dstr(S.d1) + " se " + PKS.dstr(S.d2) + " tak</span> · tareekh se chuna hua"
      : ml(M[0]) + " se " + ml(M[M.length - 1]) + " tak · " + M.length + " mahine";
  }

  function paintTabs() {
    document.getElementById("pksTabs").innerHTML = TABS.map(function (x) {
      return '<button role="tab" class="pks-tab" data-tab="' + x.k + '" aria-selected="' + (S.tab === x.k) + '">' + x.t + '</button>';
    }).join("");
  }

  /* ---------- halat ke chaar dabbe ---------- */
  function paintBoxes() {
    var box = document.getElementById("pksBoxes");
    if (S.tab === "kyun" || S.tab === "chhoot" || S.tab === "md" || S.tab === "bazaar" || S.tab === "ishaare" || S.tab === "maang" || S.tab === "khabar" || S.tab === "chaal" || S.tab === "roz") { box.style.display = "none"; return; }
    box.style.display = "";
    var M = months(), list = rowsForBoxes(), agg = {};
    ["chalu","nayi","dheemi","band"].forEach(function (k) { agg[k] = { n:0, q:0, v:0 }; });
    list.forEach(function (p) { var s = p._s.key; agg[s].n++; agg[s].q += p._t.bq; agg[s].v += p._t.val; });
    box.innerHTML = ["chalu","nayi","dheemi","band"].map(function (k) {
      var st = PKS.STATUS[k], a = agg[k];
      return '<button class="pks-box ' + (S.status === k ? "on" : "") + '" data-st="' + k + '" style="border-left-color:' + st.color + '">' +
        '<h4 style="color:' + st.color + '">' + st.label + '</h4>' +
        '<div class="n pks-num">' + a.n + '</div>' +
        '<div class="m pks-num">' + nf(a.q) + ' Qtl · ₹' + rf(a.v) + '</div>' +
        '<div class="why">' + st.why + '</div></button>';
    }).join("");
  }
  function rowsForBoxes() {
    var M = months(), out = S.tab === "apni" ? baseParties(true) : baseParties(false);
    out.forEach(function (p) { p._t = PKS.sliceOf(p, M); p._s = PKS.statusOf(p, M); });
    return out.filter(function (p) { var t = p._t; return t.bq || t.oq || t.pay || t.cut; });
  }

  /* ---------- heatmap ---------- */
  function heatTable(rows, opts) {
    opts = opts || {};
    var M = months(), v = V();
    var max = 0;
    rows.forEach(function (p) {
      M.forEach(function (m) {
        var b = p.m[m], x;
        if (v.k === "ovi") x = b ? Math.max(b.oq || 0, b.bq || 0) : 0;
        else x = Math.abs(cellVal(b));
        if (x > max) max = x;
      });
    });

    var rings = 0;
    var h = ['<div class="pks-scroll" id="pksScrollBox"><table class="pks-t' + (v.k === "ovi" ? " pks-ovi" : v.k === "full" ? " pks-full" : "") + (RT.blink ? " pks-blink" : "") + '" id="pksTable" style="font-size:' + (12.5 * S.zoom / 100).toFixed(2) + 'px">'];
    h.push('<thead><tr>');
    h.push('<th class="pks-sticky1 l">#</th>');
    h.push('<th class="pks-sticky2 l">' + (opts.broker ? "BROKER" : "PARTY") + '<small>' + (opts.broker ? "kitni party neeche" : "neeche broker") + '</small></th>');
    if (!opts.broker) { h.push('<th class="l">HALAT</th><th class="l">THIKANA</th>'); }
    M.forEach(function (m) {
      h.push('<th class="' + (PKS.isApr(m) ? "pks-apr" : "") + '">' + ml(m) + '</th>');
    });
    h.push('<th class="pks-tot">TOTAL<small>' + v.unit + '</small></th></tr></thead><tbody>');

    rows.forEach(function (p, i) {
      h.push('<tr data-c="' + E(p.c) + '">');
      h.push('<td class="pks-sticky1 pks-num">' + (i + 1) + '</td>');
      h.push('<td class="pks-sticky2"><span class="pks-pname" data-open="' + E(p.c) + '">' + E(p.name) + '</span>' +
             '<span class="pks-pbrok">' + E(opts.broker ? (p.kids.length + " party") : (p.broker || "broker nahi")) + '</span></td>');
      if (!opts.broker) {
        h.push('<td><span class="pks-chip" style="background:' + p._s.color + '">' + p._s.label + '</span></td>');
        h.push('<td><span class="pks-thikana">' + E([p.city, p.pin, p.state].filter(Boolean).join(" · ") || "—") + '</span></td>');
      }
      M.forEach(function (m) {
        var b = p.m[m], val = cellVal(b);
        // Order vs Bikri me do haalat dhyan maangti hain: order aaya par bill nahi bana,
        // aur bill ban gaya par order tha hi nahi. Wahi khaane halki ring se chamakte hain.
        var ring = "";
        if (v.k === "ovi" && b && rings < 12) {
          if (b.oq > 0 && !b.bq) { ring = " pks-ring ring-red"; rings++; }
          else if (!b.oq && b.bq > 0) { ring = " pks-ring ring-blue"; rings++; }
        }
        h.push('<td class="pks-cell num ' + (PKS.isApr(m) ? "pks-apr" : "") + ring + '" style="' + cellStyle(b, val, max, v) + '" data-c="' + E(p.c) + '" data-m="' + m + '">' + cellHtml(b) + '</td>');
      });
      h.push('<td class="num pks-tot">' + totHtml(p._t) + '</td></tr>');
    });

    // footer jod
    var G = { bq:0, oq:0, val:0, oval:0, pay:0, cut:0 };
    rows.forEach(function (p) { ["bq","oq","val","oval","pay","cut"].forEach(function (k) { G[k] += p._t[k]; }); });
    h.push('</tbody><tfoot><tr class="pks-foot"><td class="pks-sticky1"></td><td class="pks-sticky2">KUL JOD · ' + rows.length + ' line</td>');
    if (!opts.broker) h.push('<td></td><td></td>');
    M.forEach(function (m) {
      var b = { bq:0, oq:0, val:0, oval:0, pay:0, cut:0 };
      rows.forEach(function (p) { var x = p.m[m]; if (x) { b.bq+=x.bq; b.oq+=x.oq; b.val+=x.val; b.pay+=x.pay; b.cut+=x.cut; } });
      h.push('<td class="num ' + (PKS.isApr(m) ? "pks-apr" : "") + '">' + cellHtml(b) + '</td>');
    });
    G.bakaya = G.val - G.pay - G.cut; G.exec = G.oq ? G.bq / G.oq * 100 : 0;
    h.push('<td class="num">' + totHtml(G) + '</td></tr></tfoot></table></div>');
    return h.join("");
  }
  function totHtml(t) {
    var v = V();
    if (v.k === "inv") return qf(t.bq);
    if (v.k === "so") return qf(t.oq);
    if (v.k === "ovi") {
      if (!t.oq && !t.bq) return "·";
      var bd = oviBand(t);
      return '<span class="ov-o">' + (t.oq ? nf(t.oq) : "–") + '</span>' +
             '<span class="ov-b" style="color:' + bd.c + '">' + (t.bq ? nf(t.bq) : "–") + '</span>' +
             '<span class="ov-bar" title="' + bd.note + '"><i style="width:' + bd.pct.toFixed(0) + '%;background:' + bd.c + '"></i></span>';
    }
    if (v.k === "pay") return rf(t.pay);
    if (v.k === "cut") return rf(t.cut);
    var bak = t.val - t.pay - t.cut;
    var base = t.val || (t.pay + t.cut), pw = base ? Math.min(100, t.pay / base * 100) : 0,
        kw = base ? Math.min(100 - pw, t.cut / base * 100) : 0;
    return '<span class="fh-b">' + rf(Math.abs(bak)) + '<i>' + (bak > 0 ? "Dr" : bak < 0 ? "Cr" : "") + '</i></span>' +
      '<span class="fh-bar"><i class="p" style="width:' + pw.toFixed(1) + '%"></i><i class="k" style="width:' + kw.toFixed(1) + '%"></i></span>' +
      '<span class="fh-s">B ' + rf(t.val) + ' · aaya ' + Math.round(pw) + '%</span>';
  }

  /* ---------- kaun chhoot raha ---------- */
  function panelsHtml() {
    var M = months(), list = rowsForBoxes(), by = { chalu:[], nayi:[], dheemi:[], band:[] };
    if (S.q) { var q = S.q.toUpperCase(); list = list.filter(function (p) { return (p.name+" "+(p.broker||"")+" "+(p.city||"")).toUpperCase().indexOf(q) >= 0; }); }
    list.forEach(function (p) { by[p._s.key].push(p); });
    Object.keys(by).forEach(function (k) { by[k].sort(function (a, b) { return b._t.val - a._t.val; }); });
    return '<div class="pks-panels">' + ["chalu","nayi","dheemi","band"].map(function (k) {
      var st = PKS.STATUS[k], arr = by[k];
      var q = arr.reduce(function (s, p) { return s + p._t.bq; }, 0), v = arr.reduce(function (s, p) { return s + p._t.val; }, 0);
      var rows = arr.length ? arr.map(function (p) {
        return '<tr><td><span class="pks-pname" data-open="' + E(p.c) + '">' + E(p.name) + '</span>' +
          '<span class="pks-pbrok">' + E(p.broker || "broker nahi") + ' · ' + E(p.city || "—") + '</span></td>' +
          '<td class="num">' + (p._t.last ? ml(p._t.last) : "—") + '</td>' +
          '<td class="num">' + qf(p._t.bq) + '</td><td class="num">₹' + rf(p._t.val) + '</td></tr>';
      }).join("") : '<tr><td colspan="4" class="pks-empty">Is kism ki koi party nahi</td></tr>';
      return '<div class="pks-panel"><h3 style="background:' + st.color + '">' + st.label +
        '<span>' + arr.length + ' party · ' + nf(q) + ' Qtl · ₹' + rf(v) + '</span></h3>' +
        '<div class="body"><table><tbody>' + rows + '</tbody></table></div></div>';
    }).join("") + '</div>';
  }

  /* ---------- rishta kyun bigda ---------- */
  function reasonsHtml() {
    var M = months(), list = baseParties(false), res = [];
    list.forEach(function (p) {
      p._t = PKS.sliceOf(p, M); p._s = PKS.statusOf(p, M);
      if (!(p._t.bq || p._t.oq || p._t.pay)) return;
      var r = PKS.reasonOf(p, M);
      res.push({ p: p, r: r.r, ev: r.ev, t: r.t, gap: r.gap });
    });
    var agg = {};
    res.forEach(function (x) {
      var k = String(x.r.id);
      if (!agg[k]) agg[k] = { r: x.r, n: 0, q: 0, v: 0 };
      agg[k].n++; agg[k].q += x.t.bq; agg[k].v += x.t.val;
    });
    var boxes = Object.keys(agg).map(function (k) { return agg[k]; })
      .sort(function (a, b) { return b.r.sev - a.r.sev || b.v - a.v; })
      .map(function (a) {
        return '<button class="pks-rbox ' + (String(S.reason) === String(a.r.id) ? "on" : "") + '" data-r="' + a.r.id + '" style="border-top-color:' + a.r.color + '">' +
          '<h4 style="color:' + a.r.color + '">' + a.r.text + '</h4>' +
          '<div class="n pks-num">' + a.n + ' <span style="font-size:12px;font-weight:400;color:var(--pks-mut)">party</span></div>' +
          '<div class="m pks-num">' + nf(a.q) + ' Qtl · ₹' + rf(a.v) + '</div></button>';
      }).join("");

    var show = res.slice();
    if (S.reason) show = show.filter(function (x) { return String(x.r.id) === String(S.reason); });
    if (S.q) { var q = S.q.toUpperCase(); show = show.filter(function (x) { return (x.p.name + " " + (x.p.broker || "") + " " + (x.p.city || "")).toUpperCase().indexOf(q) >= 0; }); }
    show.sort(function (a, b) { return b.r.sev - a.r.sev || b.t.val - a.t.val; });

    var rows = show.map(function (x, i) {
      return '<tr><td class="pks-sticky1 pks-num">' + (i + 1) + '</td>' +
        '<td class="pks-sticky2"><span class="pks-pname" data-open="' + E(x.p.c) + '">' + E(x.p.name) + '</span>' +
        '<span class="pks-pbrok">' + E(x.p.broker || "broker nahi") + ' · ' + E(x.p.city || "—") + '</span></td>' +
        '<td><span class="pks-chip" style="background:' + x.p._s.color + '">' + x.p._s.label + '</span></td>' +
        '<td><span class="pks-chip" style="background:' + x.r.color + '">' + E(x.r.text) + '</span></td>' +
        '<td style="white-space:normal;max-width:300px;font-size:11.5px;color:var(--pks-mut)">' + E(x.ev) + '</td>' +
        '<td class="num">' + qf(x.t.oq) + '</td><td class="num">' + qf(x.t.bq) + '</td>' +
        '<td class="num">' + (x.t.oq ? Math.round(x.t.exec) + "%" : "·") + '</td>' +
        '<td class="num">₹' + rf(x.t.val) + '</td><td class="num">₹' + rf(x.t.pay) + '</td>' +
        '<td class="num">' + (x.gap === 99 ? "—" : x.gap) + '</td>' +
        '<td><span class="pks-do">' + E(x.r.doIt) + '</span></td></tr>';
    }).join("");

    return '<div class="pks-reasons">' + boxes + '</div>' +
      '<div class="pks-scroll"><table class="pks-t" id="pksTable" style="font-size:' + (12.5 * S.zoom / 100).toFixed(2) + 'px">' +
      '<thead><tr><th class="pks-sticky1 l">#</th><th class="pks-sticky2 l">PARTY</th><th class="l">HALAT</th>' +
      '<th class="l">KAARAN</th><th class="l">SABOOT</th><th>ORDER Qtl</th><th>BIKRI Qtl</th><th>NIKLA</th>' +
      '<th>BIKRI ₹</th><th>PAISA ₹</th><th>GAP</th><th class="l">KYA KIJIYE</th></tr></thead><tbody>' +
      (rows || '<tr><td colspan="12" class="pks-empty">Koi line nahi mili</td></tr>') + '</tbody></table></div>';
  }

  /* ============================================================
     MAAL KA SAFAR — item-war heatmap (party table ke neeche)
     ============================================================ */
  var IM = { mode: "inv", sk: "tot", dir: -1 };   // mode: inv | so | both · sk: kis column par chhanta

  function itemAgg(internal) {
    var IX = PKS.idx(), M = months(), a = M[0], b = M[M.length - 1], map = {};
    function row(it) {
      if (!map[it]) map[it] = { item: it, m: {}, val: 0, bq: 0, oq: 0, buyers: {} };
      return map[it];
    }
    function bk(r, m) { if (!r.m[m]) r.m[m] = { bq: 0, oq: 0, val: 0 }; return r.m[m]; }
    function mine(raw) { var p = IX.parties[PKS.clean(raw)]; return p && (!!p.internal === !!internal) ? p : null; }

    (IX.raw.invoices || []).forEach(function (x) {
      var p = mine(x.party); if (!p) return;
      var m = PKS.monOf(x.dt); if (m < a || m > b) return;
      var r = row(x.item), c = bk(r, m);
      c.bq += (+x.qty || 0); c.val += (+x.total || 0);
      r.bq += (+x.qty || 0); r.val += (+x.total || 0);
      r.buyers[p.c] = (r.buyers[p.c] || 0) + (+x.qty || 0);
    });
    (IX.raw.orders || []).forEach(function (x) {
      var p = mine(x.party); if (!p) return;
      var m = PKS.monOf(x.dt); if (m < a || m > b) return;
      var r = row(x.item); bk(r, m).oq += (+x.qty || 0); r.oq += (+x.qty || 0);
    });

    var out = Object.keys(map).map(function (k) { return map[k]; });
    out.forEach(function (r) {
      var top = null;
      Object.keys(r.buyers).forEach(function (c) { if (!top || r.buyers[c] > r.buyers[top]) top = c; });
      r.top = top ? { name: (IX.parties[top] || {}).name || top, qty: r.buyers[top], c: top } : null;
      r.nBuyers = Object.keys(r.buyers).length;
    });
    out.sort(function (x, y) { return (y.bq || 0) - (x.bq || 0) || (y.oq || 0) - (x.oq || 0); });
    return out;
  }

  function imTotal(r) { return IM.mode === "so" ? (r.oq || 0) : (r.bq || 0); }
  function imMonths(r, M) {
    var n = 0;
    M.forEach(function (m) {
      var c = r.m[m]; if (!c) return;
      var v = IM.mode === "so" ? c.oq : c.bq;
      if (v > 0) n++;
    });
    return n;
  }
  function imSortVal(r, M) {
    var k = IM.sk;
    if (k === "item") return r.item;
    if (k === "mon") return imMonths(r, M);
    if (k === "val") return r.val || 0;
    if (k === "buyer") return r.top ? r.top.qty : 0;
    if (k.indexOf("m:") === 0) return imVal(r.m[+k.slice(2)]);
    return imTotal(r);
  }
  function imSort(rows, M) {
    var d = IM.dir;
    rows.sort(function (a, b) {
      var x = imSortVal(a, M), y = imSortVal(b, M);
      if (typeof x === "string") return x.localeCompare(y) * (d < 0 ? -1 : 1);
      return (y - x) * (d < 0 ? 1 : -1);
    });
    return rows;
  }
  function imTh(key, label, cls, sub) {
    var on = IM.sk === key;
    return '<th class="' + (cls || "") + ' pks-sortable' + (on ? " on" : "") + '" data-sk="' + key + '" title="is column par chhaantiye">' +
      label + (on ? '<span class="car">' + (IM.dir < 0 ? "▼" : "▲") + '</span>' : "") +
      (sub ? '<small>' + sub + '</small>' : "") + '</th>';
  }
  function imVal(c) {
    if (!c) return 0;
    if (IM.mode === "so") return c.oq;
    if (IM.mode === "both") return Math.max(c.oq || 0, c.bq || 0);
    return c.bq;
  }
  function imCell(c) {
    if (!c || (!c.bq && !c.oq)) return "";
    if (IM.mode === "both") {
      var bd = oviBand(c);
      return '<span class="ov-o">' + (c.oq ? nf(c.oq) : "–") + '</span>' +
             '<span class="ov-b" style="color:' + bd.c + '">' + (c.bq ? nf(c.bq) : "–") + '</span>' +
             '<span class="ov-bar" title="' + bd.note + '"><i style="width:' + bd.pct.toFixed(0) + '%;background:' + bd.c + '"></i></span>';
    }
    var v = imVal(c);
    return v ? nf(v) : "";
  }

  function itemTable(internal) {
    var M = months(), rows = imSort(itemAgg(internal), M), irings = 0;
    var max = 0;
    rows.forEach(function (r) { M.forEach(function (m) { var v = Math.abs(imVal(r.m[m])); if (v > max) max = v; }); });

    var modes = [
      { k: "inv",  t: "Sales Invoice", s: "jo maal bill ban kar gaya" },
      { k: "so",   t: "Sales Order",   s: "jo order mila tha" },
      { k: "both", t: "Dono ek saath", s: "upar order, neeche bill" }
    ];
    var h = ['<section class="pks-sec2"><div class="pks-shead"><div>' +
      '<h2>Maal ka safar</h2><p>Kaunsa maal kis mahine gaya — aur uska sabse bada khareedar</p>' +
      '<div class="pks-hint">Rang jitna <b>gehra</b> — us mahine utna maal · kisi bhi column ke sirnaam par click karke <b>▲▼</b> se table chalaiye</div></div>' +
      '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">' +
      '<span class="pks-seg two">' + modes.map(function (x) {
        return '<button data-im="' + x.k + '" class="' + (IM.mode === x.k ? "on" : "") + '">' + x.t + '<small>' + x.s + '</small></button>';
      }).join("") + '</span>' +
      '<button class="pks-btn" data-xls="pksItemTable">Excel me nikaaliye</button></div></div>'];

    h.push('<div class="pks-scroll"><table class="pks-t' + (IM.mode === "both" ? " pks-ovi" : "") + (RT.blink ? " pks-blink" : "") + '" id="pksItemTable" style="font-size:' + (12.5 * S.zoom / 100).toFixed(2) + 'px">');
    h.push('<thead><tr>' + imTh("item", "MAAL", "pks-sticky-m l", "neeche us maal ki rakam"));
    M.forEach(function (m) { h.push(imTh("m:" + m, ml(m), PKS.isApr(m) ? "pks-apr" : "")); });
    h.push(imTh("tot", "KUL QTL", "pks-tot") + imTh("mon", "MAHINE", "", "kitne mahine gaya") +
      imTh("val", "RAKAM", "") + imTh("buyer", "SABSE BADA KHAREEDAR", "l", "kitni party ne liya") +
      '</tr></thead><tbody>');

    rows.forEach(function (r) {
      h.push('<tr><td class="pks-sticky-m"><span class="pks-maal" data-item="' + E(r.item) + '">' + E(r.item) + '</span>' +
        '<span class="pks-maal-v">₹' + rf(r.val) + '</span></td>');
      M.forEach(function (m) {
        var c = r.m[m], v = Math.abs(imVal(c)), html = imCell(c);
        var stl = (IM.mode === "both") ? cellStyle(c, v, max, { k: "ovi" }) : heat(v, max, "teal");
        var ring = "";
        if (IM.mode === "both" && c && irings < 12) {
          if (c.oq > 0 && !c.bq) { ring = " pks-ring ring-red"; irings++; }
          else if (!c.oq && c.bq > 0) { ring = " pks-ring ring-blue"; irings++; }
        }
        h.push('<td class="pks-cell num ' + (PKS.isApr(m) ? "pks-apr " : "") + ring + " " + (html ? "" : "pks-void") +
          '" style="' + stl + '" data-item="' + E(r.item) + '" data-m="' + m + '">' + (html || "") + '</td>');
      });
      h.push('<td class="num pks-tot">' + nf(imTotal(r)) + '</td>');
      h.push('<td class="pks-mah">' + (imMonths(r, M) || "–") + '</td>');
      h.push('<td class="pks-rak">₹' + rf(r.val) + '</td>');
      h.push('<td><span class="pks-buyer">' + (r.top ? '<b>' + E(r.top.name) + '</b> · ' + nf(r.top.qty) + ' Qtl · ' + r.nBuyers + ' party' : "—") + '</span></td></tr>');
    });

    var G = { bq: 0, oq: 0, val: 0 };
    rows.forEach(function (r) { G.bq += r.bq; G.oq += r.oq; G.val += r.val; });
    h.push('</tbody><tfoot><tr class="pks-foot"><td class="pks-sticky-m">KUL JOD · ' + rows.length + ' maal</td>');
    M.forEach(function (m) {
      var c = { bq: 0, oq: 0, val: 0 };
      rows.forEach(function (r) { var x = r.m[m]; if (x) { c.bq += x.bq; c.oq += x.oq; c.val += x.val; } });
      h.push('<td class="num ' + (PKS.isApr(m) ? "pks-apr" : "") + '">' + imCell(c) + '</td>');
    });
    var gm = 0; rows.forEach(function (r) { var n = imMonths(r, M); if (n > gm) gm = n; });
    h.push('<td class="num">' + nf(IM.mode === "so" ? G.oq : G.bq) + '</td>' +
      '<td class="pks-mah">' + M.length + '</td><td class="pks-rak">₹' + rf(G.val) + '</td>' +
      '<td>' + rows.length + ' maal · sabse lamba safar ' + gm + ' mahine</td></tr></tfoot></table></div></section>');
    return h.join("");
  }

  /* ============================================================
     RATE KA HISAAB — ek hi maal, ek hi mahina, party-war rate
     ============================================================ */
  var RT = { mode: "maal", item: "__all__", sk: "avg", dir: -1, blink: true, snap: {}, amend: {}, snapRev: -1,
             open: {}, allOpen: false };
  var DATA_REV = 0;   // data badalne par badhta hai — tabhi "badal gaya" dobara naapa jata hai

  function rateData(internal) {
    var IX = PKS.idx(), M = months(), a = M[0], b = M[M.length - 1], rows = {},
        byParty = (RT.mode === "party"), dono = (RT.mode === "dono");
    (IX.raw.invoices || []).forEach(function (x) {
      var p = IX.parties[PKS.clean(x.party)];
      if (!p || (!!p.internal !== !!internal)) return;
      var m = PKS.monOf(x.dt); if (m < a || m > b) return;
      if (RT.item !== "__all__" && x.item !== RT.item) return;
      var q = +x.qty || 0, v = +x.total || 0; if (!q) return;
      var r = v / q;
      var key = byParty ? p.c : x.item, label = byParty ? p.name : x.item;
      var sk = byParty ? x.item : p.c, slabel = byParty ? x.item : p.name;
      var R = rows[key] || (rows[key] = { key:key, label:label, note: byParty ? (p.broker || "broker nahi") : "", m:{}, q:0, v:0, sub:{}, msub:{} });
      R.q += q; R.v += v;
      var RS = R.sub[sk] || (R.sub[sk] = { label:slabel, q:0, v:0 }); RS.q += q; RS.v += v;
      var RM = R.msub[m] || (R.msub[m] = { label: ml(m), q:0, v:0 }); RM.q += q; RM.v += v;
      var C = R.m[m] || (R.m[m] = { q:0, v:0, min:0, max:0, sub:{} });
      C.q += q; C.v += v;
      C.min = C.min ? Math.min(C.min, r) : r; C.max = Math.max(C.max, r);
      var CS = C.sub[sk] || (C.sub[sk] = { label:slabel, q:0, v:0, n:0 }); CS.q += q; CS.v += v; CS.n++;
      if (dono) {   // maal ke neeche har party ki apni line
        var K = R.kids || (R.kids = {});
        var kid = K[p.c] || (K[p.c] = { key: r_kid(key, p.c), label: p.name, note: p.broker || "broker nahi", m:{}, q:0, v:0, sub:{}, msub:{} });
        kid.q += q; kid.v += v;
        var KC = kid.m[m] || (kid.m[m] = { q:0, v:0, min:0, max:0, sub:{} }); KC.q += q; KC.v += v;
        var KM = kid.msub[m] || (kid.msub[m] = { label: ml(m), q:0, v:0 }); KM.q += q; KM.v += v;
      }
    });
    return Object.keys(rows).map(function (k) { return rows[k]; });
  }
  function r_kid(item, pc) { return item + "\u00a7" + pc; }
  function rate(o) { return o && o.q ? o.v / o.q : 0; }
  /* jab tulna karne ko ek hi cheez bache (jaise ek hi maal chuna ho), to mahine se tulna karte hain */
  function subMap(r) { return (Object.keys(r.sub).length > 1) ? r.sub : (r.msub || r.sub); }
  function subKind(r) { return (Object.keys(r.sub).length > 1) ? (RT.mode === "maal" ? "kis party ko" : "kis maal par") : "kis mahine"; }
  function bestWorst(map) {
    var hi = null, lo = null;
    Object.keys(map).forEach(function (k) {
      var r = rate(map[k]); if (!r) return;
      if (!hi || r > rate(map[hi])) hi = k;
      if (!lo || r < rate(map[lo])) lo = k;
    });
    return { hi: hi ? { k:hi, r:rate(map[hi]), label:map[hi].label } : null,
             lo: lo ? { k:lo, r:rate(map[lo]), label:map[lo].label } : null };
  }
  function rtSortVal(r, M) {
    var k = RT.sk, bw = bestWorst(subMap(r));
    if (k === "label") return r.label;
    if (k === "qty") return r.q;
    if (k === "hi") return bw.hi ? bw.hi.r : 0;
    if (k === "lo") return bw.lo ? bw.lo.r : 0;
    if (k === "sp") return (bw.hi && bw.lo) ? (bw.hi.r - bw.lo.r) : 0;
    if (k.indexOf("m:") === 0) return rate(r.m[+k.slice(2)]);
    return rate(r);
  }
  /* Rate ka rang — paanch seedhi pattiyan, dono taraf. Chatak rang ke bajaye report jaisa
     halka rang, aur likhaayi har khaane me gehri — isliye har aankda saaf padhta hai.
     Upar wala (behtar rate) thanda hara-slate, neeche wala (kam rate) garam matti-laal. */
  var RATE_UP = [["#eff4f2","#1d4239"],["#d9e7e1","#17392f"],["#bcd6cc","#12332a"],["#94bfb0","#0d2b23"]];
  var RATE_DN = [["#f8f1ee","#6b2f20"],["#f1e0d9","#62291b"],["#e6c8bc","#5a2417"],["#d6a998","#4f1f13"]];
  function rateFill(dev) {
    var a = Math.abs(dev);
    if (a < 1.5) return "background:#ffffff;color:#3a4a5e;";
    var i = a < 3 ? 0 : a < 6 ? 1 : a < 10 ? 2 : 3;
    var s = (dev >= 0 ? RATE_UP : RATE_DN)[i];
    return "background:" + s[0] + ";color:" + s[1] + ";font-weight:600;";
  }

  function rtTh(key, label, cls, sub) {
    var on = RT.sk === key;
    return '<th class="' + (cls || "") + ' pks-sortable' + (on ? " on" : "") + '" data-rk="' + key + '">' +
      label + (on ? '<span class="car">' + (RT.dir < 0 ? "▼" : "▲") + '</span>' : "") +
      (sub ? '<small>' + sub + '</small>' : "") + '</th>';
  }

  function rateTable(internal) {
    var M = months(), rows = rateData(internal);
    rows.sort(function (x, y) {
      var p = rtSortVal(x, M), q = rtSortVal(y, M), d = RT.dir;
      if (typeof p === "string") return p.localeCompare(q) * (d < 0 ? -1 : 1);
      return (q - p) * (d < 0 ? 1 : -1);
    });
    // ----- table banane se pehle ka hisaab -----
    // (a) mahine-dar-mahine badlaav — sirf sabse bade paanch khaane chamakte hain, warna
    //     aadha table timtimane lagta hai aur nazar kahin nahi tikti
    // (b) "badal gaya" ka milaan — sirf tab jab data naya aaya ho, taaki chhaantne ya
    //     chamak band karne se nishaan mit na jaye
    var fresh = (RT.snapRev !== DATA_REV);
    if (fresh) RT.amend = {};
    var moms = [], big = {};
    rows.forEach(function (r) {
      var pv = 0;
      M.forEach(function (m) {
        var cr = rate(r.m[m]); if (!cr) return;
        if (pv) moms.push({ k: r.key + "|" + m, a: Math.abs((cr - pv) / pv * 100) });
        pv = cr;
        var sk2 = RT.mode + "|" + r.key + "|" + m;
        if (fresh) {
          var old = RT.snap[sk2];
          if (old && Math.abs(cr - old) / old > 0.005) RT.amend[sk2] = old;
          RT.snap[sk2] = cr;
        } else if (RT.snap[sk2] === undefined) {
          RT.snap[sk2] = cr;   // naya mode ya nayi line — pehli baar ka aankda yaad rakh lete hain
        }
      });
    });
    if (fresh) RT.snapRev = DATA_REV;
    moms.sort(function (x, y) { return y.a - x.a; });
    moms.slice(0, 5).forEach(function (x) { if (x.a >= 5) big[x.k] = 1; });

    var IX = PKS.idx(), itemList = {};
    (IX.raw.invoices || []).forEach(function (x) { itemList[x.item] = 1; });

    var h = ['<section class="pks-sec2"><div class="pks-shead"><div>' +
      '<h2>Rate ka hisaab</h2><p>Ek hi maal, ek hi mahina — par kis party ko kya rate mila</p>' +
      '<div class="pks-hint">Khaane me <b>aausat rate ₹/Qtl</b>, neeche us maal ke apne aausat se <b>farak</b> · ' +
      'hara matlab behtar rate, laal matlab kam — rang ki paanch pattiyan (1.5% se kam par koi rang nahi, phir 3%, 6%, 10% par gehra) · <b>▲▼</b> pichhle mahine se badlaav · ' +
      '<b>sunehri lakeer aur chamak</b> matlab ye aankda pichhli baar se badal gaya hai · khaane par click kariye to party-war rate khulta hai</div></div>' +
      '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">' +
      '<span class="pks-seg two">' +
        '<button data-rt="maal" class="' + (RT.mode === "maal" ? "on" : "") + '">Maal ka rate<small>har maal ki line</small></button>' +
        '<button data-rt="party" class="' + (RT.mode === "party" ? "on" : "") + '">Party ka rate<small>har party ki line</small></button>' +
        '<button data-rt="dono" class="' + (RT.mode === "dono" ? "on" : "") + '">Dono ek saath<small>maal ke neeche party</small></button>' +
      '</span>' +
      (RT.mode === "dono" ? '<button class="pks-btn" data-rtall="1">' + (RT.allOpen ? "Sab band kijiye" : "Sab kholiye") + '</button>' : "") +
      '<select class="pks-sel" id="pksRtItem"><option value="__all__">Sab maal ek saath</option>' +
        Object.keys(itemList).sort().map(function (it) {
          return '<option value="' + E(it) + '"' + (RT.item === it ? " selected" : "") + '>' + E(it) + '</option>';
        }).join("") + '</select>' +
      '<button class="pks-btn ' + (RT.blink ? "solid" : "") + '" data-blink="1" title="badle hue khaane chamkein ya nahi">' +
        (RT.blink ? "Chamak chalu hai" : "Chamak band hai") + '</button>' +
      '<button class="pks-btn" data-rtdemo="1" title="demo ke liye kuch bill ka rate badal kar dikhata hai">Demo: rate badal kar dikhaiye</button>' +
      '<button class="pks-btn" data-xls="pksRateTable">Excel me nikaaliye</button></div></div>'];

    var anyAmend = Object.keys(RT.amend).some(function (k) { return k.indexOf(RT.mode + "|") === 0; });
    h.push('<div class="pks-scroll"><table class="pks-t' + (RT.blink ? " pks-blink" : "") +
      (anyAmend && RT.blink ? " pks-spot" : "") + '" id="pksRateTable" style="font-size:' + (12.5 * S.zoom / 100).toFixed(2) + 'px">');
    h.push('<thead><tr>' + rtTh("label", RT.mode === "party" ? "PARTY" : (RT.mode === "dono" ? "MAAL · uske neeche PARTY" : "MAAL"), "pks-sticky-m l",
      RT.mode === "party" ? "neeche broker" : (RT.mode === "dono" ? "naam par click — party khulti hai" : "sab party ka mila-jula rate")));
    M.forEach(function (m) { h.push(rtTh("m:" + m, ml(m), PKS.isApr(m) ? "pks-apr" : "")); });
    h.push(rtTh("qty", "KUL QTL", "") + rtTh("avg", "AAUSAT RATE", "pks-tot", "₹ per Qtl") +
      rtTh("hi", "SABSE OONCHA", "", rows.length ? subKind(rows[0]) : "") +
      rtTh("lo", "SABSE NEECHA", "", rows.length ? subKind(rows[0]) : "") +
      rtTh("sp", "FARAK", "", "ooncha − neecha") + '</tr></thead><tbody>');

    var dono = (RT.mode === "dono");
    if (dono) {
      if (RT.openAllNow) { rows.forEach(function (r) { RT.open[r.key] = 1; }); RT.openAllNow = false; }
      if (RT.openFirst && rows.length) { RT.open[rows[0].key] = 1; RT.openFirst = false; }
    }
    function line(r, kid, ref) {
      // ref = jis se tulna karni hai. Maal ki line apne saal-bhar ke aausat se, aur party ki
      // line us maal ke us mahine ke rate se — yahi asli sawaal hai.
      var avg = rate(r), bw = bestWorst(subMap(r));
      var open = !!RT.open[r.key];
      h.push('<tr class="' + (kid ? "pks-kid" : (dono ? "pks-grp" : "")) + '"><td class="pks-sticky-m">' +
        (dono && !kid
          ? '<span class="pks-maal grp-tog" data-grp="' + E(r.key) + '"><span class="car">' + (open ? "▾" : "▸") + '</span>' + E(r.label) +
            '<span class="grp-n">' + Object.keys(r.kids || {}).length + ' party</span></span>'
          : '<span class="pks-maal" data-rrow="' + E(r.key) + '">' + E(r.label) + '</span>') +
        (r.note ? '<span class="pks-maal-v" style="color:var(--pks-mut)">' + E(r.note) + '</span>' : '') + '</td>');
      var prevR = 0;
      M.forEach(function (m) {
        var c = r.m[m], cr = rate(c);
        if (!cr) { h.push('<td class="pks-cell num pks-void ' + (PKS.isApr(m) ? "pks-apr" : "") + '"></td>'); return; }
        var base = kid ? rate(ref.m[m]) : avg;
        var dev = base ? (cr - base) / base * 100 : 0;
        // pichhle mahine se badlaav
        var mom = prevR ? (cr - prevR) / prevR * 100 : 0;
        var ar = "", tip = (kid ? "Is party ko is mahine ₹" : "Is mahine ka aausat rate ₹") + nf(Math.round(cr)) +
          (kid ? " · is maal ka us mahine ka aausat ₹" + nf(Math.round(base)) : "");
        if (prevR) {
          tip += " · pichhle mahine ₹" + nf(Math.round(prevR)) + " (" + (mom >= 0 ? "+" : "−") + Math.abs(mom).toFixed(1) + "%)";
          if (Math.abs(mom) >= 1.5) ar = '<span class="rt-ar">' + (mom > 0 ? "▲" : "▼") + '</span>';
        }
        // pichhli baar ke aankde se milaan — badla ho to sunehri lakeer
        var was = RT.amend[RT.mode + "|" + r.key + "|" + m], amend = !!was;
        if (amend) tip += " · pehle ₹" + nf(Math.round(was)) + " tha, ab badal gaya";
        var cls = (PKS.isApr(m) ? "pks-apr " : "") +
          (amend ? "pks-ring ring-gold " : (big[r.key + "|" + m] ? "pks-ring ring-ink " : ""));
        h.push('<td class="pks-cell num ' + cls + '" style="' +
          rateFill(dev) + '" title="' + E(tip) + '" data-rrow="' + E(r.key) + '" data-rm="' + m + '">' +
          '<span class="rt-r">' + nf(Math.round(cr)) + ar + '</span>' +
          (amend ? '<span class="rt-was">' + nf(Math.round(was)) + '</span>' : "") +
          '<span class="rt-d">' + (dev >= 0 ? "+" : "−") + Math.abs(dev).toFixed(1) + '%</span></td>');
        prevR = cr;
      });
      h.push('<td class="num">' + nf(r.q) + '</td><td class="num pks-tot">₹' + nf(Math.round(avg)) + '</td>');
      h.push('<td class="pks-hi"><div class="pair"><span class="pks-who" title="' + (bw.hi ? E(bw.hi.label) : "") + '">' +
        (bw.hi ? E(bw.hi.label) : "—") + '</span><b>₹' + (bw.hi ? nf(Math.round(bw.hi.r)) : "—") + '</b></div></td>');
      h.push('<td class="pks-lo"><div class="pair"><span class="pks-who" title="' + (bw.lo ? E(bw.lo.label) : "") + '">' +
        (bw.lo ? E(bw.lo.label) : "—") + '</span><b>₹' + (bw.lo ? nf(Math.round(bw.lo.r)) : "—") + '</b></div></td>');
      h.push('<td class="pks-sp">₹' + ((bw.hi && bw.lo) ? nf(Math.round(bw.hi.r - bw.lo.r)) : "—") + '</td></tr>');
    }

    rows.forEach(function (r) {
      line(r, false, null);
      if (dono && RT.open[r.key]) {
        Object.keys(r.kids || {}).map(function (k) { return r.kids[k]; })
          .sort(function (x, y) { return rate(y) - rate(x); })
          .forEach(function (kid) { line(kid, true, r); });
      }
    });

    if (!rows.length) {
      h.push('<tr><td colspan="' + (M.length + 6) + '" class="pks-empty">Is chhaant me koi bikri nahi mili — upar se doosra maal ya doosra samay chuniye</td></tr>');
    }
    var GQ = 0, GV = 0;
    rows.forEach(function (r) { GQ += r.q; GV += r.v; });
    h.push('</tbody><tfoot><tr class="pks-foot"><td class="pks-sticky-m">KUL JOD · ' + rows.length + ' line</td>');
    M.forEach(function (m) {
      var q = 0, v = 0;
      rows.forEach(function (r) { var c = r.m[m]; if (c) { q += c.q; v += c.v; } });
      h.push('<td class="num ' + (PKS.isApr(m) ? "pks-apr" : "") + '">' + (q ? "₹" + nf(Math.round(v / q)) : "·") + '</td>');
    });
    h.push('<td class="num">' + nf(GQ) + '</td><td class="num">₹' + (GQ ? nf(Math.round(GV / GQ)) : "—") + '</td>' +
      '<td colspan="3" style="font-size:11px;color:#9db3d0">Kul bikri ₹' + rf(GV) + ' · sab maal ka mila-jula aausat rate</td></tr></tfoot></table></div></section>');
    return h.join("");
  }

  /* khaane par click — us mahine ka party-war (ya maal-war) rate */
  function rateDrill(key, mon, internal) {
    var rows = rateData(internal), r = null;
    rows.forEach(function (x) {
      if (String(x.key) === String(key)) r = x;
      if (x.kids) Object.keys(x.kids).forEach(function (k) { if (String(x.kids[k].key) === String(key)) r = x.kids[k]; });
    });
    if (!r) return;
    var M = months(), one = !!mon;
    var pool = one ? (r.m[mon] || { sub:{}, q:0, v:0 }) : { sub: subMap(r), q:r.q, v:r.v };
    var list = Object.keys(pool.sub).map(function (k) { return pool.sub[k]; })
      .sort(function (a, b) { return rate(b) - rate(a); });
    var avg = pool.q ? pool.v / pool.q : 0;
    var hi = list.length ? rate(list[0]) : 0, lo = list.length ? rate(list[list.length - 1]) : 0;
    var upside = Math.round((hi - avg) * pool.q);

    var head = '<div class="pks-kpis">' +
      '<div class="pks-kpi"><div class="k">Aausat rate</div><div class="v">₹' + nf(Math.round(avg)) + '</div></div>' +
      '<div class="pks-kpi"><div class="k">Sabse ooncha</div><div class="v" style="color:#1f6f6a">₹' + nf(Math.round(hi)) + '</div></div>' +
      '<div class="pks-kpi"><div class="k">Sabse neecha</div><div class="v" style="color:#a8422f">₹' + nf(Math.round(lo)) + '</div></div>' +
      '<div class="pks-kpi"><div class="k">Maal</div><div class="v">' + nf(pool.q) + ' Qtl</div></div></div>' +
      '<div class="pks-bigline"><div class="k">Agar ye poora maal sabse oonchi rate par jata to bikri itni zyada hoti</div>' +
      '<div class="v">₹' + nf(upside) + '</div>' +
      '<div class="k" style="margin-top:2px">₹' + nf(Math.round(hi)) + ' aur ₹' + nf(Math.round(avg)) + ' ka farak, ' + nf(pool.q) + ' Qtl par</div></div>';

    var body = '<div class="pks-sec"><h4>' + (one ? (RT.mode === "maal" ? "Kis party ko kya rate" : "Kis maal par kya rate")
      : (subKind(r) === "kis mahine" ? "Kis mahine kya rate" : (RT.mode === "maal" ? "Kis party ko kya rate" : "Kis maal par kya rate"))) + '</h4>' +
      '<table class="pks-d"><thead><tr><th class="l">' + (one ? (RT.mode === "maal" ? "Party" : "Maal") : (subKind(r) === "kis mahine" ? "Mahina" : (RT.mode === "maal" ? "Party" : "Maal"))) + '</th>' +
      '<th>Qty</th><th>Rate ₹</th><th>Aausat se farak</th><th>%</th><th>Rakam ₹</th><th>Hissa</th></tr></thead><tbody>' +
      (list.length ? list.map(function (x) {
        var rr = rate(x), d = rr - avg;
        return '<tr><td class="l">' + E(x.label) + '</td><td>' + nf(x.q) + '</td>' +
          '<td><b>' + nf(Math.round(rr)) + '</b></td>' +
          '<td style="color:' + (d >= 0 ? "#1f6f6a" : "#a8422f") + ';font-weight:600">' + (d >= 0 ? "+" : "−") + nf(Math.abs(Math.round(d))) + '</td>' +
          '<td style="color:' + (d >= 0 ? "#1f6f6a" : "#a8422f") + '">' + (avg ? ((d >= 0 ? "+" : "−") + Math.abs(d / avg * 100).toFixed(1) + "%") : "·") + '</td>' +
          '<td>' + nf(Math.round(x.v)) + '</td>' +
          '<td>' + (pool.q ? (x.q / pool.q * 100).toFixed(1) + "%" : "·") + '</td></tr>';
      }).join("") : '<tr><td colspan="7" class="l">Is mahine kuch nahi gaya</td></tr>') +
      '</tbody><tfoot><tr><td class="l">Jod / aausat</td><td>' + nf(pool.q) + '</td><td>' + nf(Math.round(avg)) + '</td>' +
      '<td></td><td></td><td>' + nf(Math.round(pool.v)) + '</td><td>100%</td></tr></tfoot></table></div>';

    var af = { a: one ? mon : M[0], b: one ? mon : M[M.length - 1] };
    var kidKey = String(r.key).split("\u00a7");          // "maal§party" — Dono ek saath wali line
    var label;
    if (kidKey.length === 2) { af.item = kidKey[0]; af.party = kidKey[1]; label = "Party ka rate · " + kidKey[0]; }
    else if (RT.mode === "party") { af.party = r.key; label = "Party ka rate"; }
    else { af.item = r.key; label = "Maal ka rate"; }
    if (RT.item !== "__all__") af.item = RT.item;
    var nAud = PKSD.auditList(af).length;
    PKSD.show(r.label, label + (r.note ? " · " + r.note : ""),
      one ? "Sirf " + ml(mon) : ml(M[0]) + " se " + ml(M[M.length - 1]) + " tak",
      [{ label: "Rate ka byora", html: head + body },
       { label: "Badlaav ka byora", cnt: nAud, html: PKSD.auditHtml(af) }]);
  }

  /* Demo — asli ERP me ye kaam refresh karta hai. Yahan kuch bill ka rate badal kar
     dikhate hain ki badla hua khaana kaise chamakta hai. */
  function demoAmend() {
    var M = months(), a = M[0], b = M[M.length - 1];
    var pool = (PKS.DATA.invoices || []).filter(function (x) { var m = PKS.monOf(x.dt); return m >= a && m <= b; });
    if (!pool.length) return;
    var users = ["SALES-01 (raipur)", "SALES-04 (ambikapur)", "ACCOUNTS-02", "ADMIN"];
    var why = ["Rate sanshodhan — sauda ke hisaab se", "Weight difference ke baad rate revise",
               "Bill dobara pass hua", "Broker ke saath rate settle hua", "Galat rate feed ho gaya tha, sudhara"];
    var now = new Date();
    PKS.DATA.audit = PKS.DATA.audit || [];
    for (var i = 0; i < 6 && pool.length; i++) {
      var x = pool[Math.floor(Math.random() * pool.length)];
      var wasRate = x.rate, wasAmt = x.total;
      var f = 1 + (Math.random() < 0.5 ? -1 : 1) * (0.05 + Math.random() * 0.07);
      x.rate = Math.round(x.rate * f);
      x.total = Math.round(x.qty * x.rate);
      PKS.DATA.audit.push({
        stamp: now.getTime() - i * 60000,
        when: now.toLocaleDateString("en-IN", { day:"2-digit", month:"short", year:"2-digit" }) + " · " +
              now.toLocaleTimeString("en-IN", { hour:"2-digit", minute:"2-digit" }),
        user: users[Math.floor(Math.random() * users.length)],
        doc: x.inv, docDt: x.dt, party: x.party, item: x.item,
        field: "Rate ₹/Qtl", was: wasRate, now: x.rate, qty: x.qty,
        wasAmt: wasAmt, nowAmt: x.total,
        reason: why[Math.floor(Math.random() * why.length)]
      });
    }
    IX = PKS.buildIndex(PKS.DATA);
    DATA_REV++;
    paint();
  }

  /* ============================================================
     MD KA PANNA — ek panne me poora dhandha, har baat rupaye me toli hui.
     Har aankda usi hisaab se aata hai jo baaki tab me chal raha hai (§12).
     ============================================================ */
  function mdHtml() {
    var IX = PKS.idx(), M = months(), a = M[0], b = M[M.length - 1];
    var P = baseParties(false);
    P.forEach(function (p) { p._t = PKS.sliceOf(p, M); p._s = PKS.statusOf(p, M); });
    var live = P.filter(function (p) { var t = p._t; return t.bq || t.oq || t.pay || t.cut; });

    var G = { q:0, val:0, pay:0, cut:0, oq:0, oval:0 };
    live.forEach(function (p) {
      G.q += p._t.bq; G.val += p._t.val; G.pay += p._t.pay; G.cut += p._t.cut;
      G.oq += p._t.oq; G.oval += p._t.oval;
    });
    var bakaya = G.val - G.pay - G.cut;
    var avgRate = G.q ? G.val / G.q : 0;

    /* ---- mahine ka jod (bar ke liye) aur pichhle mahine se tulna ---- */
    var mv = M.map(function (m) {
      var v = 0, pay = 0, q = 0;
      live.forEach(function (p) { var c = p.m[m]; if (c) { v += c.val; pay += c.pay; q += c.bq; } });
      return { m:m, v:v, pay:pay, q:q };
    });
    var withSale = mv.filter(function (x) { return x.v > 0; });
    var lastM = withSale[withSale.length - 1] || { v:0, q:0, m:b };
    var prevM = withSale[withSale.length - 2] || null;
    var momPct = (prevM && prevM.v) ? (lastM.v - prevM.v) / prevM.v * 100 : 0;

    /* ---- 1. rate ka risaav: har maal ke us mahine ke aausat se neeche gaya maal ---- */
    var im = {};
    (IX.raw.invoices || []).forEach(function (x) {
      var p = IX.parties[PKS.clean(x.party)]; if (!p || p.internal) return;
      var m = PKS.monOf(x.dt); if (m < a || m > b) return;
      var k = x.item + "|" + m, o = im[k] || (im[k] = { q:0, v:0 });
      o.q += +x.qty || 0; o.v += +x.total || 0;
    });
    var leak = 0, leakBy = {}, leakItem = {};
    (IX.raw.invoices || []).forEach(function (x) {
      var p = IX.parties[PKS.clean(x.party)]; if (!p || p.internal) return;
      var m = PKS.monOf(x.dt); if (m < a || m > b) return;
      var q = +x.qty || 0; if (!q) return;
      var o = im[x.item + "|" + m], mAvg = o && o.q ? o.v / o.q : 0;
      var r = (+x.total || 0) / q;
      if (mAvg && r < mAvg) {
        var d = (mAvg - r) * q;
        leak += d;
        leakBy[p.c] = (leakBy[p.c] || 0) + d;
        leakItem[x.item] = (leakItem[x.item] || 0) + d;
      }
    });
    var leakTop = Object.keys(leakBy).map(function (k) { return { c:k, n:(IX.parties[k] || {}).name || k, v:leakBy[k] }; })
      .sort(function (x, y) { return y.v - x.v; }).slice(0, 4);

    /* ---- 2. paisa atka hua ---- */
    var due = live.filter(function (p) { return (p._t.val - p._t.pay - p._t.cut) > 0; })
      .sort(function (x, y) { return (y._t.val - y._t.pay - y._t.cut) - (x._t.val - x._t.pay - x._t.cut); });
    var dueTop = due.slice(0, 4);

    /* ---- 3. badi party jo band ho gayi ---- */
    var lost = live.filter(function (p) { return p._s.key === "band" && p._t.val > 0; })
      .sort(function (x, y) { return y._t.val - x._t.val; }).slice(0, 4);
    var lostVal = live.filter(function (p) { return p._s.key === "band"; })
      .reduce(function (s, p) { return s + p._t.val; }, 0);

    /* ---- 4. order aaya, bill nahi bana ---- */
    var nob = live.filter(function (p) { return p._t.oq > 0 && !p._t.bq; })
      .sort(function (x, y) { return y._t.oval - x._t.oval; });
    var nobVal = nob.reduce(function (s, p) { return s + p._t.oval; }, 0);

    /* ---- 5. ek jagah par nirbharta ---- */
    var byVal = live.slice().sort(function (x, y) { return y._t.val - x._t.val; });
    var top5 = byVal.slice(0, 5).reduce(function (s, p) { return s + p._t.val; }, 0);
    var brokers = {};
    live.forEach(function (p) { var k = p.broker || "(broker nahi)"; brokers[k] = (brokers[k] || 0) + p._t.val; });
    var bTop = Object.keys(brokers).map(function (k) { return { n:k, v:brokers[k] }; })
      .sort(function (x, y) { return y.v - x.v; });

    /* ---- 6. sabse bada nuksan wala maal ---- */
    var itemTop = Object.keys(leakItem).map(function (k) { return { n:k, v:leakItem[k] }; })
      .sort(function (x, y) { return y.v - x.v; }).slice(0, 3);

    function row(name, sub, amt, c) {
      return '<div class="md-row"><span class="nm"' + (c ? ' data-open="' + E(c) + '"' : '') + '>' + E(name) +
        (sub ? '<small>' + E(sub) + '</small>' : '') + '</span><span class="amt">' + amt + '</span></div>';
    }
    function card(color, title, big, sub, rows, doIt) {
      return '<div class="md-card" style="--mdc:' + color + '"><h3>' + title + '</h3>' +
        '<div class="big">' + big + '</div><div class="sub">' + sub + '</div>' +
        rows + '<div class="md-do">' + doIt + '</div></div>';
    }

    /* ---- bar chart ---- */
    var maxV = Math.max.apply(null, mv.map(function (x) { return Math.max(x.v, x.pay); }).concat([1]));
    var bars = '<div class="md-bars">' + mv.map(function (x) {
      var h1 = Math.round(x.v / maxV * 116), h2 = Math.round(x.pay / maxV * 116);
      return '<div class="md-bar"><div class="pair">' +
        '<i class="b1" style="height:' + Math.max(h1, x.v ? 2 : 0) + 'px" title="Bikri ₹' + rf(x.v) + '"></i>' +
        '<i class="b2" style="height:' + Math.max(h2, x.pay ? 2 : 0) + 'px" title="Vasooli ₹' + rf(x.pay) + '"></i>' +
        '</div><span>' + ml(x.m).replace(" ", "\u00a0") + '</span></div>';
    }).join("") + '</div><div class="md-legend">Har mahine ki <i style="background:#1f6f6a"></i> bikri aur <i style="background:#c9a227"></i> vasooli</div>';

    var h = [];
    h.push('<p class="md-lead">' + spanText() + ' <b>' + live.length + ' party</b> ke saath <b>' +
      nf(G.q) + ' Qtl</b> ka kaam hua, kul <b>₹' + rf(G.val) + '</b>. Vasooli ₹' + rf(G.pay) +
      ', bakaya ₹' + rf(Math.abs(bakaya)) + (bakaya >= 0 ? " lena baaki" : " dena baaki") + '.</p>');

    h.push('<div class="md-kpis">' +
      '<div class="md-kpi"><div class="k">Kul bikri</div><div class="v">₹' + rf(G.val) + '</div>' +
      '<div class="s">' + nf(G.q) + ' Qtl · aausat rate ₹' + nf(Math.round(avgRate)) + '</div></div>' +
      '<div class="md-kpi"><div class="k">Vasooli</div><div class="v">₹' + rf(G.pay) + '</div>' +
      '<div class="s">' + (G.val ? Math.round(G.pay / G.val * 100) : 0) + '% paisa aa gaya</div></div>' +
      '<div class="md-kpi"><div class="k">Bakaya</div><div class="v" style="color:' + (bakaya > 0 ? "#a8422f" : "#1f6f6a") + '">₹' + rf(Math.abs(bakaya)) + '</div>' +
      '<div class="s">kaat ₹' + rf(G.cut) + ' ke baad</div></div>' +
      '<div class="md-kpi"><div class="k">' + ml(lastM.m) + ' ka kaam</div><div class="v">₹' + rf(lastM.v) + '</div>' +
      '<div class="s" style="color:' + (momPct >= 0 ? "#1f6f6a" : "#a8422f") + '">' +
      (prevM ? (momPct >= 0 ? "▲ " : "▼ ") + Math.abs(momPct).toFixed(1) + "% pichhle mahine se" : "tulna ke liye pichhla mahina nahi") +
      '</div></div></div>');

    h.push('<div class="md-cards">');

    h.push(card("#a8422f", "Rate ka risaav — sabse badi chhupi hui haani",
      "₹" + rf(leak),
      "Jo maal us mahine ke apne aausat rate se neeche gaya, uska jod. Ye nuksan kisi bahi me nahi dikhta, " +
      "par ye poora ka poora munafe me se jata hai." + (itemTop.length ? " Sabse zyada " + E(itemTop[0].n) + " me." : ""),
      leakTop.map(function (x) { return row(x.n, "aausat se neeche gaya maal", "₹" + rf(x.v), x.c); }).join(""),
      "In paanch party ka rate broker ke saath baithkar dobara tay kijiye — 1% rate sudhre to ₹" +
      rf(G.val * 0.01) + " seedha munafe me."));

    h.push(card("#c9a227", "Paisa jo bahar atka hai",
      "₹" + rf(Math.max(bakaya, 0)),
      due.length + " party par paisa baaki hai. Neeche wali " + Math.min(4, due.length) +
      " party par hi bakaye ka " +
      (bakaya > 0 ? Math.round(dueTop.reduce(function (s, p) { return s + (p._t.val - p._t.pay - p._t.cut); }, 0) / bakaya * 100) : 0) +
      "% hissa hai.",
      dueTop.map(function (p) {
        var d = p._t.val - p._t.pay - p._t.cut;
        return row(p.name, (p.broker || "broker nahi") + " · " + (p._t.val ? Math.round(p._t.pay / p._t.val * 100) : 0) + "% paisa aaya",
          "₹" + rf(d), p.c);
      }).join(""),
      "Pehle vasooli, phir naya order — khaas kar un party ka jinka paisa 60% se kam aaya hai."));

    h.push(card("#7a3f6d", "Badi party jo haath se nikal gayi",
      "₹" + rf(lostVal),
      "Itna kaam un party ka tha jo ab 4 mahine se zyada se kuch nahi le rahi. Ye purana kaam hai — " +
      "naya khareedar dhoondhne se saste me wapas aa sakta hai.",
      lost.map(function (p) {
        return row(p.name, (p.broker || "broker nahi") + " · aakhri bill " + (p._t.last ? ml(p._t.last) : "—"),
          "₹" + rf(p._t.val), p.c);
      }).join("") || '<div class="md-row"><span class="nm">Koi badi party nahi chhooti</span><span class="amt">—</span></div>',
      "In par khud ek phone — 'Rishta kyun bigda' tab me har ek ka kaaran aur saboot likha hai."));

    h.push(card("#2c5f8a", "Order aaya, par bill ek bhi nahi bana",
      "₹" + rf(nobVal),
      nob.length + " party ka order register me pada hai jiska ek bhi bill nahi bana. Ya sauda toota, " +
      "ya rate badla, ya order kabhi asli tha hi nahi — teenon me se kuch ek sach hai.",
      nob.slice(0, 4).map(function (p) {
        return row(p.name, (p.broker || "broker nahi") + " · " + nf(p._t.oq) + " Qtl ka order",
          "₹" + rf(p._t.oval), p.c);
      }).join("") || '<div class="md-row"><span class="nm">Aisa koi order nahi</span><span class="amt">—</span></div>',
      "Order lene wale se seedha poochhiye. Jhoote order register me rahenge to har aankda galat banta rahega."));

    h.push(card("#1f6f6a", "Kitna kaam kitne haathon me",
      (G.val ? Math.round(top5 / G.val * 100) : 0) + "%",
      "Itna kaam sirf paanch party ke paas hai. " +
      (bTop.length ? "Sabse bade broker " + E(bTop[0].n) + " ke neeche " +
        (G.val ? Math.round(bTop[0].v / G.val * 100) : 0) + "% kaam hai." : ""),
      byVal.slice(0, 4).map(function (p) {
        return row(p.name, (p.broker || "broker nahi"), (G.val ? (p._t.val / G.val * 100).toFixed(1) : 0) + "%", p.c);
      }).join(""),
      "Ek party ya ek broker par 25% se zyada nirbharta jokhim hai — wo rate bhi apni marzi ka manwata hai."));

    h.push('<div class="md-card" style="--mdc:#b5703a"><h3>Mahine dar mahine — bikri aur vasooli</h3>' +
      '<div class="sub">Sunehri patti hari se chhoti rahe to paisa peechhe chhoot raha hai.</div>' + bars + '</div>');

    h.push('</div>');
    return h.join("");
  }

  /* ============================================================
     BAZAAR KA NAKSHA — ilaaka × broker (ya maal), aur uske neeche party.
     Khaali khaana matlab us ilaake me us broker ka kaam hai hi nahi — mauka wahin hai.
     ============================================================ */
  var BZ = { area: "state", base: "broker", mon: null };

  function bzCol(k) { return (BZ.base === "mon") ? ml(+k) : k; }
  /* upar wala search bazaar me bhi chalta hai — ilaaka, broker, maal, party, shehar, pincode */
  function bzMatch(p, item, mon) {
    if (!S.q) return true;
    var q = S.q.toUpperCase();
    var hay = [bzLabel(p), p.name, p.broker, p.city, p.pin, p.state, item, ml(mon)].join(" ").toUpperCase();
    return hay.indexOf(q) >= 0;
  }
  function bzLabel(p) {
    if (BZ.area === "city") return p.city || "—";
    if (BZ.area === "pin") return p.pin || "—";
    return p.state || "—";
  }
  function bazaar() {
    var IX = PKS.idx(), M = months(), a = M[0], b = M[M.length - 1];
    var rows = {}, cols = {}, cell = {};
    (IX.raw.invoices || []).forEach(function (x) {
      var p = IX.parties[PKS.clean(x.party)]; if (!p || p.internal) return;
      var m = PKS.monOf(x.dt); if (m < a || m > b) return;
      if (BZ.mon && m !== BZ.mon) return;
      if (!bzMatch(p, x.item, m)) return;
      var q = +x.qty || 0, v = +x.total || 0;
      var ar = bzLabel(p),
          co = (BZ.base === "broker") ? (p.broker || "(broker nahi)")
             : (BZ.base === "mon") ? String(m) : x.item;
      var R = rows[ar] || (rows[ar] = { k:ar, q:0, v:0, parties:{}, cols:{} });
      R.q += q; R.v += v; R.parties[p.c] = 1; R.cols[co] = (R.cols[co] || 0) + v;
      var C = cols[co] || (cols[co] = { k:co, q:0, v:0, areas:{} });
      C.q += q; C.v += v; C.areas[ar] = 1;
      var K = ar + "\u00a7" + co, E2 = cell[K] || (cell[K] = { q:0, v:0, parties:{} });
      E2.q += q; E2.v += v; E2.parties[p.c] = 1;
    });
    return { rows: rows, cols: cols, cell: cell };
  }

  function bzHtml() {
    var B = bazaar(), M = months();
    var R = Object.keys(B.rows).map(function (k) { return B.rows[k]; }).sort(function (x, y) { return y.v - x.v; });
    var C = Object.keys(B.cols).map(function (k) { return B.cols[k]; });
    if (BZ.base === "mon") C.sort(function (x, y) { return (+x.k) - (+y.k); });
    else C.sort(function (x, y) { return y.v - x.v; }).slice(0, 12);
    if (BZ.base !== "mon") C = C.slice(0, 12);
    var GV = R.reduce(function (s, r) { return s + r.v; }, 0);
    var GQ = R.reduce(function (s, r) { return s + r.q; }, 0);
    var maxCell = 0;
    R.forEach(function (r) { C.forEach(function (c) { var e = B.cell[r.k + "\u00a7" + c.k]; if (e && e.v > maxCell) maxCell = e.v; }); });

    var h = [];
    h.push('<p class="bz-lead">' +
      '<span>' + (BZ.mon ? ml(BZ.mon) : spanText()) + '</span>' +
      '<span>' + R.length + ' ' + (BZ.area === "state" ? "rajya" : BZ.area === "city" ? "shehar" : "pincode") + '</span>' +
      '<span>' + C.length + ' ' + (BZ.base === "broker" ? "broker" : BZ.base === "mon" ? "mahina" : "maal") + '</span>' +
      '<span>₹' + rf(GV) + '</span>' +
      (R[0] ? '<span><b>' + E(R[0].k) + '</b> sabse bada · ' + (GV ? Math.round(R[0].v / GV * 100) : 0) + '%</span>' : "") +
      '</p>');

    /* ---- chunav ---- */
    h.push('<div class="pks-shead"><div>' +
      '<h2>Bazaar ka naksha</h2><p>Kaun sa ilaaka, kis broker ke haath, aur kitna kaam</p>' +
      '<div class="pks-hint">Har khaana us ilaake me us ' + (BZ.base === "broker" ? "broker" : "maal") +
      ' ka kaam hai · <b>tirchi lakeeron wala khaali khaana</b> matlab wahan kaam hai hi nahi — mauka wahin hai · ' +
      'khaane par click kariye to us ilaake ki party khulti hai</div></div>' +
      '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">' +
      '<span class="pks-seg"><button data-bza="state" class="' + (BZ.area === "state" ? "on" : "") + '">Rajya</button>' +
      '<button data-bza="city" class="' + (BZ.area === "city" ? "on" : "") + '">Shehar</button>' +
      '<button data-bza="pin" class="' + (BZ.area === "pin" ? "on" : "") + '">Pincode</button></span>' +
      '<span class="pks-seg two">' +
      '<button data-bzb="broker" class="' + (BZ.base === "broker" ? "on" : "") + '">Broker ke saamne<small>kis dalal ka kaun sa ilaaka</small></button>' +
      '<button data-bzb="item" class="' + (BZ.base === "item" ? "on" : "") + '">Maal ke saamne<small>kis ilaake me kaun sa maal</small></button>' +
      '<button data-bzb="mon" class="' + (BZ.base === "mon" ? "on" : "") + '">Mahine ke saamne<small>kaun sa ilaaka kab chala</small></button></span>' +
      '<button class="pks-btn" data-xls="pksBzTable">Excel me nikaaliye</button></div></div>');

    /* mahine ki patti — ek mahina chunne par poora naksha usi mahine ka ban jata hai */
    if (BZ.base !== "mon") {
      var mv = M.map(function (m) {
        var v = 0;
        (PKS.idx().raw.invoices || []).forEach(function (x) {
          var p = PKS.idx().parties[PKS.clean(x.party)]; if (!p || p.internal) return;
          if (PKS.monOf(x.dt) !== m) return;
          if (!bzMatch(p, x.item, m)) return;
          v += +x.total || 0;
        });
        return { m:m, v:v };
      });
      var mx = Math.max.apply(null, mv.map(function (x) { return x.v; }).concat([1]));
      h.push('<div class="bz-mons"><button class="bz-m' + (BZ.mon ? "" : " on") + '" data-bzm="all">' +
        '<span class="l">Sab mahine</span><span class="v">₹' + rf(mv.reduce(function (s, x) { return s + x.v; }, 0)) + '</span>' +
        '<span class="t"><i style="height:100%"></i></span></button>' +
        mv.map(function (x) {
          return '<button class="bz-m' + (BZ.mon === x.m ? " on" : "") + (PKS.isApr(x.m) ? " apr" : "") + '" data-bzm="' + x.m + '"' +
            (x.v ? "" : " disabled") + '>' +
            '<span class="l">' + ml(x.m) + '</span><span class="v">' + (x.v ? "₹" + rf(x.v) : "—") + '</span>' +
            '<span class="t"><i style="height:' + Math.max(2, Math.round(x.v / mx * 100)) + '%"></i></span></button>';
        }).join("") + '</div>');
    }

    /* ---- upar ki pattiyan ---- */
    var maxV = R.length ? R[0].v : 1;
    h.push('<div class="bz-bars">' + R.slice(0, 6).map(function (r) {
      var rate = r.q ? r.v / r.q : 0;
      return '<div class="bz-b"><div class="bz-h"><span class="nm">' + E(r.k) + '</span>' +
        '<span class="pc">' + (GV ? (r.v / GV * 100).toFixed(1) : 0) + '%</span></div>' +
        '<div class="bz-t"><i style="width:' + Math.max(2, Math.round(r.v / maxV * 100)) + '%"></i></div>' +
        '<div class="bz-s">₹' + rf(r.v) + ' · ' + nf(r.q) + ' Qtl · ' + Object.keys(r.parties).length +
        ' party · aausat ₹' + nf(Math.round(rate)) + '</div></div>';
    }).join("") + '</div>');

    /* ---- matrix ---- */
    h.push('<div class="pks-scroll"><table class="pks-t" id="pksBzTable" style="font-size:' + (12.5 * S.zoom / 100).toFixed(2) + 'px">');
    h.push('<thead><tr><th class="pks-sticky-m l">' +
      (BZ.area === "state" ? "RAJYA" : BZ.area === "city" ? "SHEHAR" : "PINCODE") +
      '<small>neeche kitni party</small></th>');
    C.forEach(function (c) {
      h.push('<th class="' + (BZ.base === "mon" ? (PKS.isApr(+c.k) ? "pks-apr" : "") : "l") + '" style="min-width:104px">' +
        E(bzCol(c.k)) + '<small>₹' + rf(c.v) + '</small></th>');
    });
    h.push('<th class="pks-tot">KUL ₹</th><th>QTL</th><th>AAUSAT RATE</th><th>HISSA</th></tr></thead><tbody>');

    R.forEach(function (r) {
      h.push('<tr><td class="pks-sticky-m"><span class="pks-maal" data-bzr="' + E(r.k) + '">' + E(r.k) + '</span>' +
        '<span class="pks-maal-v" style="color:var(--pks-mut)">' + Object.keys(r.parties).length + ' party</span></td>');
      C.forEach(function (c) {
        var e = B.cell[r.k + "\u00a7" + c.k];
        var apr = (BZ.base === "mon" && PKS.isApr(+c.k)) ? " pks-apr" : "";
        if (!e) {
          h.push('<td class="pks-cell num pks-void' + apr + '" title="' +
            (BZ.base === "mon" ? E(r.k) + ' me ' + E(bzCol(c.k)) + ' ka koi kaam nahi'
                               : E(bzCol(c.k)) + ' ka ' + E(r.k) + ' me koi kaam nahi — mauka yahan hai') + '"></td>');
          return;
        }
        h.push('<td class="pks-cell num' + apr + '" style="' + heat(e.v, maxCell, "teal") + '" data-bzr="' + E(r.k) + '" data-bzc="' + E(c.k) + '" ' +
          'title="' + E(r.k) + ' me ' + E(bzCol(c.k)) + ' · ₹' + rf(e.v) + ' · ' + nf(e.q) + ' Qtl · ' + Object.keys(e.parties).length + ' party">' +
          '<span class="rt-r">₹' + rf(e.v) + '</span><span class="rt-d">' + nf(e.q) + ' Qtl</span></td>');
      });
      var rate = r.q ? r.v / r.q : 0;
      h.push('<td class="num pks-tot">₹' + rf(r.v) + '</td><td class="num">' + nf(r.q) + '</td>' +
        '<td class="num">₹' + nf(Math.round(rate)) + '</td>' +
        '<td class="num">' + (GV ? (r.v / GV * 100).toFixed(1) : 0) + '%</td></tr>');
    });
    if (!R.length) h.push('<tr><td colspan="' + (C.length + 5) + '" class="pks-empty">' +
      (S.q ? 'Is dhoondh se kuch nahi mila — search khaali kar ke dekhiye' : 'Is samay me koi bikri nahi mili') + '</td></tr>');

    h.push('</tbody><tfoot><tr class="pks-foot"><td class="pks-sticky-m">KUL JOD · ' + R.length + ' ilaaka</td>');
    C.forEach(function (c) { h.push('<td class="num' + (BZ.base === "mon" && PKS.isApr(+c.k) ? " pks-apr" : "") + '">₹' + rf(c.v) + '</td>'); });
    h.push('<td class="num">₹' + rf(GV) + '</td><td class="num">' + nf(GQ) + '</td>' +
      '<td class="num">₹' + (GQ ? nf(Math.round(GV / GQ)) : "—") + '</td><td class="num">100%</td></tr></tfoot></table></div>');

    /* ---- khaali khaane ka saar ---- */
    // Mauka kitna bada hai, ye is tarah naapa hai: wo broker (ya maal) jitne ilaakon me kaam
    // kar raha hai, unme uska aausat kitna hai — aur us ilaake me jitne broker kaam kar rahe
    // hain, unka aausat kitna hai. Dono me se chhota wala. Ye "kul" se kaafi kam aur
    // kaafi zyada bharosemand aankda hai.
    var gaps = [];
    R.forEach(function (r) {
      var rN = Object.keys(r.cols).length || 1;
      C.forEach(function (c) {
        if (B.cell[r.k + "\u00a7" + c.k]) return;
        var cN = Object.keys(c.areas).length || 1;
        gaps.push({ ar:r.k, co:c.k, arV:r.v, coV:c.v, cN:cN, rN:rN,
                    score: Math.min(c.v / cN, r.v / rN) });
      });
    });
    gaps.sort(function (x, y) { return y.score - x.score; });
    if (gaps.length && BZ.base !== "mon") {
      h.push('<div class="md-card" style="--mdc:#b5703a;margin-top:14px"><h3>Khaali jagah — jahan kaam ho sakta tha par hua nahi</h3>' +
        '<div class="sub">Ye wo jodiyan hain jahan ilaaka bhi bada hai aur ' + (BZ.base === "broker" ? "broker" : "maal") +
        ' bhi bada, phir bhi aapas me ek bhi bill nahi bana. Sabse upar wali sabse bada mauka.</div>' +
        gaps.slice(0, 6).map(function (g) {
          return '<div class="md-row"><span class="nm">' + E(g.co) + ' <span style="color:var(--pks-mut)">×</span> ' + E(g.ar) +
            '<small>' + E(g.co) + ' abhi ' + g.cN + ' ilaake me · ' + E(g.ar) + ' me abhi ' + g.rN +
            (BZ.base === "broker" ? ' broker' : ' maal') + '</small></span>' +
            '<span class="amt" style="color:var(--pks-copper)">₹' + rf(g.score) + '</span></div>';
        }).join("") +
        '<div class="md-do">Daayin taraf ka aankda andaaza hai, vaada nahi — ' +
        (BZ.base === "broker" ? 'us broker' : 'us maal') + ' ka doosre ilaakon me jo aausat kaam hai, ' +
        'aur us ilaake me baaki ka jo aausat kaam hai, dono me se chhota wala. Itna kaam wahan pehle se ho raha hai, ' +
        'bas is jodi me nahi.</div></div>');
    }
    return h.join("");
  }

  /* ilaake ya khaane par click — wahan ki party */
  function bzDrill(area, col) {
    var IX = PKS.idx(), M = months(), a = M[0], b = M[M.length - 1], by = {};
    (IX.raw.invoices || []).forEach(function (x) {
      var p = IX.parties[PKS.clean(x.party)]; if (!p || p.internal) return;
      var m = PKS.monOf(x.dt); if (m < a || m > b) return;
      if (bzLabel(p) !== area) return;
      if (BZ.mon && m !== BZ.mon) return;
      if (!bzMatch(p, x.item, m)) return;
      var co = (BZ.base === "broker") ? (p.broker || "(broker nahi)")
             : (BZ.base === "mon") ? String(m) : x.item;
      if (col && co !== col) return;
      var o = by[p.c] || (by[p.c] = { p:p, q:0, v:0, last:0, items:{} });
      o.q += +x.qty || 0; o.v += +x.total || 0; o.items[x.item] = 1;
      if (m > o.last) o.last = m;
    });
    var list = Object.keys(by).map(function (k) { return by[k]; }).sort(function (x, y) { return y.v - x.v; });
    var tv = list.reduce(function (s, x) { return s + x.v; }, 0), tq = list.reduce(function (s, x) { return s + x.q; }, 0);

    var html = '<div class="pks-kpis">' +
      '<div class="pks-kpi"><div class="k">Kul kaam</div><div class="v">₹' + rf(tv) + '</div></div>' +
      '<div class="pks-kpi"><div class="k">Maal</div><div class="v">' + nf(tq) + ' Qtl</div></div>' +
      '<div class="pks-kpi"><div class="k">Party</div><div class="v">' + list.length + '</div></div>' +
      '<div class="pks-kpi"><div class="k">Aausat rate</div><div class="v">₹' + (tq ? nf(Math.round(tv / tq)) : "—") + '</div></div></div>' +
      '<div class="pks-sec"><h4>Yahan ki party</h4><table class="pks-d"><thead><tr>' +
      '<th class="l">Party</th><th class="l">Broker</th><th class="l">Halat</th><th class="l">Thikana</th>' +
      '<th>Qtl</th><th>Rakam ₹</th><th>Rate ₹</th><th>Hissa</th><th class="l">Aakhri bill</th></tr></thead><tbody>' +
      (list.length ? list.map(function (x) {
        var st = PKS.statusOf(x.p, M);
        return '<tr><td class="l"><span class="pks-pname" data-open="' + E(x.p.c) + '">' + E(x.p.name) + '</span></td>' +
          '<td class="l">' + E(x.p.broker || "—") + '</td>' +
          '<td class="l"><span class="pks-chip" style="background:' + st.color + '">' + st.label + '</span></td>' +
          '<td class="l">' + E([x.p.city, x.p.pin].filter(Boolean).join(" · ")) + '</td>' +
          '<td>' + nf(x.q) + '</td><td>' + nf(Math.round(x.v)) + '</td>' +
          '<td><b>' + (x.q ? nf(Math.round(x.v / x.q)) : "·") + '</b></td>' +
          '<td>' + (tv ? (x.v / tv * 100).toFixed(1) + "%" : "·") + '</td>' +
          '<td class="l">' + (x.last ? ml(x.last) : "—") + '</td></tr>';
      }).join("") : '<tr><td colspan="9" class="l">Yahan koi party nahi</td></tr>') +
      '</tbody></table></div>';

    PKSD.show(area + (col ? " · " + bzCol(col) : ""),
      (BZ.area === "state" ? "Rajya" : BZ.area === "city" ? "Shehar" : "Pincode") +
      (col ? (BZ.base === "broker" ? " · broker" : BZ.base === "mon" ? " · mahina" : " · maal") : " · saara kaam"),
      ml(M[0]) + " se " + ml(M[M.length - 1]) + " tak", html);
  }

  /* ============================================================
     ISHAARE — data khud bolta hai. Har 30 second me ek nayi baat.
     Sath me ilaake ka target aur uske saamne asli supply.
     ============================================================ */
  var SG = { tgt: {}, tgtBase: null, i: 0, timer: null, paused: false };

  function sgPeriod() {
    var IX = PKS.idx(), M = months();
    var lastDt = 0;
    (IX.raw.invoices || []).forEach(function (x) { if (x.dt > lastDt) lastDt = x.dt; });
    return { M: M, lastDt: lastDt, done: M.filter(function (m) { return m <= Math.floor(lastDt / 100); }).length };
  }

  /* ---------- ilaake ka kaam ---------- */
  function sgAreas() {
    var IX = PKS.idx(), M = months(), a = M[0], b = M[M.length - 1], R = {};
    (IX.raw.invoices || []).forEach(function (x) {
      var p = IX.parties[PKS.clean(x.party)]; if (!p || p.internal) return;
      var m = PKS.monOf(x.dt); if (m < a || m > b) return;
      var k = p.state || "—";
      var o = R[k] || (R[k] = { k: k, q: 0, v: 0, m: {}, parties: {} });
      o.q += +x.qty || 0; o.v += +x.total || 0; o.parties[p.c] = 1;
      var c = o.m[m] || (o.m[m] = { q: 0, v: 0 }); c.q += +x.qty || 0; c.v += +x.total || 0;
    });
    return Object.keys(R).map(function (k) { return R[k]; }).sort(function (x, y) { return y.v - x.v; });
  }

  function sgTargets() {
    var A = sgAreas(), P = sgPeriod();
    var tot = A.reduce(function (s, r) { return s + r.v; }, 0);
    // Target kahan se: pehle pichhle saal ke wahi mahine dekhte hain (+10%). Agar pichhle saal
    // ka aankda nahi hai, to abhi tak ke kaam ko poore samay par phaila kar +10% kar dete hain.
    if (SG.tgtBase !== months().join(",")) {
      SG.tgtBase = months().join(","); SG.tgt = {}; SG.tgtFrom = "raftaar";
      var IXa = PKS.idx(), old = {}, oldTot = 0;
      var want = {}; months().forEach(function (m) { want[PKS.monAdd(m, -12)] = 1; });
      (PKS.DATA.invoices || []).forEach(function (x) {
        var p = IXa.parties[PKS.clean(x.party)]; if (!p || p.internal) return;
        if (!want[PKS.monOf(x.dt)]) return;
        var k = p.state || "—";
        old[k] = (old[k] || 0) + (+x.total || 0); oldTot += +x.total || 0;
      });
      var pace = P.done ? (P.M.length / P.done) : 1;
      if (oldTot > 0) SG.tgtFrom = "pichhla saal";
      A.forEach(function (r) {
        SG.tgt[r.k] = Math.round(oldTot > 0 ? ((old[r.k] || 0) * 1.10) || (r.v * pace) : r.v * pace * 1.10);
      });
    }
    A.forEach(function (r) {
      r.tgt = SG.tgt[r.k] || 0;
      r.pct = r.tgt ? r.v / r.tgt * 100 : 0;
      r.expect = r.tgt * (P.M.length ? P.done / P.M.length : 1);
      r.pace = r.expect ? r.v / r.expect * 100 : 100;
      r.left = Math.max(0, r.tgt - r.v);
    });
    return { A: A, P: P, tot: tot };
  }

  /* ---------- ishaare nikalna ---------- */
  function sgSignals() {
    var IX = PKS.idx(), M = months(), out = [];
    if (M.length < 2) return out;
    var live = M.filter(function (m) {
      var any = false;
      Object.keys(IX.parties).forEach(function (c) { var p = IX.parties[c]; if (!p.internal && p.m[m] && p.m[m].bq) any = true; });
      return any;
    });
    var Lm = live[live.length - 1], prev = live.slice(Math.max(0, live.length - 4), live.length - 1);
    if (!Lm || !prev.length) return out;
    function avg(arr) { return arr.length ? arr.reduce(function (s, x) { return s + x; }, 0) / arr.length : 0; }
    function push(sev, color, title, detail, action, amt, go) {
      out.push({ sev: sev, color: color, title: title, detail: detail, action: action, amt: amt || 0, go: go || null });
    }

    /* --- 1. maal ka order aana band --- */
    var it = {};
    (IX.raw.orders || []).forEach(function (x) {
      var p = IX.parties[PKS.clean(x.party)]; if (!p || p.internal) return;
      var m = PKS.monOf(x.dt);
      var o = it[x.item] || (it[x.item] = {});
      o[m] = (o[m] || 0) + (+x.qty || 0);
    });
    Object.keys(it).forEach(function (item) {
      var now = it[item][Lm] || 0, was = avg(prev.map(function (m) { return it[item][m] || 0; }));
      if (was < 200) return;
      if (!now) push(5, "#a8422f", item + " ka order rukh gaya",
        ml(Lm) + " me is maal ka ek bhi order nahi aaya, jabki pichhle teen mahine ka aausat " + nf(Math.round(was)) + " Qtl tha.",
        "Broker se poochhiye — bazaar me rate baitha hai ya kisi aur mill ne le liya.", was);
      else if (now / was < 0.5) push(4, "#c9a227", item + " ka order aadha rah gaya",
        ml(Lm) + " me " + nf(Math.round(now)) + " Qtl, pichhle teen mahine ka aausat " + nf(Math.round(was)) + " Qtl.",
        "Jin party ne pehle liya tha unhe dobara phone lagwaiye.", was - now);
    });

    /* --- 2. ilaake me rate girna --- */
    var ar = {};
    (IX.raw.invoices || []).forEach(function (x) {
      var p = IX.parties[PKS.clean(x.party)]; if (!p || p.internal) return;
      var m = PKS.monOf(x.dt), k = p.state || "—";
      var o = ar[k] || (ar[k] = {});
      var c = o[m] || (o[m] = { q: 0, v: 0 });
      c.q += +x.qty || 0; c.v += +x.total || 0;
    });
    Object.keys(ar).forEach(function (k) {
      var c = ar[k][Lm]; if (!c || c.q < 150) return;
      var now = c.v / c.q;
      var ps = prev.map(function (m) { return ar[k][m]; }).filter(function (x) { return x && x.q; });
      if (ps.length < 2) return;
      var was = ps.reduce(function (s, x) { return s + x.v; }, 0) / ps.reduce(function (s, x) { return s + x.q; }, 0);
      var d = (now - was) / was * 100;
      if (d <= -3) push(d <= -7 ? 5 : 4, "#a8422f", k + " me rate gir raha hai",
        ml(Lm) + " ka aausat ₹" + nf(Math.round(now)) + ", pichhle teen mahine ka ₹" + nf(Math.round(was)) +
        " — " + Math.abs(d).toFixed(1) + "% neeche.",
        "Us ilaake ke broker se rate confirm kijiye; ho sakta hai koi aur mill saste me daal rahi ho.",
        Math.round((was - now) * c.q));
    });

    /* --- 3. party ka order girna / rukna --- */
    Object.keys(IX.parties).forEach(function (c) {
      var p = IX.parties[c]; if (p.internal) return;
      var now = (p.m[Lm] && p.m[Lm].bq) || 0;
      var was = avg(prev.map(function (m) { return (p.m[m] && p.m[m].bq) || 0; }));
      if (was < 150) return;
      var rate = (p.m[Lm] && p.m[Lm].bq) ? p.m[Lm].val / p.m[Lm].bq : 0;
      if (!now) push(5, "#a8422f", p.name + " ne is mahine kuch nahi liya",
        "Pichhle teen mahine ka aausat " + nf(Math.round(was)) + " Qtl tha, " + ml(Lm) + " me shoonya.",
        (p.broker ? p.broker + " ko bhejiye" : "Khud phone kijiye") + " — rishta abhi tuta nahi hai.",
        Math.round(was * (rate || 5000)), c);
      else if (now / was < 0.6) push(4, "#c9a227", p.name + " ka kaam gir raha hai",
        nf(Math.round(now)) + " Qtl, pehle aausat " + nf(Math.round(was)) + " Qtl — " +
        Math.round((1 - now / was) * 100) + "% neeche.",
        "Poochhiye kya dikkat hai: rate, quality, ya udhaari.", Math.round((was - now) * (rate || 5000)), c);
    });

    /* --- 4. paisa nahi aa raha --- */
    Object.keys(IX.parties).forEach(function (c) {
      var p = IX.parties[c]; if (p.internal) return;
      var t = PKS.sliceOf(p, M);
      if (t.val < 500000) return;
      var bak = t.val - t.pay - t.cut;
      if (t.val && t.pay / t.val < 0.5 && bak > 0)
        push(5, "#b5703a", p.name + " par paisa atka hai",
          "Bikri ₹" + rf(t.val) + ", vasooli sirf ₹" + rf(t.pay) + " — bakaya ₹" + rf(bak) + ".",
          "Naya order rokiye jab tak aadha paisa na aaye.", bak, c);
    });

    /* --- 5. target se peechhe --- */
    var T = sgTargets();
    T.A.forEach(function (r) {
      if (r.pace < 85 && r.tgt > 0)
        push(4, "#2c5f8a", r.k + " target se peechhe chal raha hai",
          "Ab tak ₹" + rf(r.v) + " hua, is raftaar par saal ke aakhir tak ₹" +
          rf(Math.round(r.v * (T.P.done ? T.P.M.length / T.P.done : 1))) + " hoga — target ₹" + rf(r.tgt) + ".",
          "Us ilaake me ek broker aur jodiye, ya purani band party wapas laiye.", r.left);
    });

    /* --- 6. nayi party --- */
    Object.keys(IX.parties).forEach(function (c) {
      var p = IX.parties[c]; if (p.internal) return;
      var fs = PKS.firstSale(p);
      if (fs === Lm && p.m[Lm] && p.m[Lm].bq > 100)
        push(2, "#1f6f6a", p.name + " nayi party judi hai",
          "Pehla bill " + ml(Lm) + " me — " + nf(p.m[Lm].bq) + " Qtl, ₹" + rf(p.m[Lm].val) + ".",
          "Pehla paisa samay par aaya ya nahi, wo dekh lijiye — wahi aage ka rishta tay karta hai.",
          p.m[Lm].val, c);
    });

    /* --- 7. maang thi par maal nahi gaya --- */
    var dm = {};
    (IX.raw.demand || []).forEach(function (x) {
      var m = PKS.monOf(x.dt);
      var o = dm[x.item] || (dm[x.item] = {});
      var c = o[m] || (o[m] = { q: 0, why: {}, rate: 0 });
      c.q += +x.qty || 0; c.rate += (+x.rate || 0) * (+x.qty || 0);
      if (x.why) c.why[x.why] = (c.why[x.why] || 0) + (+x.qty || 0);
    });
    var bm = {};
    (IX.raw.invoices || []).forEach(function (x) {
      var p = IX.parties[PKS.clean(x.party)]; if (!p || p.internal) return;
      var m = PKS.monOf(x.dt);
      var o = bm[x.item] || (bm[x.item] = {});
      var c = o[m] || (o[m] = { q: 0, v: 0 });
      c.q += +x.qty || 0; c.v += +x.total || 0;
    });
    Object.keys(dm).forEach(function (item) {
      var dc = dm[item][Lm], bc = (bm[item] || {})[Lm];
      if (!dc) return;
      var sold = bc ? bc.q : 0, lost = dc.q - sold;
      var wantRate = dc.q ? dc.rate / dc.q : 0;
      var stock = IX.stock[Lm + "|" + item] || 0;
      if (lost > 300) {
        var top = Object.keys(dc.why).sort(function (x, y) { return dc.why[y] - dc.why[x]; })[0];
        push(5, "#a8422f", item + " ki maang thi, maal nahi gaya",
          ml(Lm) + " me maang " + nf(dc.q) + " Qtl, becha sirf " + nf(sold) + " Qtl — " + nf(lost) +
          " Qtl haath se nikal gaya. Us mahine plant me bana tha " + nf(stock) + " Qtl." +
          (top ? " Sabse badi wajah: " + top + "." : ""),
          "Maang aur maal wale panne par dekhiye — agar wajah maal ki kami hai to agle mausam se pehle stock banaiye.",
          Math.round(lost * (wantRate || 5000)));
      }
      // maang kam thi phir bhi becha — rate girana pada
      if (bc && dc.q && bc.q > dc.q * 1.15) {
        var got = bc.q ? bc.v / bc.q : 0;
        if (wantRate && got < wantRate * 0.97)
          push(4, "#c9a227", item + " maang se zyada becha, rate chhodna pada",
            ml(Lm) + " me maang " + nf(dc.q) + " Qtl thi, becha " + nf(bc.q) + " Qtl. Maang ka rate ₹" +
            nf(Math.round(wantRate)) + " tha, bika ₹" + nf(Math.round(got)) + " par.",
            "Jab maang kam ho to maal dhakelne ke bajaye rok lijiye — rate girane se agla mahina bhi kharab hota hai.",
            Math.round((wantRate - got) * bc.q));
      }
    });

    /* --- 8. mausam ki tayyari --- */
    mgSeason().forEach(function (x) {
      if (x.kami <= 200 || !x.build.length) return;
      push(3, "#2c5f8a", x.item + " ka mausam " + PKS.MON_HI[x.peakM - 1] + " me aata hai, stock abhi se banaiye",
        PKS.MON_HI[x.peakM - 1] + " ki aausat maang " + nf(Math.round(x.peak)) + " Qtl hai, par us mahine plant me banta hai sirf " +
        nf(Math.round(x.peakProd)) + " Qtl — " + nf(Math.round(x.kami)) + " Qtl ki kami.",
        x.build.map(function (m) { return PKS.MON_HI[m - 1]; }).join(", ") + " me maang sust rehti hai — usi samay har mahine " +
        nf(Math.round(x.kami / x.build.length)) + " Qtl banakar rakhiye.",
        Math.round(x.kami * 5000));
    });

    /* --- 9. order pada hai, bill nahi bana --- */
    Object.keys(IX.parties).forEach(function (c) {
      var p = IX.parties[c]; if (p.internal) return;
      var t = PKS.sliceOf(p, M);
      if (t.oq > 300 && !t.bq)
        push(5, "#7a3f6d", p.name + " ka order pada hai, bill nahi bana",
          nf(t.oq) + " Qtl ka order register me hai, ₹" + rf(t.oval) + " ka — ek bhi bill nahi.",
          "Order lene wale se aaj hi poochhiye — sauda toota ya order hi jhootha tha.", t.oval, c);
    });

    out.sort(function (x, y) { return y.sev - x.sev || y.amt - x.amt; });
    return out.slice(0, 14);
  }

  /* ---------- screen ---------- */
  function sgHtml() {
    var T = sgTargets(), S2 = sgSignals();
    SG.list = S2;
    if (SG.i >= S2.length) SG.i = 0;

    var h = [];
    h.push('<div class="pks-shead"><div><h2>Ishaare</h2>' +
      '<p>Data khud bata raha hai — har paanch second me ek naya panna</p>' +
      '<div class="pks-hint">Ye baatein kisi ne likhi nahi hain — ' + ml(months()[months().length - 1]) +
      ' tak ke aankdon se khud nikli hain. Sabse gambhir sabse pehle.</div></div>' +
      '<div style="display:flex;gap:10px;align-items:center">' +
      '<button class="pks-btn" data-sg="prev">‹ Pichhla</button>' +
      '<button class="pks-btn ' + (SG.paused ? "" : "solid") + '" data-sg="play">' + (SG.paused ? "Chalaiye" : "Ruk jaiye") + '</button>' +
      '<button class="pks-btn" data-sg="next">Agla ›</button></div></div>');

    h.push('<div id="pksSgSpot">' + sgSpot() + '</div>');

    /* ---- target aur supply ---- */
    var P = T.P;
    h.push('<div class="pks-sec2"><div class="pks-shead"><div><h2>Ilaake ka target aur asli supply</h2>' +
      '<p>Kis ilaake me kitna bhejna tha, kitna gaya, aur is raftaar par kya hoga</p>' +
      '<div class="pks-hint">Target apne aap bana hai — ' +
      (SG.tgtFrom === "pichhla saal"
        ? '<b>pichhle saal ke wahi mahine + 10%</b>'
        : '<b>abhi tak ke kaam ko poore samay par phaila kar + 10%</b> (pichhle saal ka aankda is daayre me nahi hai)') + '. ' +
      'Har line ka target aap khud badal sakte hain, table turant naya hisaab kar deta hai. ' +
      'Aankde <b>' + PKS.dstr(P.lastDt) + '</b> tak ke hain — ' + P.done + ' me se ' + P.M.length + ' mahine poore.</div></div></div>');

    h.push('<div class="pks-scroll"><table class="pks-t" id="pksTgTable" style="font-size:' + (12.5 * S.zoom / 100).toFixed(2) + 'px">' +
      '<thead><tr><th class="pks-sticky-m l">RAJYA<small>neeche kitni party</small></th>' +
      '<th>TARGET ₹</th><th>AB TAK ₹</th><th>QTL</th><th class="l">KITNA POORA</th>' +
      '<th>BACHA ₹</th><th>RAFTAAR</th><th class="l">HAAL</th></tr></thead><tbody>');
    T.A.forEach(function (r) {
      var haal = r.pace >= 100 ? { t: "Aage chal raha", c: "#1f6f6a" }
               : r.pace >= 85 ? { t: "Raftaar par", c: "#2f8f6b" }
               : r.pace >= 60 ? { t: "Thoda peechhe", c: "#c9a227" }
                              : { t: "Bahut peechhe", c: "#a8422f" };
      h.push('<tr><td class="pks-sticky-m"><span class="pks-maal" data-bzr="' + E(r.k) + '">' + E(r.k) + '</span>' +
        '<span class="pks-maal-v" style="color:var(--pks-mut)">' + Object.keys(r.parties).length + ' party</span></td>' +
        '<td class="num"><input class="tg-in" data-tg="' + E(r.k) + '" value="' + Math.round(r.tgt) + '" inputmode="numeric"></td>' +
        '<td class="num"><b>₹' + rf(r.v) + '</b></td><td class="num">' + nf(r.q) + '</td>' +
        '<td><div class="tg-t"><i style="width:' + Math.min(100, r.pct).toFixed(1) + '%;background:' + haal.c + '"></i></div>' +
        '<span class="tg-p">' + r.pct.toFixed(1) + '%</span></td>' +
        '<td class="num">₹' + rf(r.left) + '</td>' +
        '<td class="num" style="color:' + haal.c + ';font-weight:700">' + Math.round(r.pace) + '%</td>' +
        '<td><span class="pks-chip" style="background:' + haal.c + '">' + haal.t + '</span></td></tr>');
    });
    var TT = T.A.reduce(function (s, r) { return s + r.tgt; }, 0), TV = T.A.reduce(function (s, r) { return s + r.v; }, 0),
        TQ = T.A.reduce(function (s, r) { return s + r.q; }, 0);
    h.push('</tbody><tfoot><tr class="pks-foot"><td class="pks-sticky-m">KUL JOD · ' + T.A.length + ' ilaaka</td>' +
      '<td class="num">₹' + rf(TT) + '</td><td class="num">₹' + rf(TV) + '</td><td class="num">' + nf(TQ) + '</td>' +
      '<td>' + (TT ? (TV / TT * 100).toFixed(1) : 0) + '% poora</td>' +
      '<td class="num">₹' + rf(Math.max(0, TT - TV)) + '</td><td class="num"></td>' +
      '<td>' + PKS.dstr(P.lastDt) + ' tak</td></tr></tfoot></table></div></div>');
    return h.join("");
  }

  function sgSpot() {
    var L = SG.list || [];
    if (!L.length) return '<div class="sg-spot"><div class="sg-t">Abhi koi ishaara nahi</div>' +
      '<div class="sg-d">Is samay ke aankdon me dhyan dene layak kuch nahi mila. Samay badal kar dekhiye.</div></div>';
    var x = L[SG.i % L.length];
    return '<div class="sg-spot' + (SG.back ? " back" : "") + '" style="--sgc:' + x.color + '">' +
      '<div class="sg-head"><span class="sg-n">' + ((SG.i % L.length) + 1) + ' / ' + L.length + '</span>' +
      '<span class="sg-dots">' + L.map(function (_, i) {
        return '<i class="' + (i === (SG.i % L.length) ? "on" : "") + '" data-sgi="' + i + '"></i>';
      }).join("") + '</span></div>' +
      '<div class="sg-t">' + E(x.title) + '</div>' +
      '<div class="sg-d">' + E(x.detail) + '</div>' +
      (x.amt ? '<div class="sg-a">Is baat ka wazan lagbhag ₹' + rf(x.amt) + '</div>' : '') +
      '<div class="sg-do">' + E(x.action) + '</div>' +
      (x.go ? '<button class="pks-btn" data-open="' + E(x.go) + '" style="margin-top:10px">Is party ka poora byora</button>' : '') +
      '<div class="sg-bar"><i' + (SG.paused ? ' class="stop"' : '') + '></i></div></div>';
  }

  function sgTick(step) {
    var L = SG.list || []; if (!L.length) return;
    SG.back = (step || 1) < 0;          // panna ulta palta hai ya seedha
    SG.i = (SG.i + (step || 1) + L.length) % L.length;
    var el = document.getElementById("pksSgSpot");
    if (el) el.innerHTML = sgSpot();
  }
  function sgTimer(on) {
    if (SG.timer) { clearInterval(SG.timer); SG.timer = null; }
    if (on && !SG.paused) SG.timer = setInterval(function () { sgTick(1); }, 5000);
  }

  /* ============================================================
     MAANG AUR MAAL — jo maanga gaya uske saamne jo becha.
     Yahi wo register hai jo abhi kisi ERP me nahi hai: 220 ki maang thi,
     100 becha — baaki 120 kahan gaya, aur kyun gaya.
     ============================================================ */
  var MG = { view: "qty" };

  function mgAgg() {
    var IX = PKS.idx(), M = months(), a = M[0], b = M[M.length - 1], R = {}, why = {};
    function row(it) {
      return R[it] || (R[it] = { k: it, m: {}, dq: 0, bq: 0, val: 0, lost: 0 });
    }
    function cell(r, m) {
      return r.m[m] || (r.m[m] = { dq: 0, bq: 0, val: 0, drate: 0, dn: 0, stock: 0 });
    }
    (IX.raw.demand || []).forEach(function (x) {
      var m = PKS.monOf(x.dt); if (m < a || m > b) return;
      if (S.q && (x.item + " " + x.party + " " + x.broker + " " + x.state + " " + x.city).toUpperCase().indexOf(S.q.toUpperCase()) < 0) return;
      var r = row(x.item), c = cell(r, m);
      c.dq += +x.qty || 0; c.drate += (+x.rate || 0) * (+x.qty || 0); c.dn += +x.qty || 0;
      r.dq += +x.qty || 0;
      if (x.why) why[x.why] = (why[x.why] || 0) + (+x.qty || 0);
    });
    (IX.raw.invoices || []).forEach(function (x) {
      var p = IX.parties[PKS.clean(x.party)]; if (!p || p.internal) return;
      var m = PKS.monOf(x.dt); if (m < a || m > b) return;
      if (S.q && (x.item + " " + p.name + " " + (p.broker || "") + " " + (p.state || "") + " " + (p.city || "")).toUpperCase().indexOf(S.q.toUpperCase()) < 0) return;
      var r = row(x.item), c = cell(r, m);
      c.bq += +x.qty || 0; c.val += +x.total || 0;
      r.bq += +x.qty || 0; r.val += +x.total || 0;
    });
    Object.keys(R).forEach(function (it) {
      var r = R[it];
      M.forEach(function (m) {
        var c = r.m[m]; if (!c) return;
        c.stock = IX.stock[m + "|" + it] || 0;
        c.lost = Math.max(0, c.dq - c.bq);
        c.rate = c.bq ? c.val / c.bq : 0;
        c.wanted = c.dn ? c.drate / c.dn : 0;
        r.lost += c.lost;
      });
    });
    return { R: Object.keys(R).map(function (k) { return R[k]; }).sort(function (x, y) { return y.dq - x.dq; }),
             why: why, M: M };
  }

  /* mausam ka hisaab: har calendar mahine ki aausat maang, poore data se */
  function mgSeason() {
    var IX = PKS.idx(), byItem = {};
    (PKS.DATA.demand || []).forEach(function (x) {
      var mm = x.dt % 10000; mm = Math.floor(mm / 100);
      var o = byItem[x.item] || (byItem[x.item] = { mon: {}, n: {} });
      o.mon[mm] = (o.mon[mm] || 0) + (+x.qty || 0);
      o.n[mm] = (o.n[mm] || 0) + 1;
    });
    var prod = {};
    (PKS.DATA.stock || []).forEach(function (x) {
      var mm = x.mon % 100;
      var o = prod[x.item] || (prod[x.item] = {});
      o[mm] = o[mm] || { q: 0, n: 0 };
      o[mm].q += +x.qty || 0; o[mm].n++;
    });
    var yrs = {};
    (PKS.DATA.demand || []).forEach(function (x) { yrs[Math.floor(x.dt / 10000)] = 1; });
    var nY = Math.max(1, Object.keys(yrs).length);

    return Object.keys(byItem).map(function (it) {
      var o = byItem[it], avg = {}, peak = 0, peakM = 0;
      for (var mm = 1; mm <= 12; mm++) {
        avg[mm] = (o.mon[mm] || 0) / nY;
        if (avg[mm] > peak) { peak = avg[mm]; peakM = mm; }
      }
      var pr = prod[it] || {};
      var peakProd = pr[peakM] ? pr[peakM].q / pr[peakM].n : 0;
      var kami = Math.max(0, peak - peakProd);
      // sasta samay: peak se pehle ke 4 mahine jinme maang peak ke 60% se kam ho
      var build = [];
      for (var i = 4; i >= 1; i--) {
        var m2 = ((peakM - i - 1) + 12) % 12 + 1;
        if (avg[m2] < peak * 0.6) build.push(m2);
      }
      return { item: it, avg: avg, peak: peak, peakM: peakM, peakProd: peakProd, kami: kami, build: build };
    }).sort(function (x, y) { return y.kami - x.kami; });
  }

  function mgHtml() {
    var A = mgAgg(), M = A.M, SZ = mgSeason();
    var GD = 0, GB = 0, GL = 0, GV = 0;
    A.R.forEach(function (r) { GD += r.dq; GB += r.bq; GL += r.lost; GV += r.val; });
    var avgRate = GB ? GV / GB : 0;

    var h = [];
    h.push('<div class="pks-shead"><div><h2>Maang aur maal</h2>' +
      '<p>Jitni maang aayi, utna maal gaya ya nahi — aur jo chhoot gaya wo kitne ka tha</p>' +
      '<div class="pks-hint">Upar wala aankda <b>maang</b> hai, neeche wala <b>jo becha</b>. Patti batati hai kitni maang poori hui · ' +
      'laal matlab maang thi par maal nahi gaya · neela matlab maang se zyada becha — wahan aksar rate girana padta hai · ' +
      'khaane par click kariye to us mahine ki maang ka byora khulta hai</div></div>' +
      '<button class="pks-btn" data-xls="pksMgTable">Excel me nikaaliye</button></div>');

    h.push('<div class="md-kpis">' +
      '<div class="md-kpi"><div class="k">Kul maang</div><div class="v">' + nf(GD) + '</div><div class="s">Qtl</div></div>' +
      '<div class="md-kpi"><div class="k">Jitna becha</div><div class="v">' + nf(GB) + '</div><div class="s">Qtl · ₹' + rf(GV) + '</div></div>' +
      '<div class="md-kpi"><div class="k">Maang poori hui</div><div class="v">' + (GD ? Math.round(Math.min(GB, GD) / GD * 100) : 0) + '%</div>' +
      '<div class="s">' + nf(GL) + ' Qtl chhoot gaya</div></div>' +
      '<div class="md-kpi"><div class="k">Chhooti maang ka mol</div><div class="v" style="color:#a8422f">₹' + rf(GL * avgRate) + '</div>' +
      '<div class="s">aaj ke aausat rate ₹' + nf(Math.round(avgRate)) + ' par</div></div></div>');

    /* ---- matrix ---- */
    var max = 0;
    A.R.forEach(function (r) { M.forEach(function (m) { var c = r.m[m]; if (c && c.dq > max) max = c.dq; }); });
    h.push('<div class="pks-scroll"><table class="pks-t pks-ovi" id="pksMgTable" style="font-size:' + (12.5 * S.zoom / 100).toFixed(2) + 'px">' +
      '<thead><tr><th class="pks-sticky-m l">MAAL<small>upar maang, neeche bikri</small></th>');
    M.forEach(function (m) { h.push('<th class="' + (PKS.isApr(m) ? "pks-apr" : "") + '">' + ml(m) + '</th>'); });
    h.push('<th class="pks-tot">KUL MAANG</th><th>BECHA</th><th>POORA</th><th>CHHOOT GAYA</th></tr></thead><tbody>');

    A.R.forEach(function (r) {
      h.push('<tr><td class="pks-sticky-m"><span class="pks-maal" data-mgi="' + E(r.k) + '">' + E(r.k) + '</span>' +
        '<span class="pks-maal-v" style="color:var(--pks-mut)">' + nf(r.lost) + ' Qtl chhoota</span></td>');
      M.forEach(function (m) {
        var c = r.m[m];
        if (!c || (!c.dq && !c.bq)) { h.push('<td class="pks-cell num pks-void ' + (PKS.isApr(m) ? "pks-apr" : "") + '"></td>'); return; }
        var pct = c.dq ? Math.min(100, c.bq / c.dq * 100) : 100;
        var col = !c.dq ? "#2c5f8a" : (pct >= 90 ? "#1f6f6a" : pct >= 60 ? "#c9a227" : "#a8422f");
        var over = c.dq && c.bq > c.dq;
        var band = over ? "#2c5f8a" : col;
        var sz = Math.sqrt(Math.min(Math.max(c.dq, c.bq) / (max || 1), 1));
        h.push('<td class="pks-cell num ' + (PKS.isApr(m) ? "pks-apr" : "") + '" style="background:' + hexA(band, 0.05 + 0.16 * sz) + '" ' +
          'data-mgi="' + E(r.k) + '" data-mgm="' + m + '" title="' + E(r.k) + ' · ' + ml(m) +
          ' — maang ' + nf(c.dq) + ' Qtl, becha ' + nf(c.bq) + ' Qtl' +
          (c.lost ? ', chhoota ' + nf(c.lost) + ' Qtl' : '') +
          ' · us mahine production ' + nf(c.stock) + ' Qtl' +
          (c.wanted ? ' · maang ka rate ₹' + nf(Math.round(c.wanted)) : '') +
          (c.rate ? ' · bika ₹' + nf(Math.round(c.rate)) : '') + '">' +
          '<span class="ov-o">' + (c.dq ? nf(c.dq) : "–") + '</span>' +
          '<span class="ov-b" style="color:' + band + '">' + (c.bq ? nf(c.bq) : "–") + '</span>' +
          '<span class="ov-bar"><i style="width:' + (over ? 100 : pct).toFixed(0) + '%;background:' + band + '"></i></span></td>');
      });
      var pr = r.dq ? Math.round(Math.min(r.bq, r.dq) / r.dq * 100) : 100;
      h.push('<td class="num pks-tot">' + nf(r.dq) + '</td><td class="num">' + nf(r.bq) + '</td>' +
        '<td class="num" style="color:' + (pr >= 90 ? "#1f6f6a" : pr >= 60 ? "#c9a227" : "#a8422f") + ';font-weight:700">' + pr + '%</td>' +
        '<td class="num" style="color:#a8422f;font-weight:700">' + nf(r.lost) + '</td></tr>');
    });
    h.push('</tbody><tfoot><tr class="pks-foot"><td class="pks-sticky-m">KUL JOD · ' + A.R.length + ' maal</td>');
    M.forEach(function (m) {
      var dq = 0, bq = 0;
      A.R.forEach(function (r) { var c = r.m[m]; if (c) { dq += c.dq; bq += c.bq; } });
      h.push('<td class="num ' + (PKS.isApr(m) ? "pks-apr" : "") + '">' +
        '<span class="ov-o">' + nf(dq) + '</span><span class="ov-b">' + nf(bq) + '</span></td>');
    });
    h.push('<td class="num">' + nf(GD) + '</td><td class="num">' + nf(GB) + '</td>' +
      '<td class="num">' + (GD ? Math.round(Math.min(GB, GD) / GD * 100) : 0) + '%</td>' +
      '<td class="num">' + nf(GL) + '</td></tr></tfoot></table></div>');

    /* ---- maang kyun chhooti ---- */
    var wk = Object.keys(A.why).sort(function (x, y) { return A.why[y] - A.why[x]; });
    if (wk.length) {
      h.push('<div class="md-cards" style="margin-top:14px"><div class="md-card" style="--mdc:#a8422f">' +
        '<h3>Maang chhooti to kyun chhooti</h3>' +
        '<div class="big">' + nf(GL) + ' Qtl</div>' +
        '<div class="sub">Ye wo maal hai jo maanga gaya par gaya nahi. Wajah har line me darj hoti hai — ' +
        'isi se pata chalta hai ki galti stock ki thi, rate ki, ya vasooli ki.</div>' +
        wk.map(function (k) {
          return '<div class="md-row"><span class="nm">' + E(k) + '</span><span class="amt">' + nf(A.why[k]) + ' Qtl</span></div>';
        }).join("") +
        '<div class="md-do">"Maal hi nahi tha" sabse upar ho to ye bikri ki galti nahi, planning ki hai — neeche wali tayyari dekhiye.</div></div>');

      /* ---- mausam aur stock ki tayyari ---- */
      h.push('<div class="md-card" style="--mdc:#1f6f6a"><h3>Mausam ki tayyari — kab se stock banaiye</h3>' +
        '<div class="big">' + SZ.filter(function (x) { return x.kami > 0; }).length + ' maal</div>' +
        '<div class="sub">Jinki peak wale mahine ki maang us mahine ke production se zyada hai. Sasta samay wo hai ' +
        'jab maang peak ke 60% se neeche rehti hai — usi samay banakar rakhna hota hai.</div>' +
        SZ.slice(0, 5).map(function (x) {
          return '<div class="md-row"><span class="nm">' + E(x.item) +
            '<small>peak ' + PKS.MON_HI[x.peakM - 1] + ' · maang ' + nf(Math.round(x.peak)) + ' Qtl · us mahine banta ' +
            nf(Math.round(x.peakProd)) + ' Qtl' +
            (x.build.length ? ' · stock banaiye ' + x.build.map(function (m) { return PKS.MON_HI[m - 1]; }).join(", ") : '') +
            '</small></span><span class="amt" style="color:' + (x.kami > 0 ? "#a8422f" : "#1f6f6a") + '">' +
            (x.kami > 0 ? nf(Math.round(x.kami)) + " Qtl kami" : "poora pad jata hai") + '</span></div>';
        }).join("") +
        '<div class="md-do">Jahan kami hai, wahan peak se pehle ke sust mahinon me har mahine ' +
        'thoda-thoda banakar rakhiye — peak par maal khatam nahi hoga aur rate bhi apna rahega.</div></div></div>');
    }
    return h.join("");
  }

  /* khaane par click — us mahine ki maang ka byora */
  function mgDrill(item, mon) {
    var IX = PKS.idx(), M = months(), a = mon || M[0], b = mon || M[M.length - 1];
    var lines = (IX.raw.demand || []).filter(function (x) {
      var m = PKS.monOf(x.dt);
      return x.item === item && m >= a && m <= b;
    }).sort(function (x, y) { return y.qty - x.qty; });
    var bills = (IX.raw.invoices || []).filter(function (x) {
      var p = IX.parties[PKS.clean(x.party)]; if (!p || p.internal) return false;
      var m = PKS.monOf(x.dt);
      return x.item === item && m >= a && m <= b;
    });
    var dq = lines.reduce(function (s, x) { return s + x.qty; }, 0);
    var bq = bills.reduce(function (s, x) { return s + (+x.qty || 0); }, 0);
    var bv = bills.reduce(function (s, x) { return s + (+x.total || 0); }, 0);
    var wantRate = dq ? lines.reduce(function (s, x) { return s + x.rate * x.qty; }, 0) / dq : 0;
    var gotRate = bq ? bv / bq : 0;
    var stock = 0;
    for (var m2 = a; m2 <= b; m2 = PKS.monAdd(m2, 1)) stock += IX.stock[m2 + "|" + item] || 0;

    var html = '<div class="pks-kpis">' +
      '<div class="pks-kpi"><div class="k">Maang</div><div class="v">' + nf(dq) + ' Qtl</div></div>' +
      '<div class="pks-kpi"><div class="k">Becha</div><div class="v">' + nf(bq) + ' Qtl</div></div>' +
      '<div class="pks-kpi"><div class="k">Us samay banaya</div><div class="v">' + nf(stock) + ' Qtl</div></div>' +
      '<div class="pks-kpi"><div class="k">Chhoot gaya</div><div class="v" style="color:#a8422f">' + nf(Math.max(0, dq - bq)) + ' Qtl</div></div></div>' +
      '<div class="pks-bigline"><div class="k">Maang kis rate par thi, aur bika kis rate par</div>' +
      '<div class="v">₹' + nf(Math.round(wantRate)) + ' <span style="font-size:13px;color:var(--pks-mut)">maang</span> ' +
      ' → ₹' + nf(Math.round(gotRate)) + ' <span style="font-size:13px;color:var(--pks-mut)">bika</span></div>' +
      '<div class="k" style="margin-top:2px">' +
      (gotRate && wantRate
        ? (gotRate < wantRate
            ? "Bika hua rate maang ke rate se ₹" + nf(Math.round(wantRate - gotRate)) + " neeche — itna chhodna pada."
            : "Bika hua rate maang ke rate se ₹" + nf(Math.round(gotRate - wantRate)) + " upar raha.")
        : "Tulna ke liye dono taraf ka aankda nahi hai.") + '</div></div>' +
      '<div class="pks-sec"><h4>Kisne kitni maang bheji</h4><table class="pks-d"><thead><tr>' +
      '<th class="l">Date</th><th class="l">Party</th><th class="l">Broker</th><th class="l">Ilaaka</th>' +
      '<th>Maang Qtl</th><th>Rate ₹</th><th class="l">Nahi becha to kyun</th></tr></thead><tbody>' +
      (lines.length ? lines.map(function (x) {
        return '<tr><td class="l">' + PKS.dstr(x.dt) + '</td><td class="l">' + E(x.party) + '</td>' +
          '<td class="l">' + E(x.broker || "—") + '</td><td class="l">' + E([x.city, x.state].filter(Boolean).join(", ")) + '</td>' +
          '<td>' + nf(x.qty) + '</td><td>' + nf(x.rate) + '</td>' +
          '<td class="l" style="color:' + (x.why ? "#a8422f" : "var(--pks-mut)") + '">' + E(x.why || "— becha gaya") + '</td></tr>';
      }).join("") : '<tr><td colspan="7" class="l">Is samay ki koi maang darj nahi</td></tr>') +
      '</tbody><tfoot><tr><td class="l" colspan="4">Jod</td><td>' + nf(dq) + '</td><td>' + nf(Math.round(wantRate)) + '</td><td></td></tr></tfoot></table></div>';

    PKSD.show(item, "Maang aur maal", mon ? "Sirf " + ml(mon) : ml(M[0]) + " se " + ml(M[M.length - 1]) + " tak", html);
  }

  /* ============================================================
     BAZAAR KI KHABAR — hamara apna aankda + AI se bahar ka haal.
     Baayen: hamara maal kis rajya me chalta hai aur hamara rate kya hai (apne data se).
     Daayen: AI web se bazaar ka bhaav, kis brand ka zor, aur tulna.
     ============================================================ */
  var KH = { busy: false, out: null, err: null, extra: "", brand: "CHETAK" };

  /* Hamare apne brand aur har ek ki chaal. Ye maalik ne tay ki hai, data se nahi nikli —
     isliye yahin likhi hai. Naya brand jodna ho to bas is list me ek line aur. */
  var BRANDS = [
    { n: "CHETAK", stance: "Aage badhane wala", note: "Jahan hissa badhana hai — nayi party, naya ilaaka", c: "#b5703a" },
    { n: "TIGER",  stance: "Sabse upar",        note: "Sabse ooncha rate, sabse achhi quality — yahan rate par samjhauta nahi", c: "#1f6f6a" },
    { n: "MANI",   stance: "Jaisa hai waisa",   note: "Chalta rahe, na ghatt na badhe", c: "#2c5f8a" },
    { n: "APPLE",  stance: "Jaisa hai waisa",   note: "Chalta rahe, na ghatt na badhe", c: "#2c5f8a" },
    { n: "ANMOL",  stance: "Market me ladne wala", note: "Jahan doosri mill rate girati hai, wahan ye utarta hai", c: "#a8422f" }
  ];

  /* hamara apna naksha — maal × rajya */
  function khOurs() {
    var IX = PKS.idx(), M = months(), a = M[0], b = M[M.length - 1], R = {};
    (IX.raw.invoices || []).forEach(function (x) {
      var p = IX.parties[PKS.clean(x.party)]; if (!p || p.internal) return;
      var m = PKS.monOf(x.dt); if (m < a || m > b) return;
      var k = x.item, st = p.state || "—";
      var r = R[k] || (R[k] = { item: k, q: 0, v: 0, st: {} });
      r.q += +x.qty || 0; r.v += +x.total || 0;
      var s2 = r.st[st] || (r.st[st] = { q: 0, v: 0 });
      s2.q += +x.qty || 0; s2.v += +x.total || 0;
    });
    return Object.keys(R).map(function (k) {
      var r = R[k];
      r.rate = r.q ? r.v / r.q : 0;
      r.top = Object.keys(r.st).map(function (s2) {
        return { k: s2, q: r.st[s2].q, v: r.st[s2].v, rate: r.st[s2].q ? r.st[s2].v / r.st[s2].q : 0 };
      }).sort(function (x, y) { return y.v - x.v; });
      return r;
    }).sort(function (x, y) { return y.v - x.v; });
  }

  /* Hamare apne aankdon se: har rajya me kitni maang chhooti, hamara rate apne aausat se
     upar hai ya neeche, aur kitni party hai. Brand ki chaal ke hisaab se kram badalta hai. */
  function khOpp() {
    var IX = PKS.idx(), M = months(), a = M[0], b = M[M.length - 1], R = {};
    function row(k) { return R[k] || (R[k] = { k: k, q: 0, v: 0, dq: 0, lost: 0, parties: {} }); }
    (IX.raw.invoices || []).forEach(function (x) {
      var p = IX.parties[PKS.clean(x.party)]; if (!p || p.internal) return;
      var m = PKS.monOf(x.dt); if (m < a || m > b) return;
      var r = row(p.state || "—");
      r.q += +x.qty || 0; r.v += +x.total || 0; r.parties[p.c] = 1;
    });
    (IX.raw.demand || []).forEach(function (x) {
      var m = PKS.monOf(x.dt); if (m < a || m > b) return;
      row(x.state || "—").dq += +x.qty || 0;
    });
    var tq = 0, tv = 0;
    Object.keys(R).forEach(function (k) { tq += R[k].q; tv += R[k].v; });
    var avg = tq ? tv / tq : 0;
    var L = Object.keys(R).map(function (k) {
      var r = R[k];
      r.rate = r.q ? r.v / r.q : 0;
      r.gap = avg ? (r.rate - avg) / avg * 100 : 0;
      r.lost = Math.max(0, r.dq - r.q);
      r.n = Object.keys(r.parties).length;
      return r;
    });
    var st = (BRANDS.filter(function (x) { return x.n === KH.brand; })[0] || BRANDS[0]).stance;
    if (st === "Sabse upar") L.sort(function (x, y) { return y.gap - x.gap || y.v - x.v; });
    else if (st === "Market me ladne wala") L.sort(function (x, y) { return x.gap - y.gap || y.lost - x.lost; });
    else L.sort(function (x, y) { return y.lost - x.lost || y.dq - x.dq; });
    return { L: L, avg: avg, stance: st };
  }

  function khHtml() {
    var O = khOurs(), M = months();
    var h = [];
    h.push('<div class="pks-shead"><div><h2>Bazaar ki khabar</h2>' +
      '<p>Hamara maal kis rajya me chalta hai — aur bahar bazaar me uska kya bhaav chal raha hai</p>' +
      '<div class="pks-hint">Baayen taraf ka hisaab <b>hamare apne bill</b> se banta hai. ' +
      'Daayen taraf ki khabar <b>AI web par dhoondh kar</b> laata hai — mandi bhaav, kis brand ka zor, aur tulna. ' +
      'Bahar ki khabar hamesha jaanch kar hi istemaal kijiye.</div></div>' +
      '<div style="display:flex;gap:10px;align-items:center">' +
      '<input class="pks-inp" id="pksKhQ" placeholder="Koi khaas sawaal (jaise: MP me besan ka bhaav)" value="' + E(KH.extra) + '" style="min-width:280px">' +
      '<button class="pks-btn solid" data-kh="go"' + (KH.busy ? " disabled" : "") + '>' +
      (KH.busy ? "Dhoondh raha hoon…" : "Bazaar ka haal mangwaiye") + '</button></div></div>');

    /* ---- hamare brand ---- */
    h.push('<div class="kh-brands">' + BRANDS.map(function (b, i) {
      return '<button class="kh-b' + (KH.brand === b.n ? " on" : "") + '" data-khb="' + E(b.n) + '" style="--bc:' + b.c + '">' +
        '<span class="i">' + (i + 1) + '</span>' +
        '<span><span class="n">' + E(b.n) + '</span><span class="s">' + E(b.stance) + '</span>' +
        '<span class="d">' + E(b.note) + '</span></span></button>';
    }).join("") + '</div>');

    /* ---- chune hue brand ke liye mauka, apne aankdon se ---- */
    var OP = khOpp(), bsel = BRANDS.filter(function (x) { return x.n === KH.brand; })[0] || BRANDS[0];
    var why = OP.stance === "Sabse upar"
      ? "Ye brand sabse upar rehta hai, isliye kram wahan se shuru hai jahan hamara rate pehle se apne aausat se ooncha hai — wahan ye brand tikta hai."
      : OP.stance === "Market me ladne wala"
      ? "Ye brand ladne ke liye hai, isliye kram wahan se shuru hai jahan hamara rate apne aausat se neeche gir chuka hai — wahin mukabla chal raha hai."
      : "Ye brand hissa badhane ke liye hai, isliye kram wahan se shuru hai jahan maang sabse zyada chhooti — wahan jagah khaali padi hai.";
    h.push('<div class="md-card" style="--mdc:' + bsel.c + ';margin-bottom:14px"><h3>' + E(bsel.n) +
      ' ke liye mauka — hamare apne aankdon se</h3>' +
      '<div class="sub">' + E(why) + ' Hamara kul aausat rate ₹' + nf(Math.round(OP.avg)) + '.</div>' +
      '<table class="pks-d"><thead><tr><th class="l">Rajya</th><th>Hamara maal Qtl</th><th>Hamara rate ₹</th>' +
      '<th>Aausat se</th><th>Maang chhooti Qtl</th><th>Party</th></tr></thead><tbody>' +
      OP.L.slice(0, 6).map(function (r) {
        return '<tr><td class="l"><b>' + E(r.k) + '</b></td><td>' + nf(r.q) + '</td><td>' + nf(Math.round(r.rate)) + '</td>' +
          '<td style="color:' + (r.gap >= 0 ? "#1f6f6a" : "#a8422f") + ';font-weight:600">' +
          (r.gap >= 0 ? "+" : "−") + Math.abs(r.gap).toFixed(1) + '%</td>' +
          '<td style="color:' + (r.lost ? "#a8422f" : "var(--pks-mut)") + '">' + nf(r.lost) + '</td>' +
          '<td>' + r.n + '</td></tr>';
      }).join("") + '</tbody></table></div>');

    h.push('<div class="kh-grid">');

    /* ---- hamara apna ---- */
    h.push('<div class="md-card" style="--mdc:#1f6f6a"><h3>Hamara maal kahan chalta hai</h3>' +
      '<div class="sub">' + ml(M[0]) + ' se ' + ml(M[M.length - 1]) + ' tak ke apne bill se. Har maal ke saamne ' +
      'hamara aausat rate aur jin teen rajya me sabse zyada gaya.</div>' +
      '<table class="pks-d"><thead><tr><th class="l">Maal</th><th>Qtl</th><th>Hamara rate ₹</th>' +
      '<th class="l">Sabse bade rajya</th></tr></thead><tbody>' +
      O.map(function (r) {
        return '<tr><td class="l"><b>' + E(r.item) + '</b></td><td>' + nf(r.q) + '</td>' +
          '<td><b>' + nf(Math.round(r.rate)) + '</b></td>' +
          '<td class="l">' + r.top.slice(0, 3).map(function (s2) {
            return E(s2.k) + ' <span style="color:var(--pks-mut)">(' + nf(s2.q) + ' Qtl · ₹' + nf(Math.round(s2.rate)) + ')</span>';
          }).join("<br>") + '</td></tr>';
      }).join("") + '</tbody></table></div>');

    /* ---- AI wala ---- */
    h.push('<div class="md-card" style="--mdc:#2c5f8a"><h3>Bahar bazaar me kya chal raha hai</h3>');
    if (KH.err) {
      h.push('<div class="kh-err"><b>Khabar nahi aa payi.</b><br>' + E(KH.err) + '</div>' +
        '<div class="md-do">Ye tab tabhi chalta hai jab is page ko AI se baat karne ki ijazat mili ho. ' +
        'ERP me lagane ke liye aapke server par ek chhota rasta (API proxy) banana hoga — ' +
        'software team ko kahiye, aadhe din ka kaam hai. Tab tak baayen taraf ka apna hisaab poora chalta rahega.</div>');
    } else if (KH.busy) {
      h.push('<div class="kh-wait"><span class="kh-dot"></span><span class="kh-dot"></span><span class="kh-dot"></span>' +
        '<div>Bazaar ki khabar dhoondhi ja rahi hai — mandi bhaav, brand aur maang. Thoda samay lagta hai.</div></div>');
    } else if (!KH.out) {
      h.push('<div class="sub">Abhi tak khabar mangwayi nahi gayi. Upar wala button dabaiye — AI web par dhoondh kar ' +
        'in cheezon ka jawab laayega:</div>' +
        '<div class="md-row"><span class="nm">Hamare maal ka aaj ka mandi bhaav, rajya ke hisaab se</span></div>' +
        '<div class="md-row"><span class="nm">Kis brand ya kis mill ka us ilaake me zor hai</span></div>' +
        '<div class="md-row"><span class="nm">Maang badh rahi hai ya gir rahi hai, aur kyun</span></div>' +
        '<div class="md-row"><span class="nm">Hamare rate ke saamne bazaar ka rate — upar ya neeche</span></div>');
    } else {
      var o = KH.out;
      if (o.saar) h.push('<div class="kh-saar">' + E(o.saar) + '</div>');
      if (o.bazaar && o.bazaar.length) {
        h.push('<table class="pks-d"><thead><tr><th class="l">Rajya</th><th class="l">Maal</th>' +
          '<th class="l">Bazaar ka bhaav</th><th class="l">Kiska zor</th><th class="l">Haal</th></tr></thead><tbody>' +
          o.bazaar.map(function (x) {
            return '<tr><td class="l"><b>' + E(x.rajya || "—") + '</b></td><td class="l">' + E(x.maal || "—") + '</td>' +
              '<td class="l">' + E(x.bhaav || "—") + '</td><td class="l">' + E(x.brand || "—") + '</td>' +
              '<td class="l">' + E(x.haal || "—") + '</td></tr>';
          }).join("") + '</tbody></table>');
      }
      if (o.chaal) {
        var cc = o.chaal, bs = BRANDS.filter(function (x) { return x.n === KH.brand; })[0] || BRANDS[0];
        h.push('<div class="kh-chaal" style="--bc:' + bs.c + '"><div class="t">' + E(cc.brand || KH.brand) +
          ' ki chaal <span>' + E(bs.stance) + '</span></div>' +
          [["Mukabla kaise", cc.mukabla], ["Supply kaise", cc.supply], ["Rate ki rannneeti", cc.rate], ["Shuru kahan se", cc.kahan]]
            .filter(function (p) { return p[1]; })
            .map(function (p) { return '<div class="kc"><div class="k">' + p[0] + '</div><div class="v">' + E(p[1]) + '</div></div>'; }).join("") +
          (cc.kadam && cc.kadam.length
            ? '<div class="kc"><div class="k">Kadam</div><div class="v">' +
              cc.kadam.map(function (k) { return '<div class="kd">' + E(k) + '</div>'; }).join("") + '</div></div>' : '') +
          '</div>');
      }
      if (o.brands && o.brands.length) {
        h.push('<div style="margin-top:14px"><h4 style="margin:0 0 5px 0;font-size:12.5px">Hamare brand bazaar me</h4>' +
          '<table class="pks-d"><thead><tr><th class="l">Brand</th><th class="l">Kahan dikhta hai</th>' +
          '<th class="l">Kitna area</th><th class="l">Saamne kaun</th><th class="l">Bhaav</th><th class="l">Kya kijiye</th></tr></thead><tbody>' +
          o.brands.map(function (x) {
            var b = null;
            BRANDS.forEach(function (y) { if (String(x.brand || "").toUpperCase().indexOf(y.n) >= 0) b = y; });
            return '<tr><td class="l"><b style="color:' + (b ? b.c : "var(--pks-text)") + '">' + E(x.brand || "—") + '</b>' +
              (b ? '<span class="pks-who">' + E(b.stance) + '</span>' : '') + '</td>' +
              '<td class="l">' + E(x.kahan || "—") + '</td><td class="l">' + E(x.kitna || "—") + '</td>' +
              '<td class="l">' + E(x.mukabla || "—") + '</td>' +
              '<td class="l">' + E(x.bhaav || "—") + '</td><td class="l">' + E(x.kijiye || "—") + '</td></tr>';
          }).join("") + '</tbody></table></div>');
      }
      if (o.kijiye && o.kijiye.length) {
        h.push('<div style="margin-top:12px"><h4 style="margin:0 0 4px 0;font-size:12.5px">Iska matlab hamare liye</h4>' +
          o.kijiye.map(function (k) { return '<div class="md-row"><span class="nm">' + E(k) + '</span></div>'; }).join("") + '</div>');
      }
      h.push('<div class="md-do">Ye khabar web se aayi hai, hamare bahi-khate se nahi. Sauda karne se pehle ' +
        'apne broker se bhaav confirm kar lijiye.</div>');
    }
    h.push('</div></div>');
    return h.join("");
  }

  /* ---- AI se poochhna ---- */
  function khAsk() {
    KH.busy = false;
    KH.err = "External market feed ERP me configured nahi hai. Baayen taraf ke live ERP trends upalabdh hain.";
    paint();
  }

  /* ============================================================
     RATE KI CHAAL — do cheezein ek saath:
     (1) EX PLANT aur FOR ka farak — dono ka rate seedha jodna galat hai
     (2) Har mandi/ilaake ke liye aage ki chaal — kitna upar, kitna neeche
     ============================================================ */
  var CH = { basis: "sab", moves: {}, mkt: {} };

  function chRate(x) {
    // FOR wale bill me bhaada rate ke andar chhupa hai — use nikal kar hi tulna hoti hai
    var q = +x.qty || 0; if (!q) return 0;
    var r = (+x.total || 0) / q;
    return (x.basis === "FOR") ? r - (+x.bhaada || 0) : r;
  }
  function chPass(x) {
    if (CH.basis === "sab") return true;
    return (x.basis || "EX PLANT") === (CH.basis === "ex" ? "EX PLANT" : "FOR");
  }

  function chAgg() {
    var IX = PKS.idx(), M = months(), a = M[0], b = M[M.length - 1], R = {};
    var G = { q: 0, v: 0, vn: 0, n: 0, ex: 0, fo: 0, bhaada: 0 };
    (IX.raw.invoices || []).forEach(function (x) {
      var p = IX.parties[PKS.clean(x.party)]; if (!p || p.internal) return;
      var m = PKS.monOf(x.dt); if (m < a || m > b) return;
      if (!chPass(x)) return;
      if (S.q && (p.name + " " + (p.broker || "") + " " + (p.city || "") + " " + (p.state || "") + " " + x.item).toUpperCase().indexOf(S.q.toUpperCase()) < 0) return;
      var q = +x.qty || 0, v = +x.total || 0, net = chRate(x) * q;
      var k = p.city || p.state || "—";
      var r = R[k] || (R[k] = { k: k, state: p.state || "", q: 0, v: 0, vn: 0, n: 0, parties: {}, dq: 0 });
      r.q += q; r.v += v; r.vn += net; r.n++; r.parties[p.c] = 1;
      G.q += q; G.v += v; G.vn += net; G.n++;
      if ((x.basis || "EX PLANT") === "FOR") { G.fo++; G.bhaada += (+x.bhaada || 0) * q; } else G.ex++;
    });
    (IX.raw.demand || []).forEach(function (x) {
      var m = PKS.monOf(x.dt); if (m < a || m > b) return;
      var k = x.city || x.state || "—";
      if (R[k]) R[k].dq += +x.qty || 0;
    });
    var avg = G.q ? G.vn / G.q : 0;
    var L = Object.keys(R).map(function (k) {
      var r = R[k];
      r.rate = r.q ? r.vn / r.q : 0;
      r.gap = avg ? (r.rate - avg) / avg * 100 : 0;
      r.lost = Math.max(0, r.dq - r.q);
      r.np = Object.keys(r.parties).length;
      return r;
    }).sort(function (x, y) { return y.q - x.q; });
    return { L: L, G: G, avg: avg };
  }

  function chAdvice(r) {
    if (r.gap >= 2 && r.q > 0) return { t: "Yahan taakat hai — rate upar le jaana hai", c: "#1f6f6a", m: [50, 50, 50] };
    if (r.gap <= -2) return { t: "Yahan ladna hai — rate neeche karke jagah banani hai", c: "#a8422f", m: [-50, -50, 0] };
    if (r.lost > r.q * 0.5) return { t: "Maang chhoot rahi hai — pehle maal, phir rate", c: "#c9a227", m: [0, 25, 25] };
    return { t: "Abhi haath rokiye — rate hilane ki zaroorat nahi", c: "#2c5f8a", m: [0, 0, 0] };
  }

  function chHtml() {
    var A = chAgg(), M = months();
    var h = [];

    /* ---- basis ka chunav ---- */
    h.push('<div class="pks-shead"><div><h2>Rate ki chaal</h2>' +
      '<p>Kis mandi me rate upar le jaana hai, kis me ladna hai — aur kitna</p>' +
      '<div class="pks-hint">Pehle <b>EX PLANT</b> aur <b>FOR</b> alag kijiye. FOR wale bill me bhaada rate ke andar ' +
      'chhupa hota hai, isliye dono ka rate seedha jodne se aausat galat banta hai. Neeche har mandi ka rate ' +
      '<b>bhaada nikal kar</b> (ex-plant ke barabar) dikhaya gaya hai.</div></div>' +
      '<span class="pks-seg"><button data-chb="sab" class="' + (CH.basis === "sab" ? "on" : "") + '">Sab</button>' +
      '<button data-chb="ex" class="' + (CH.basis === "ex" ? "on" : "") + '">EX PLANT</button>' +
      '<button data-chb="for" class="' + (CH.basis === "for" ? "on" : "") + '">FOR</button></span></div>');

    /* ---- KPI ---- */
    var G = A.G, grossRate = G.q ? G.v / G.q : 0;
    h.push('<div class="md-kpis">' +
      '<div class="md-kpi"><div class="k">Maal bika</div><div class="v">' + nf(G.q) + '</div><div class="s">Qtl · ' + G.n + ' saude</div></div>' +
      '<div class="md-kpi"><div class="k">Rakam</div><div class="v">₹' + rf(G.v) + '</div><div class="s">bill ka jod</div></div>' +
      '<div class="md-kpi"><div class="k">Aausat rate — bhaada nikal kar</div><div class="v" style="color:var(--pks-copper)">₹' + nf(Math.round(A.avg)) + '</div>' +
      '<div class="s">bill par dikhta ₹' + nf(Math.round(grossRate)) + '</div></div>' +
      '<div class="md-kpi"><div class="k">Kis basis par</div><div class="v" style="font-size:19px">' + G.ex + ' <span style="font-size:12px;color:var(--pks-mut)">EX PLANT</span> · ' +
      G.fo + ' <span style="font-size:12px;color:var(--pks-mut)">FOR</span></div>' +
      '<div class="s">FOR ka bhaada ₹' + rf(G.bhaada) + '</div></div></div>');

    if (CH.basis === "sab" && G.ex && G.fo) {
      h.push('<div class="ch-warn"><b>Milaate waqt dhyan</b> — ' + G.ex + ' bill <b>EX PLANT</b> hain, unka bhaada grahak ne diya ' +
        'aur wo hamare bill me hai hi nahi. ' + G.fo + ' bill <b>FOR</b> hain, jinme bhaada hamara hai — kul ₹' + rf(G.bhaada) + '. ' +
        'Isliye dono ka rate seedha jodkar aausat nikalna theek nahi. Upar ka aausat bhaada nikal kar banaya gaya hai; ' +
        'saaf tasveer ke liye upar se ek hi tarah ka saoda chunkar dekhiye.</div>');
    }

    /* ---- mandi ki chaal ---- */
    h.push('<div class="pks-scroll"><table class="pks-t" id="pksChTable" style="font-size:' + (12.5 * S.zoom / 100).toFixed(2) + 'px">' +
      '<thead><tr><th class="pks-sticky-m l">MANDI<small>neeche rajya aur party</small></th>' +
      '<th>HAMARA RATE</th><th>AAUSAT SE</th><th>BIKA QTL</th><th>MAANG CHHOOTI</th>' +
      '<th>BAZAAR KA RATE</th><th>PEHLI</th><th>DOOSRI</th><th>TEESRI</th><th>KUL ASAR</th><th>NAYA RATE</th>' +
      '<th class="l">KYA KARNA HAI</th></tr></thead><tbody>');

    A.L.slice(0, 25).forEach(function (r) {
      var ad = chAdvice(r);
      var mv = CH.moves[r.k] || (CH.moves[r.k] = ad.m.slice());
      var tot = mv.reduce(function (s, x) { return s + (+x || 0); }, 0);
      var nay = Math.round(r.rate + tot);
      var mkt = CH.mkt[r.k];
      h.push('<tr><td class="pks-sticky-m"><span class="pks-maal" data-bzr="' + E(r.k) + '">' + E(r.k) + '</span>' +
        '<span class="pks-maal-v" style="color:var(--pks-mut)">' + E(r.state || "—") + ' · ' + r.np + ' party</span></td>' +
        '<td class="num"><b>₹' + nf(Math.round(r.rate)) + '</b></td>' +
        '<td class="num" style="color:' + (r.gap >= 0 ? "#1f6f6a" : "#a8422f") + ';font-weight:600">' +
        (r.gap >= 0 ? "+" : "−") + Math.abs(r.gap).toFixed(1) + '%</td>' +
        '<td class="num">' + nf(r.q) + '</td>' +
        '<td class="num" style="color:' + (r.lost ? "#a8422f" : "var(--pks-mut)") + '">' + (r.lost ? nf(r.lost) : "—") + '</td>' +
        '<td class="num"><input class="tg-in ch-mkt" data-chm="' + E(r.k) + '" value="' + (mkt || "") + '" placeholder="?" style="width:74px"></td>' +
        [0, 1, 2].map(function (i) {
          return '<td class="num"><input class="tg-in ch-mv" data-chv="' + E(r.k) + '" data-chi="' + i + '" value="' + mv[i] + '" style="width:62px"></td>';
        }).join("") +
        '<td class="num" style="color:' + (tot > 0 ? "#1f6f6a" : tot < 0 ? "#a8422f" : "var(--pks-mut)") + ';font-weight:700">' +
        (tot > 0 ? "+" : tot < 0 ? "−" : "") + (tot ? nf(Math.abs(tot)) : "0") + '</td>' +
        '<td class="num"><b>₹' + nf(nay) + '</b>' +
        (mkt ? '<span class="pks-who">bazaar se ' + (nay - mkt >= 0 ? "+" : "−") + nf(Math.abs(nay - mkt)) + '</span>' : '') + '</td>' +
        '<td><span class="ch-ad" style="color:' + ad.c + '">' + ad.t + '</span></td></tr>');
    });

    var GT = 0, GQ = 0;
    A.L.slice(0, 25).forEach(function (r) {
      var mv = CH.moves[r.k] || [0, 0, 0];
      GT += mv.reduce(function (s, x) { return s + (+x || 0); }, 0) * r.q; GQ += r.q;
    });
    h.push('</tbody><tfoot><tr class="pks-foot"><td class="pks-sticky-m">KUL JOD · ' + Math.min(25, A.L.length) + ' mandi</td>' +
      '<td class="num">₹' + nf(Math.round(A.avg)) + '</td><td></td><td class="num">' + nf(G.q) + '</td><td></td><td></td>' +
      '<td colspan="3" style="text-align:right">In chaalon ka asar</td>' +
      '<td class="num">' + (GQ ? (GT / GQ >= 0 ? "+" : "−") + nf(Math.abs(Math.round(GT / GQ))) : "0") + '</td>' +
      '<td class="num">₹' + rf(GT) + '</td>' +
      '<td>itni rakam ka farak padega</td></tr></tfoot></table></div>');

    h.push('<div class="ch-note"><b>Chaal kaise padhi jaye</b> — har mandi ke saamne teen khaane hain: pehli, doosri, teesri chaal. ' +
      'Inme rupaye me badlaav likhiye (+50 matlab rate pachaas upar, −100 matlab sau neeche, 0 matlab wahan haath nahi lagana). ' +
      'Table turant bata dega ki naya rate kya hoga aur poore maal par kitni rakam ka farak padega. ' +
      'Bazaar ka rate bhar dijiye to saath hi dikh jayega ki hum bazaar se upar hain ya neeche. ' +
      'Shuruaat ki chaal khud bhar jati hai — jahan hamara rate aausat se ooncha hai wahan upar, jahan neecha hai wahan ladne wali.</div>');
    return h.join("");
  }

  /* ============================================================
     ROZ KA KAAM — bharne wala panna.
     Kis aadmi ko kaunsi mandi ka, kaunse maal ka rate bharna hai — aur bhara ya nahi.
     Bhara hua rate seedha "Rate ki chaal" ke bazaar wale khaane me chala jata hai.
     ============================================================ */
  var RQ = { dt: null, user: "sab", log: {}, note: {} };

  function rqToday() {
    if (RQ.dt) return RQ.dt;
    var IX = PKS.idx(), last = 0;
    (IX.raw.invoices || []).forEach(function (x) { if (x.dt > last) last = x.dt; });
    RQ.dt = last || 20260911;
    return RQ.dt;
  }

  /* kiska kaam kya — broker ke neeche uski mandi aur wahan ka maal */
  function rqRows() {
    var IX = PKS.idx(), M = months(), a = M[0], b = M[M.length - 1], R = {};
    (IX.raw.invoices || []).forEach(function (x) {
      var p = IX.parties[PKS.clean(x.party)]; if (!p || p.internal) return;
      var m = PKS.monOf(x.dt); if (m < a || m > b) return;
      var who = p.broker || "(broker nahi)", mandi = p.city || p.state || "—";
      var k = who + "\u00a7" + mandi + "\u00a7" + x.item;
      var r = R[k] || (R[k] = { k: k, who: who, mandi: mandi, state: p.state || "", item: x.item, q: 0, v: 0, vn: 0, last: 0 });
      var q = +x.qty || 0;
      r.q += q; r.v += +x.total || 0; r.vn += chRate(x) * q;
      if (x.dt > r.last) r.last = x.dt;
    });
    var L = Object.keys(R).map(function (k) { var r = R[k]; r.rate = r.q ? r.vn / r.q : 0; return r; });
    L.sort(function (x, y) { return x.who.localeCompare(y.who) || y.q - x.q; });
    return L;
  }

  function rqKey(r) { return rqToday() + "|" + r.mandi + "|" + r.item; }
  function rqPrev(r) {
    // pichhli baar jo bhara gaya (koi bhi purani tareekh)
    var best = null;
    Object.keys(RQ.log).forEach(function (k) {
      var p = k.split("|");
      if (p[1] === r.mandi && p[2] === r.item && +p[0] < rqToday()) {
        if (!best || +p[0] > +best.split("|")[0]) best = k;
      }
    });
    return best ? { dt: +best.split("|")[0], v: RQ.log[best] } : null;
  }

  function rqHtml() {
    var L = rqRows();
    var users = {};
    L.forEach(function (r) { users[r.who] = (users[r.who] || 0) + 1; });
    var uk = Object.keys(users).sort();
    var mine = L.filter(function (r) { return RQ.user === "sab" || r.who === RQ.user; });
    var done = mine.filter(function (r) { return RQ.log[rqKey(r)]; }).length;
    var pct = mine.length ? Math.round(done / mine.length * 100) : 0;

    var h = [];
    h.push('<div class="pks-shead"><div><h2>Roz ka kaam</h2>' +
      '<p>Kis aadmi ko kaunsi mandi ka, kaunse maal ka rate bharna hai — aur aaj bhara ya nahi</p>' +
      '<div class="pks-hint">Har line ek <b>mandi aur maal</b> ki jodi hai, aur wo usi ke naam par hai jiska wahan kaam chalta hai. ' +
      'Aaj ka bazaar rate bhariye — table turant bata dega ki hamara rate uske upar hai ya neeche. ' +
      'Bhara hua rate seedha <b>Rate ki chaal</b> wale panne me chala jata hai.</div></div>' +
      '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">' +
      '<span class="pks-lab">TAREEKH</span>' +
      '<input type="date" class="pks-sel" id="pksRqDt" value="' + PKS.dstr(rqToday()).split("-").reverse().join("-") + '">' +
      '<span class="pks-lab">KISKA KAAM</span>' +
      '<select class="pks-sel" id="pksRqU"><option value="sab"' + (RQ.user === "sab" ? " selected" : "") + '>Sab ka (' + L.length + ')</option>' +
      uk.map(function (u) {
        return '<option value="' + E(u) + '"' + (RQ.user === u ? " selected" : "") + '>' + E(u) + ' (' + users[u] + ')</option>';
      }).join("") + '</select></div></div>');

    /* ---- kiska kitna kaam ---- */
    h.push('<div class="rq-who">' + uk.map(function (u) {
      var all = L.filter(function (r) { return r.who === u; });
      var dn = all.filter(function (r) { return RQ.log[rqKey(r)]; }).length;
      var p2 = all.length ? Math.round(dn / all.length * 100) : 0;
      return '<button class="rq-w' + (RQ.user === u ? " on" : "") + '" data-rqu="' + E(u) + '">' +
        '<span class="n">' + E(u) + '</span>' +
        '<span class="c">' + dn + ' / ' + all.length + ' bhara</span>' +
        '<span class="t"><i style="width:' + p2 + '%;background:' + (p2 === 100 ? "#1f6f6a" : p2 >= 50 ? "#c9a227" : "#a8422f") + '"></i></span></button>';
    }).join("") + '</div>');

    h.push('<div class="rq-bar"><div class="l">' + (RQ.user === "sab" ? "Sab ka kaam" : E(RQ.user) + " ka kaam") +
      ' — <b>' + done + '</b> me se <b>' + mine.length + '</b> line bhari</div>' +
      '<div class="t"><i style="width:' + pct + '%"></i></div><div class="p">' + pct + '%</div></div>');

    h.push('<div class="pks-scroll"><table class="pks-t" id="pksRqTable" style="font-size:' + (12.5 * S.zoom / 100).toFixed(2) + 'px">' +
      '<thead><tr><th class="pks-sticky-m l">MANDI · MAAL<small>neeche kiska kaam</small></th>' +
      '<th>HAMARA RATE</th><th>AAJ KA BAZAAR RATE</th><th>FARAK</th><th class="l">PICHHLI BAAR</th>' +
      '<th class="l">NOTE</th><th class="l">HAAL</th></tr></thead><tbody>');

    mine.forEach(function (r) {
      var k = rqKey(r), v = RQ.log[k], prev = rqPrev(r);
      var diff = v ? Math.round(r.rate - v) : null;
      h.push('<tr><td class="pks-sticky-m"><span class="pks-maal" data-bzr="' + E(r.mandi) + '">' + E(r.mandi) + ' · ' + E(r.item) + '</span>' +
        '<span class="pks-maal-v" style="color:var(--pks-mut)">' + E(r.who) + ' · ' + nf(r.q) + ' Qtl ab tak</span></td>' +
        '<td class="num"><b>₹' + nf(Math.round(r.rate)) + '</b></td>' +
        '<td class="num"><input class="tg-in rq-in" data-rqk="' + E(k) + '" value="' + (v || "") + '" placeholder="bhariye" style="width:88px"></td>' +
        '<td class="num" style="color:' + (diff === null ? "var(--pks-mut)" : diff >= 0 ? "#1f6f6a" : "#a8422f") + ';font-weight:700">' +
        (diff === null ? "—" : (diff >= 0 ? "+" : "−") + nf(Math.abs(diff))) + '</td>' +
        '<td class="l">' + (prev ? '₹' + nf(prev.v) + ' <span style="color:var(--pks-mut)">(' + PKS.dstr(prev.dt) + ')</span>' +
          (v ? ' <b style="color:' + (v >= prev.v ? "#1f6f6a" : "#a8422f") + '">' + (v >= prev.v ? "▲" : "▼") + nf(Math.abs(v - prev.v)) + '</b>' : '')
          : '<span style="color:var(--pks-mut)">pehli baar</span>') + '</td>' +
        '<td class="l"><input class="tg-in rq-nt" data-rqn="' + E(k) + '" value="' + E(RQ.note[k] || "") + '" placeholder="kuch kehna ho to" style="width:150px;text-align:left"></td>' +
        '<td class="l">' + (v
          ? '<span class="pks-chip" style="background:#1f6f6a">Bhar diya</span>'
          : '<span class="pks-chip" style="background:#a8422f">Baaki hai</span>') + '</td></tr>');
    });
    if (!mine.length) h.push('<tr><td colspan="7" class="pks-empty">Is aadmi ke naam koi mandi nahi</td></tr>');
    h.push('</tbody></table></div>');

    h.push('<div class="ch-note"><b>Ye panna kaise chalta hai</b> — har mandi-maal ki jodi us aadmi ke naam par jaati hai ' +
      'jiska wahan kaam chal raha hai; ye naam bill se apne aap nikalta hai, alag se kisi ko baithna nahi padta. ' +
      'Upar wali goliyon se dekh sakte hain ki kisne kitna bhara — jo laal hai, uska kaam baaki hai. ' +
      'Rate bharte hi <b>farak</b> ka khaana bata deta hai ki hamara rate bazaar se upar hai ya neeche, aur ' +
      '<b>pichhli baar</b> wala khaana batata hai ki bazaar us din se kitna hila. ' +
      'Abhi ye bhara hua aankda is session tak rehta hai — ERP me jodne par ek chhoti table chahiye: ' +
      'tareekh, mandi, maal, rate, bharne wala, aur note.</div>');
    return h.join("");
  }

  /* ---------- main paint ---------- */
  function paint() {
    paintTabs(); paintBars(); paintBoxes();
    var main = document.getElementById("pksMain"), rows = [];
    if (S.tab === "chhoot") { main.innerHTML = panelsHtml(); }
    else if (S.tab === "kyun") { main.innerHTML = reasonsHtml(); }
    else if (S.tab === "md") { main.innerHTML = mdHtml(); }
    else if (S.tab === "bazaar") { main.innerHTML = bzHtml(); }
    else if (S.tab === "maang") { main.innerHTML = mgHtml(); }
    else if (S.tab === "khabar") { main.innerHTML = khHtml(); }
    else if (S.tab === "roz") {
      main.innerHTML = rqHtml();
      [].forEach.call(document.querySelectorAll(".rq-in"), function (el) {
        el.addEventListener("change", function () {
          var k = this.getAttribute("data-rqk"), v = Math.round(+String(this.value).replace(/[^0-9.]/g, "") || 0);
          if (v > 0) RQ.log[k] = v; else delete RQ.log[k];
          // bhara hua rate seedha Rate ki chaal ke bazaar khaane me
          var mandi = k.split("|")[1], sum = 0, n = 0;
          Object.keys(RQ.log).forEach(function (k2) {
            var p = k2.split("|");
            if (p[1] === mandi && +p[0] === rqToday()) { sum += RQ.log[k2]; n++; }
          });
          if (n) CH.mkt[mandi] = Math.round(sum / n);
          paint();
        });
      });
      [].forEach.call(document.querySelectorAll(".rq-nt"), function (el) {
        el.addEventListener("change", function () { RQ.note[this.getAttribute("data-rqn")] = this.value; });
      });
      var du = document.getElementById("pksRqU");
      if (du) du.addEventListener("change", function () { RQ.user = this.value; paint(); });
      var dd = document.getElementById("pksRqDt");
      if (dd) dd.addEventListener("change", function () { RQ.dt = +String(this.value).replace(/-/g, "") || RQ.dt; paint(); });
    }
    else if (S.tab === "chaal") {
      main.innerHTML = chHtml();
      [].forEach.call(document.querySelectorAll(".ch-mv"), function (el) {
        el.addEventListener("change", function () {
          var k = this.getAttribute("data-chv"), i = +this.getAttribute("data-chi");
          CH.moves[k] = CH.moves[k] || [0, 0, 0];
          CH.moves[k][i] = Math.round(+String(this.value).replace(/[^0-9.\-]/g, "") || 0);
          paint();
        });
      });
      [].forEach.call(document.querySelectorAll(".ch-mkt"), function (el) {
        el.addEventListener("change", function () {
          var v = +String(this.value).replace(/[^0-9.]/g, "");
          CH.mkt[this.getAttribute("data-chm")] = v > 0 ? v : 0;
          paint();
        });
      });
    }
    else if (S.tab === "ishaare") {
      main.innerHTML = sgHtml();
      [].forEach.call(document.querySelectorAll("input[data-tg]"), function (el) {
        el.addEventListener("change", function () {
          var v = +String(this.value).replace(/[^0-9.]/g, "");
          SG.tgt[this.getAttribute("data-tg")] = v > 0 ? v : 0;
          paint();
        });
      });
    }
    else {
      rows = rowsFor(S.tab);
      main.innerHTML = heatTable(rows, { broker: S.tab === "broker" }) + itemTable(S.tab === "apni") + rateTable(S.tab === "apni");
      var ri = document.getElementById("pksRtItem");
      if (ri) ri.addEventListener("change", function () { RT.item = this.value; paint(); });
    }
    sgTimer(S.tab === "ishaare");
    document.getElementById("pksCount").textContent =
      (S.tab === "roz" ? (document.querySelectorAll("#pksRqTable tbody tr").length + " line bharni hai") : S.tab === "chaal" ? (document.querySelectorAll("#pksChTable tbody tr").length + " mandi · rate ki chaal") : S.tab === "khabar" ? "apna aankda + bahar ki khabar" : S.tab === "maang" ? (document.querySelectorAll("#pksMgTable tbody tr").length + " maal · maang ke saamne bikri") : S.tab === "ishaare" ? ((SG.list || []).length + " ishaare · har 5 second me agla panna") : S.tab === "bazaar" ? (document.querySelectorAll("#pksBzTable tbody tr").length + " ilaaka" + (BZ.mon ? " · " + ml(BZ.mon) : "")) : S.tab === "md" ? "poora dhandha ek nazar me" : S.tab === "kyun" ? "kaaran ke hisaab se" : S.tab === "chhoot" ? "chaar panel" : rows.length + " line dikh rahi hai") +
      (S.tab === "apni" ? " · apni company alag hai (§9)" : "");
    document.getElementById("pksZoomVal").textContent = S.zoom + "%";
  }

  /* ============================================================
     EVENTS
     ============================================================ */
  function on(id, ev, fn) { document.getElementById(id).addEventListener(ev, fn); }

  document.addEventListener("click", function (e) {
    var t = e.target.closest ? e.target.closest("[data-tab],[data-y],[data-v],[data-st],[data-r],[data-open],[data-im],[data-xls],[data-sk],[data-rt],[data-rk],[data-rrow],[data-blink],[data-rtdemo],[data-grp],[data-rtall],[data-bza],[data-bzb],[data-bzm],[data-bzr],[data-sg],[data-sgi],[data-mgi],[data-kh],[data-khb],[data-chb],[data-rqu],[data-item],td.pks-cell,[data-mode]") : null;
    if (!t) return;
    if (t.hasAttribute("data-im")) { IM.mode = t.getAttribute("data-im"); paint(); return; }
    if (t.hasAttribute("data-rt")) {
      RT.mode = t.getAttribute("data-rt"); RT.sk = "avg"; RT.dir = -1;
      if (RT.mode === "dono" && !Object.keys(RT.open).length) RT.openFirst = true;
      paint(); return;
    }
    if (t.hasAttribute("data-grp")) {
      var gk = t.getAttribute("data-grp");
      if (RT.open[gk]) delete RT.open[gk]; else RT.open[gk] = 1;
      paint(); return;
    }
    if (t.hasAttribute("data-rqu")) { RQ.user = (RQ.user === t.getAttribute("data-rqu")) ? "sab" : t.getAttribute("data-rqu"); paint(); return; }
    if (t.hasAttribute("data-chb")) { CH.basis = t.getAttribute("data-chb"); paint(); return; }
    if (t.hasAttribute("data-kh")) { khAsk(); return; }
    if (t.hasAttribute("data-khb")) { KH.brand = t.getAttribute("data-khb"); KH.out = null; paint(); return; }
    if (t.hasAttribute("data-mgi")) { mgDrill(t.getAttribute("data-mgi"), t.getAttribute("data-mgm") ? +t.getAttribute("data-mgm") : null); return; }
    if (t.hasAttribute("data-sg")) {
      var act = t.getAttribute("data-sg");
      if (act === "next") sgTick(1);
      else if (act === "prev") sgTick(-1);
      else { SG.paused = !SG.paused; paint(); return; }
      sgTimer(true); return;
    }
    if (t.hasAttribute("data-sgi")) { SG.i = +t.getAttribute("data-sgi"); sgTick(0); sgTimer(true); return; }
    if (t.hasAttribute("data-bza")) { BZ.area = t.getAttribute("data-bza"); paint(); return; }
    if (t.hasAttribute("data-bzb")) { BZ.base = t.getAttribute("data-bzb"); if (BZ.base === "mon") BZ.mon = null; paint(); return; }
    if (t.hasAttribute("data-bzm")) {
      var bm = t.getAttribute("data-bzm");
      BZ.mon = (bm === "all") ? null : +bm;
      paint(); return;
    }
    if (t.hasAttribute("data-bzr")) { bzDrill(t.getAttribute("data-bzr"), t.getAttribute("data-bzc") || null); return; }
    if (t.hasAttribute("data-rtall")) { RT.allOpen = !RT.allOpen; RT.open = {}; RT.openAllNow = RT.allOpen; paint(); return; }
    if (t.hasAttribute("data-blink")) { RT.blink = !RT.blink; paint(); return; }
    if (t.hasAttribute("data-rtdemo")) { demoAmend(); return; }
    if (t.hasAttribute("data-rk")) {
      var rk = t.getAttribute("data-rk");
      if (RT.sk === rk) RT.dir = -RT.dir; else { RT.sk = rk; RT.dir = (rk === "label") ? 1 : -1; }
      paint(); return;
    }
    if (t.hasAttribute("data-rrow")) {
      rateDrill(t.getAttribute("data-rrow"), t.getAttribute("data-rm") ? +t.getAttribute("data-rm") : null, S.tab === "apni");
      return;
    }
    if (t.hasAttribute("data-sk")) {
      var sk = t.getAttribute("data-sk");
      if (IM.sk === sk) IM.dir = -IM.dir; else { IM.sk = sk; IM.dir = (sk === "item") ? 1 : -1; }
      paint(); return;
    }
    if (t.hasAttribute("data-xls")) { exportXls(t.getAttribute("data-xls")); return; }
    if (t.hasAttribute("data-item")) { PKSD.openItem(t.getAttribute("data-item"), t.getAttribute("data-m") ? +t.getAttribute("data-m") : null, S.tab === "apni"); return; }
    if (t.hasAttribute("data-tab")) { S.tab = t.getAttribute("data-tab"); S.status = null; S.reason = null; paint(); return; }
    if (t.hasAttribute("data-y")) {
      S.year = t.getAttribute("data-y"); S.from = S.to = null;
      if (S.d1) { S.d1 = S.d2 = null; rebuild(); }
      paint(); return;
    }
    if (t.hasAttribute("data-v")) { S.view = t.getAttribute("data-v"); paint(); return; }
    if (t.hasAttribute("data-st")) { var k = t.getAttribute("data-st"); S.status = (S.status === k ? null : k); paint(); return; }
    if (t.hasAttribute("data-r")) { var r = t.getAttribute("data-r"); S.reason = (String(S.reason) === r ? null : r); paint(); return; }
    if (t.hasAttribute("data-open")) { PKSD.open(t.getAttribute("data-open"), months()[months().length - 1], "till"); return; }
    if (t.hasAttribute("data-mode")) { PKSD.setMode(t.getAttribute("data-mode")); return; }
    if (t.classList.contains("pks-cell") && t.getAttribute("data-c")) { PKSD.open(t.getAttribute("data-c"), +t.getAttribute("data-m"), "only"); return; }
  });

  on("pksGo", "click", function () {
    var f = +document.getElementById("pksFrom").value, t = +document.getElementById("pksTo").value;
    if (f > t) { var x = f; f = t; t = x; }
    S.from = f; S.to = t;
    if (S.d1) { S.d1 = S.d2 = null; rebuild(); }
    paint();
  });
  on("pksDtGo", "click", function () {
    var d1 = fromISO(document.getElementById("pksDtFrom").value),
        d2 = fromISO(document.getElementById("pksDtTo").value);
    if (!d1 || !d2) { alert("Dono tareekh bhariye — kis din se kis din tak."); return; }
    if (d1 > d2) { var x = d1; d1 = d2; d2 = x; }
    S.d1 = d1; S.d2 = d2;
    S.from = Math.floor(d1 / 100); S.to = Math.floor(d2 / 100);
    rebuild();
    if (!IX.months.length) {
      alert("In tareekhon ke beech koi kaam nahi mila — doosri tareekh chuniye.");
      S.d1 = S.d2 = null; S.from = S.to = null; rebuild();
    }
    paint();
  });
  on("pksDtClear", "click", function () {
    S.d1 = S.d2 = null; S.from = S.to = null; rebuild(); paint();
  });
  on("pksSearch", "input", function (e) { S.q = e.target.value.trim(); paint(); });
  on("pksZoomIn", "click", function () { S.zoom = Math.min(140, S.zoom + 10); paint(); });
  on("pksZoomOut", "click", function () { S.zoom = Math.max(60, S.zoom - 10); paint(); });
  on("pksFull", "click", function () { document.body.classList.toggle("pks-full"); });
  on("pksXls", "click", function () { exportXls(); });

  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      if (document.getElementById("pksOv").classList.contains("on")) { PKSD.close(); return; }
      if (document.body.classList.contains("pks-full")) { document.body.classList.remove("pks-full"); return; }
      try { if (window.parent && window.parent.pks33Close) { window.parent.pks33Close(); return; } } catch(err){}
    }
    var tg = (e.target && e.target.tagName || "").toUpperCase();
    if (tg === "INPUT" || tg === "TEXTAREA" || tg === "SELECT" || e.ctrlKey || e.altKey || e.metaKey) return;
    if (/^[lbcpsLBCPS]$/.test(e.key) || /^F[123]$/.test(e.key)) {
      try { var P = window.parent; if (P && P !== window && P.pks33Key) { e.preventDefault(); P.pks33Key(e.key); } } catch(err){}
    }
  });

  /* ---------- Excel ---------- */
  function exportXls(id) {
    // upar wali patti ka Excel button us tab ka table uthata hai jo saamne hai
    id = id || (S.tab === "bazaar" ? "pksBzTable" : "pksTable");
    var tbl = document.getElementById(id);
    if (!tbl) { alert("Is tab me table nahi hai — pehle koi table wala tab kholiye."); return; }
    var isItem = (id === "pksItemTable"), isRate = (id === "pksRateTable"), isBz = (id === "pksBzTable");
    var M = months();
    var head = '<table><tr><td colspan="8" style="font:bold 15px Arial">AMBIKAH · REPORTS &amp; MIS — Party ka Safar</td></tr>' +
      '<tr><td colspan="8">' + (isBz ? "Bazaar ka naksha · " +
        (BZ.area === "state" ? "rajya" : BZ.area === "city" ? "shehar" : "pincode") + " × " +
        (BZ.base === "broker" ? "broker" : BZ.base === "mon" ? "mahina" : "maal") +
        (BZ.mon ? " · " + ml(BZ.mon) : "") : isRate ? "Rate ka hisaab · " + (RT.mode === "maal" ? "Maal ka rate" : "Party ka rate") + " · " + (RT.item === "__all__" ? "sab maal" : RT.item) : isItem ? "Maal ka safar · " + IM.mode.toUpperCase() : "Tab: " + TABS.filter(function(x){return x.k===S.tab;})[0].t + " · View: " + V().t) +
      ' · Samay: ' + ml(M[0]) + ' se ' + ml(M[M.length-1]) + '</td></tr><tr><td></td></tr></table>';
    var html = '<html xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="utf-8">' +
      '<style>td,th{border:1px solid #ccc;padding:3px;font:11px Arial} th{background:#111d22;color:#fff}</style></head><body>' +
      head + tbl.outerHTML + '</body></html>';
    var blob = new Blob(["\ufeff" + html], { type: "application/vnd.ms-excel" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = (isBz ? "Bazaar_ka_Naksha_" + BZ.area + "_" + BZ.base : isRate ? "Rate_ka_Hisaab_" + RT.mode : isItem ? "Maal_ka_Safar_" + IM.mode : "Party_ka_Safar_" + S.tab + "_" + S.view) + "_" + M[0] + "-" + M[M.length-1] + ".xls";
    document.body.appendChild(a); a.click(); a.remove();
  }

  /* ---------- boot ---------- */
  PKS.DATA = (window.pksRealData ? window.pksRealData() : PKS.buildDemo());
  IX = PKS.buildIndex(PKS.DATA);
  ALL = IX.months.slice();
  var span = dataSpan();
  ["pksDtFrom", "pksDtTo"].forEach(function (id, i) {
    var el = document.getElementById(id);
    el.min = toISO(span.lo); el.max = toISO(span.hi);
    el.value = toISO(i ? span.hi : span.lo);
  });
  document.getElementById("pksStamp").textContent = new Date().toLocaleDateString("en-IN", { day:"2-digit", month:"short", year:"numeric" });
  window.PKSUI = { S: S, months: months, paint: paint, idx: function () { return IX; }, V: V };
  paint();
})();

/* ============================================================
   PARTY KA SAFAR — drill-down (§10)
   ============================================================ */
var PKSD = (function () {
  "use strict";
  var E = PKS.esc, nf = PKS.nf, qf = PKS.qf, rf = PKS.rf, ml = PKS.monLabel, ds = PKS.dstr;
  var cur = { c: null, mon: null, mode: "till" };

  function scope() {
    var M = PKSUI.months();
    var a = (cur.mode === "only") ? cur.mon : M[0];
    var b = cur.mon;
    return { a: a, b: b, M: M.filter(function (m) { return m >= a && m <= b; }) };
  }
  function match(rec, s) { var m = PKS.monOf(rec.dt); return PKS.clean(rec.party) === cur.c && m >= s.a && m <= s.b; }

  function open(c, mon, mode) {
    var IX = PKS.idx();
    if (String(c).indexOf("B|") === 0) return openBroker(c.slice(2), mon);
    if (!IX.parties[c]) return;
    cur.c = c; cur.mon = mon; cur.mode = mode || "till";
    paint();
    document.getElementById("pksOv").classList.add("on");
  }

  function openBroker(name, mon) {
    var IX = PKS.idx(), M = PKSUI.months();
    var kids = Object.keys(IX.parties).map(function (k) { return IX.parties[k]; })
      .filter(function (p) { return !p.internal && (p.broker || "(broker nahi)") === name; });
    kids.forEach(function (p) { p._t = PKS.sliceOf(p, M); p._s = PKS.statusOf(p, M); });
    kids.sort(function (a, b) { return b._t.val - a._t.val; });
    document.getElementById("pksDName").textContent = name;
    document.getElementById("pksDMeta").textContent = "Broker · " + kids.length + " party · " + ml(M[0]) + " se " + ml(M[M.length - 1]);
    document.getElementById("pksDMon").textContent = "Broker ke neeche ki saari party";
    document.getElementById("pksDBody").innerHTML =
      '<div class="pks-sec"><h4>Is broker ke neeche kaun</h4><table class="pks-d"><thead><tr>' +
      '<th class="l">Party</th><th class="l">Halat</th><th class="l">Thikana</th><th>Order Qtl</th><th>Bikri Qtl</th>' +
      '<th>Bikri ₹</th><th>Paisa ₹</th><th>Kaat ₹</th><th>Bakaya ₹</th></tr></thead><tbody>' +
      kids.map(function (p) {
        var t = p._t, bak = t.val - t.pay - t.cut;
        return '<tr><td class="l"><span class="pks-pname" data-open="' + E(p.c) + '">' + E(p.name) + '</span></td>' +
          '<td class="l"><span class="pks-chip" style="background:' + p._s.color + '">' + p._s.label + '</span></td>' +
          '<td class="l">' + E([p.city, p.state].filter(Boolean).join(", ") || "—") + '</td>' +
          '<td>' + qf(t.oq) + '</td><td>' + qf(t.bq) + '</td><td>' + nf(t.val) + '</td><td>' + nf(t.pay) + '</td>' +
          '<td>' + nf(t.cut) + '</td><td>' + nf(Math.abs(bak)) + PKS.dcTag(bak) + '</td></tr>';
      }).join("") + '</tbody></table></div>';
    document.getElementById("pksOv").classList.add("on");
  }

  function setMode(m) {
    cur.mode = m;
    [].forEach.call(document.querySelectorAll("#pksDMode button"), function (b) {
      b.classList.toggle("on", b.getAttribute("data-mode") === m);
    });
    if (cur.c && String(cur.c).indexOf("B|") !== 0) paint();
  }

  function paint() {
    var IX = PKS.idx(), D = IX.raw, p = IX.parties[cur.c], s = scope();
    var ords = (D.orders || []).filter(function (r) { return match(r, s); }).sort(function (a, b) { return a.dt - b.dt; });
    var invs = (D.invoices || []).filter(function (r) { return match(r, s); }).sort(function (a, b) { return a.dt - b.dt; });
    var recs = (D.receipts || []).filter(function (r) { return match(r, s); }).sort(function (a, b) { return a.dt - b.dt; });
    var nts  = (D.notes || []).filter(function (r) { return match(r, s); }).sort(function (a, b) { return a.dt - b.dt; });

    var t = PKS.sliceOf(p, s.M), st = PKS.statusOf(p, PKSUI.months()), why = PKS.reasonOf(p, PKSUI.months());

    document.getElementById("pksDName").textContent = p.name;
    document.getElementById("pksDMeta").innerHTML =
      E([p.city, p.pin, p.state].filter(Boolean).join(" · ") || "thikana nahi") +
      ' · broker: ' + E(p.broker || "nahi") +
      ' · <span class="pks-chip" style="background:' + st.color + '">' + st.label + '</span>' +
      (p.names.length > 1 ? ' · ' + p.names.length + ' naam jode gaye' : '');
    document.getElementById("pksDMon").textContent =
      (cur.mode === "only" ? "Sirf " + ml(cur.mon) : ml(s.a) + " se " + ml(cur.mon) + " tak");

    var bak = t.val - t.pay - t.cut;
    var h = [];
    h.push('<div class="pks-kpis">' +
      kpi("Bikri", nf(t.bq) + " Qtl") + kpi("Order", nf(t.oq) + " Qtl") +
      kpi("Order me se nikla", t.oq ? Math.round(t.exec) + "%" : "—") +
      kpi("Bakaya", "₹" + nf(Math.abs(bak)) + (bak > 0 ? " Dr" : bak < 0 ? " Cr" : "")) + '</div>');

    h.push('<div class="pks-sec"><h4>Rishta kis haal me</h4>' +
      '<div style="background:#fff;border:1px solid var(--pks-line);border-left:5px solid ' + why.r.color + ';border-radius:5px;padding:9px 12px">' +
      '<div style="font-weight:600;color:' + why.r.color + '">' + E(why.r.text) + '</div>' +
      '<div style="font-size:11.5px;color:var(--pks-mut);margin-top:3px">' + E(why.ev) + '</div>' +
      '<div style="font-size:11.5px;color:var(--pks-copper);margin-top:4px">' + E(why.r.doIt) + '</div></div></div>');

    h.push(tbl("Sales Order", ["Order no","Date","Item","Qty","Rate","Rakam"], ords.map(function (r) {
      return ['<span class="l">' + E(r.ord) + '</span>', ds(r.dt), E(r.item), nf(r.qty), nf(r.rate), nf(r.amount)];
    }), [3,5], ords.reduce(function (a, r) { return a + r.qty; }, 0), ords.reduce(function (a, r) { return a + r.amount; }, 0)));

    h.push(tbl("Invoice (bikri)", ["Invoice no","Date","Item","Qty","Rate","Rakam"], invs.map(function (r) {
      return ['<span class="l">' + E(r.inv) + '</span>', ds(r.dt), E(r.item), nf(r.qty), nf(r.rate), nf(r.total)];
    }), [3,5], invs.reduce(function (a, r) { return a + r.qty; }, 0), invs.reduce(function (a, r) { return a + r.total; }, 0)));

    h.push('<div class="pks-sec"><h4>Paisa aaya</h4><table class="pks-d"><thead><tr><th class="l">Date</th><th>Rakam ₹</th></tr></thead><tbody>' +
      (recs.length ? recs.map(function (r) { return '<tr><td class="l">' + ds(r.dt) + '</td><td>' + nf(r.amount) + '</td></tr>'; }).join("")
        : '<tr><td colspan="2" class="l">Is samay me koi vasooli nahi</td></tr>') +
      '</tbody><tfoot><tr><td class="l">Kul vasooli</td><td>' + nf(t.pay) + '</td></tr></tfoot></table></div>');

    h.push('<div class="pks-sec"><h4>Kaat (CD, weight shortage, quality, TDS)</h4><table class="pks-d"><thead><tr><th class="l">Date</th><th class="l">Kism</th><th>Rakam ₹</th></tr></thead><tbody>' +
      (nts.length ? nts.map(function (r) { return '<tr><td class="l">' + ds(r.dt) + '</td><td class="l">' + E(r.kism) + '</td><td>' + nf(r.amount) + '</td></tr>'; }).join("")
        : '<tr><td colspan="3" class="l">Koi kaat nahi</td></tr>') +
      '</tbody><tfoot><tr><td class="l" colspan="2">Kul kaat</td><td>' + nf(t.cut) + '</td></tr></tfoot></table></div>');

    // khaata
    var run = 0;
    h.push('<div class="pks-sec"><h4>Khaata — mahine dar mahine</h4><table class="pks-d"><thead><tr>' +
      '<th class="l">Mahina</th><th>Bikri ₹</th><th>Paisa ₹</th><th>Kaat ₹</th><th>Us mahine ka farak</th><th>Chalta bakaya</th></tr></thead><tbody>' +
      s.M.map(function (m) {
        var b = p.m[m] || { val:0, pay:0, cut:0 };
        var d = b.val - b.pay - b.cut; run += d;
        if (!b.val && !b.pay && !b.cut) return "";
        return '<tr><td class="l">' + ml(m) + '</td><td>' + nf(b.val) + '</td><td>' + nf(b.pay) + '</td><td>' + nf(b.cut) + '</td>' +
          '<td>' + nf(Math.abs(d)) + PKS.dcTag(d) + '</td><td><b>' + nf(Math.abs(run)) + '</b>' + PKS.dcTag(run) + '</td></tr>';
      }).join("") +
      '</tbody><tfoot><tr><td class="l">Jod</td><td>' + nf(t.val) + '</td><td>' + nf(t.pay) + '</td><td>' + nf(t.cut) + '</td>' +
      '<td></td><td>' + nf(Math.abs(bak)) + PKS.dcTag(bak) + '</td></tr></tfoot></table></div>');

    if (p.names.length > 1) {
      h.push('<div class="pks-sec"><h4>Jo naam jode gaye</h4><div style="font-size:11.5px;color:var(--pks-mut);line-height:1.7">' +
        p.names.map(E).join("<br>") + '<br><b style="color:var(--pks-text)">saaf naam: ' + E(p.c) + '</b></div></div>');
    }

    var af = { party: p.c, a: s.a, b: s.b };
    document.getElementById("pksDBody").innerHTML = panels([
      { label: "Party ka byora", html: h.join("") },
      { label: "Badlaav ka byora", cnt: auditList(af).length, html: auditHtml(af) }
    ]);
    document.getElementById("pksDBody").scrollTop = 0;
  }

  function kpi(k, v) { return '<div class="pks-kpi"><div class="k">' + k + '</div><div class="v">' + v + '</div></div>'; }
  function tbl(title, cols, rows, numIdx, totQ, totV) {
    return '<div class="pks-sec"><h4>' + title + ' <span style="font-weight:400;color:var(--pks-mut)">· ' + rows.length + ' line</span></h4>' +
      '<table class="pks-d"><thead><tr>' + cols.map(function (c, i) { return '<th class="' + (i < 3 ? "l" : "") + '">' + c + '</th>'; }).join("") + '</tr></thead><tbody>' +
      (rows.length ? rows.map(function (r) {
        return '<tr>' + r.map(function (c, i) { return '<td class="' + (i < 3 ? "l" : "") + '">' + c + '</td>'; }).join("") + '</tr>';
      }).join("") : '<tr><td colspan="' + cols.length + '" class="l">Is samay me kuch nahi</td></tr>') +
      '</tbody><tfoot><tr><td class="l" colspan="3">Jod</td><td>' + nf(totQ) + '</td><td></td><td>' + nf(totV) + '</td></tr></tfoot></table></div>';
  }

  /* ---------- maal ka byora (item drill-down) ---------- */
  function openItem(item, mon, internal) {
    var IX = PKS.idx(), M = PKSUI.months(), a = mon || M[0], b = mon || M[M.length - 1];
    function mine(raw) { var p = IX.parties[PKS.clean(raw)]; return p && (!!p.internal === !!internal) ? p : null; }
    function inScope(r) { var m = PKS.monOf(r.dt); return r.item === item && m >= a && m <= b && mine(r.party); }

    var invs = (IX.raw.invoices || []).filter(inScope);
    var ords = (IX.raw.orders || []).filter(inScope);
    var by = {};
    invs.forEach(function (r) {
      var p = mine(r.party), k = p.c;
      if (!by[k]) by[k] = { p: p, q: 0, v: 0, oq: 0, last: 0 };
      by[k].q += (+r.qty || 0); by[k].v += (+r.total || 0);
      var m = PKS.monOf(r.dt); if (m > by[k].last) by[k].last = m;
    });
    ords.forEach(function (r) {
      var p = mine(r.party), k = p.c;
      if (!by[k]) by[k] = { p: p, q: 0, v: 0, oq: 0, last: 0 };
      by[k].oq += (+r.qty || 0);
    });
    var list = Object.keys(by).map(function (k) { return by[k]; }).sort(function (x, y) { return y.q - x.q || y.oq - x.oq; });
    var tq = invs.reduce(function (s, r) { return s + (+r.qty || 0); }, 0);
    var tv = invs.reduce(function (s, r) { return s + (+r.total || 0); }, 0);
    var to = ords.reduce(function (s, r) { return s + (+r.qty || 0); }, 0);

    cur.c = null;
    document.getElementById("pksDName").textContent = item;
    document.getElementById("pksDMeta").textContent =
      (internal ? "Apni company ka maal" : "Bahar ki party ka maal") + " · " + list.length + " khareedar";
    document.getElementById("pksDMon").textContent = mon ? "Sirf " + ml(mon) : ml(a) + " se " + ml(b) + " tak";

    var monRows = [];
    for (var m = a; m <= b; m = PKS.monAdd(m, 1)) {
      var q = 0, v = 0, o = 0;
      invs.forEach(function (r) { if (PKS.monOf(r.dt) === m) { q += +r.qty || 0; v += +r.total || 0; } });
      ords.forEach(function (r) { if (PKS.monOf(r.dt) === m) { o += +r.qty || 0; } });
      if (q || o) monRows.push('<tr><td class="l">' + ml(m) + '</td><td>' + nf(o) + '</td><td>' + nf(q) + '</td>' +
        '<td>' + (o ? Math.round(q / o * 100) + "%" : "·") + '</td><td>' + nf(v) + '</td>' +
        '<td>' + (q ? nf(Math.round(v / q)) : "·") + '</td></tr>');
    }

    document.getElementById("pksDBody").innerHTML =
      '<div class="pks-kpis">' + kpi("Bikri", nf(tq) + " Qtl") + kpi("Order", nf(to) + " Qtl") +
      kpi("Order me se nikla", to ? Math.round(tq / to * 100) + "%" : "—") +
      kpi("Aausat rate", tq ? "₹" + nf(Math.round(tv / tq)) : "—") + '</div>' +
      '<div class="pks-sec"><h4>Kis mahine kitna gaya</h4><table class="pks-d"><thead><tr>' +
      '<th class="l">Mahina</th><th>Order Qtl</th><th>Bikri Qtl</th><th>Nikla</th><th>Rakam ₹</th><th>Aausat rate</th>' +
      '</tr></thead><tbody>' + (monRows.join("") || '<tr><td colspan="6" class="l">Kuch nahi gaya</td></tr>') +
      '</tbody><tfoot><tr><td class="l">Jod</td><td>' + nf(to) + '</td><td>' + nf(tq) + '</td>' +
      '<td>' + (to ? Math.round(tq / to * 100) + "%" : "·") + '</td><td>' + nf(tv) + '</td>' +
      '<td>' + (tq ? nf(Math.round(tv / tq)) : "·") + '</td></tr></tfoot></table></div>' +
      '<div class="pks-sec"><h4>Kaun le raha hai ye maal</h4><table class="pks-d"><thead><tr>' +
      '<th class="l">Party</th><th class="l">Broker</th><th class="l">Halat</th><th>Order Qtl</th><th>Bikri Qtl</th>' +
      '<th>Hissa</th><th>Rakam ₹</th><th class="l">Aakhri bill</th></tr></thead><tbody>' +
      (list.length ? list.map(function (x) {
        var st = PKS.statusOf(x.p, M);
        return '<tr><td class="l"><span class="pks-pname" data-open="' + E(x.p.c) + '">' + E(x.p.name) + '</span></td>' +
          '<td class="l">' + E(x.p.broker || "—") + '</td>' +
          '<td class="l"><span class="pks-chip" style="background:' + st.color + '">' + st.label + '</span></td>' +
          '<td>' + nf(x.oq) + '</td><td>' + nf(x.q) + '</td>' +
          '<td>' + (tq ? (x.q / tq * 100).toFixed(1) + "%" : "·") + '</td>' +
          '<td>' + nf(x.v) + '</td><td class="l">' + (x.last ? ml(x.last) : "—") + '</td></tr>';
      }).join("") : '<tr><td colspan="8" class="l">Koi khareedar nahi</td></tr>') +
      '</tbody></table></div>';
    var iaf = { item: item, a: a, b: b };
    document.getElementById("pksDBody").innerHTML = panels([
      { label: "Maal ka byora", html: document.getElementById("pksDBody").innerHTML },
      { label: "Badlaav ka byora", cnt: auditList(iaf).length, html: auditHtml(iaf) }
    ]);
    document.getElementById("pksDBody").scrollTop = 0;
    document.getElementById("pksOv").classList.add("on");
  }

  /* ---------- badlaav ka byora (ERP ka sanshodhan register) ---------- */
  function auditList(f) {
    var D = PKS.idx().raw;
    return (D.audit || []).filter(function (x) {
      if (f.item && x.item !== f.item) return false;
      if (f.party && PKS.clean(x.party) !== f.party) return false;
      var m = PKS.monOf(x.docDt);
      if (f.a && m < f.a) return false;
      if (f.b && m > f.b) return false;
      return true;
    }).sort(function (a, b) { return b.stamp - a.stamp; });
  }
  function auditHtml(f) {
    var list = auditList(f);
    var rows = list.map(function (x) {
      var up = (+x.now) >= (+x.was);
      return '<tr><td class="l">' + E(x.when) + '</td>' +
        '<td class="l">' + E(x.user) + '</td>' +
        '<td class="l">' + E(x.doc) + '<span class="pks-who">' + ds(x.docDt) + '</span></td>' +
        '<td class="l">' + E(x.item || "—") + '</td>' +
        '<td class="l">' + E(x.field) + '</td>' +
        '<td class="aud-old">' + nf(Math.round(x.was)) + '</td>' +
        '<td class="aud-new">' + nf(Math.round(x.now)) + '</td>' +
        '<td class="' + (up ? "aud-up" : "aud-dn") + '">' + (up ? "+" : "−") + nf(Math.abs(Math.round(x.now - x.was))) + '</td>' +
        '<td>' + nf(x.qty || 0) + '</td>' +
        '<td class="l" style="white-space:normal;max-width:230px">' + E(x.reason || "—") + '</td></tr>';
    }).join("");
    return '<div class="pks-sec"><h4>Kya badla, kisne badla, kab badla</h4>' +
      '<table class="pks-d"><thead><tr>' +
      '<th class="l">Kab badla</th><th class="l">Kisne badla</th><th class="l">Kis bill par</th>' +
      '<th class="l">Maal</th><th class="l">Kya badla</th><th>Pehle</th><th>Ab</th><th>Farak</th><th>Qty</th>' +
      '<th class="l">Wajah</th></tr></thead><tbody>' +
      (rows || '<tr><td colspan="10" class="l">Is samay ka koi sanshodhan darj nahi hai</td></tr>') +
      '</tbody></table>' +
      '<div class="pks-aud-note">Ye byora ERP ke sanshodhan register (audit trail) se aata hai. Har sudhaar ke sath ' +
      'tareekh-samay, user ka naam, bill number, purana aankda, naya aankda aur wajah save honi chahiye — tabhi ' +
      'ye tab poora bharta hai.</div></div>';
  }

  /* koi bhi taiyaar byora overlay me dikhane ke liye.
     html string bhi de sakte hain, ya [{k,label,html,cnt}] dekar tab bana sakte hain. */
  function show(title, meta, monText, html) {
    cur.c = null;
    document.getElementById("pksDName").textContent = title;
    document.getElementById("pksDMeta").textContent = meta || "";
    document.getElementById("pksDMon").textContent = monText || "";
    document.getElementById("pksDBody").innerHTML = (html && html.length && typeof html !== "string") ? panels(html) : html;
    document.getElementById("pksDBody").scrollTop = 0;
    document.getElementById("pksOv").classList.add("on");
  }
  function panels(ps) {
    return '<div class="pks-dtabs">' + ps.map(function (p, i) {
      return '<button data-dtab="' + i + '" class="' + (i ? "" : "on") + '">' + E(p.label) +
        (p.cnt ? '<span class="cnt">' + p.cnt + '</span>' : "") + '</button>';
    }).join("") + '</div>' +
    ps.map(function (p, i) {
      return '<div class="pks-dpanel" data-dp="' + i + '"' + (i ? " hidden" : "") + '>' + p.html + '</div>';
    }).join("");
  }
  document.addEventListener("click", function (e) {
    var t = e.target.closest ? e.target.closest("[data-dtab]") : null;
    if (!t) return;
    var i = t.getAttribute("data-dtab");
    [].forEach.call(document.querySelectorAll("#pksDBody .pks-dtabs button"), function (b) {
      b.classList.toggle("on", b.getAttribute("data-dtab") === i);
    });
    [].forEach.call(document.querySelectorAll("#pksDBody .pks-dpanel"), function (p) {
      p.hidden = (p.getAttribute("data-dp") !== i);
    });
    document.getElementById("pksDBody").scrollTop = 0;
  });

  function close() { document.getElementById("pksOv").classList.remove("on"); }
  document.getElementById("pksDClose").addEventListener("click", close);
  document.getElementById("pksOv").addEventListener("click", function (e) { if (e.target.id === "pksOv") close(); });

  return { open: open, openItem: openItem, show: show, auditHtml: auditHtml, auditList: auditList,
           close: close, setMode: setMode };
})();
});
