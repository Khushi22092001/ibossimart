/* Progressive enhancement only: every number is a native, checksummed APEX link. */
(function () {
  'use strict';
  const svgNS='http://www.w3.org/2000/svg';
  function svgNode(name,attrs,text){const node=document.createElementNS(svgNS,name);for(const [key,value] of Object.entries(attrs||{}))node.setAttribute(key,String(value));if(text!==undefined)node.textContent=text;return node;}
  function miniIcons(){
    const paths={billing:'M3 3v18h18M6 15l5-5 4 3 6-8m-5 0h5v5',collection:'M12 3v14m-5-5 5 5 5-5M4 17v4h16v-4',payment:'M12 17V3m-5 5 5-5 5 5M4 17v4h16v-4',output:'M3 21V10l6 3V7l6 4V3h4l2 18H3M7 17h1m4 0h1m4 0h1',grn:'M3 7l9-4 9 4-9 4-9-4m0 0v10l9 4 9-4V7m-9 4v10',issue:'M3 7l9-4 9 4-9 4-9-4m0 0v10l9 4 9-4V7m-9 4v10',dispatch:'M3 5h11v13H3V5m11 5h4l3 4v4h-7M5 18a2 2 0 1 0 4 0m7 0a2 2 0 1 0 4 0',gate_in:'M13 3h7v18h-7M3 12h12m-4-4 4 4-4 4',gate_out:'M13 3h7v18h-7M15 12H3m4-4-4 4 4 4',transfer:'M3 7h18m-4-4 4 4-4 4M21 17H3m4-4-4 4 4 4',attendance:'M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M2 21v-3a7 7 0 0 1 14 0v3m1-16a4 4 0 0 1 0 8m2 3a5 5 0 0 1 3 5',overtime:'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18m0 4v6l4 2',service:'M4 7h16v14H4V7m4 0V3h8v4M4 12h16m-10 0v3h4v-3',breakdown:'m3 21 8-8m4-10a6 6 0 0 0-4 10 6 6 0 0 0 10-4l-4 3-4-4 2-5'};
    paths.issue_value=paths.issue;
    document.querySelectorAll('.ec-mini-wrap').forEach(card=>{const key=[...card.classList].find(c=>c.startsWith('ec-mini-')&&c!=='ec-mini-wrap')?.slice(8);const svg=card.querySelector('.ec-mini-icon svg');if(svg&&paths[key])svg.replaceChildren(svgNode('path',{d:paths[key],'stroke-linecap':'round','stroke-linejoin':'round'}));});
  }
  function chartFrame(table,svg){
    const surface=document.createElement('div');surface.className='ec-chart-surface';surface.append(svg);
    const details=document.createElement('details');details.className='ec-chart-values';const summary=document.createElement('summary');summary.textContent='View chart values and record links';details.append(summary);
    const note=table.querySelector('.ec-panel-note')?.cloneNode(true);
    table.before(surface,details);details.append(table);if(note)surface.after(note);
  }
  function trendChart(){
    const table=document.querySelector('.ec-trend-panel .t-Report-report');if(!table||table.dataset.chartReady)return;
    const rows=[...table.querySelectorAll('.ec-trend-point')];if(!rows.length)return;
    const palette={BILLING:['Goods billing','#3479ce'],PURCHASE_BILL:['Purchase bills','#21a39a']};
    const series=Object.keys(palette).map(key=>({key,label:palette[key][0],color:palette[key][1],points:rows.map(row=>{const a=row.querySelector('[data-series="'+key+'"]');return a?{day:row.dataset.day,value:Number(a.dataset.value)/100000,url:a.getAttribute('href'),text:a.textContent}:null;})})).filter(s=>s.points.every(p=>p&&Number.isFinite(p.value)));
    if(!series.length)return;
    const values=series.flatMap(s=>s.points.map(p=>p.value));let low=Math.min(0,...values),high=Math.max(0,...values);if(low===high)high=1;
    const power=10**Math.floor(Math.log10(high-low)),step=Math.ceil((high-low)/(4*power))*power;low=Math.floor(low/step)*step;high=Math.ceil(high/step)*step;
    const X=i=>66+i*86,Y=v=>270-(v-low)/(high-low)*220;
    const svg=svgNode('svg',{viewBox:'0 0 620 350',class:'ec-chart-svg',role:'img','aria-label':'Seven-day goods billing and purchase bills. Values in rupees lakh; each point opens its day’s records.'});
    svg.append(svgNode('text',{x:66,y:23,class:'ec-axis-title'},'Value (₹ lakh)'));
    for(let v=low;v<=high+step/100;v+=step){const y=Y(v);svg.append(svgNode('line',{x1:66,y1:y,x2:582,y2:y,class:'ec-chart-grid'}),svgNode('text',{x:56,y:y+4,'text-anchor':'end',class:'ec-axis-label'},Number(v.toFixed(2)).toLocaleString('en-IN')));}
    svg.append(svgNode('line',{x1:66,y1:Y(0),x2:582,y2:Y(0),class:'ec-chart-axis'}));
    rows.forEach((r,i)=>svg.append(svgNode('text',{x:X(i),y:292,'text-anchor':'middle',class:'ec-axis-label'},r.dataset.day)));
    series.forEach((s,index)=>{
      const points=s.points.map((p,i)=>X(i)+','+Y(p.value)).join(' ');
      svg.append(svgNode('polygon',{points:X(0)+','+Y(0)+' '+points+' '+X(6)+','+Y(0),fill:s.color,opacity:'.07'}),svgNode('polyline',{points,fill:'none',stroke:s.color,'stroke-width':3}));
      // A 24px radius covered neighbouring series points and could navigate to
      // the wrong measure. Keep a 24px diameter; exact links remain in the table.
      s.points.forEach((p,i)=>{const a=svgNode('a',{href:p.url,'aria-label':p.day+' · '+p.text,tabindex:0});a.append(svgNode('title',{},p.day+' · '+p.text),svgNode('circle',{cx:X(i),cy:Y(p.value),r:12,fill:'transparent',class:'ec-chart-hit'}),svgNode('circle',{cx:X(i),cy:Y(p.value),r:6,fill:'#fff',stroke:s.color,'stroke-width':3}));svg.append(a);});
      svg.append(svgNode('rect',{x:165+index*180,y:321,width:10,height:10,rx:3,fill:s.color}),svgNode('text',{x:181+index*180,y:331,class:'ec-axis-label'},s.label));
    });
    chartFrame(table,svg);table.dataset.chartReady='yes';
  }
  function mixChart(){
    const table=document.querySelector('.ec-mix-panel .t-Report-report');if(!table||table.dataset.chartReady)return;
    const items=[...table.querySelectorAll('.ec-mix-item')].map(a=>({node:a,label:a.querySelector('span')?.textContent||'Activity',value:Number(a.dataset.count),color:a.dataset.color}));if(!items.length||items.some(i=>!Number.isFinite(i.value)||i.value<0))return;
    const total=items.reduce((n,i)=>n+i.value,0),svg=svgNode('svg',{viewBox:'0 0 340 270',class:'ec-donut-svg',role:'img','aria-label':'Business activity mix across permitted source types: '+total+' documents.'});
    const surface=document.createElement('div');surface.className='ec-chart-surface ec-mix-surface';
    const tooltip=document.createElement('div');tooltip.className='ec-mix-tooltip';tooltip.id='ec-mix-tooltip';tooltip.setAttribute('role','tooltip');tooltip.hidden=true;
    const heading=document.createElement('strong'),dot=document.createElement('i'),label=document.createElement('span');heading.append(dot,label);
    const valueRow=document.createElement('div'),valueLabel=document.createElement('span'),value=document.createElement('b');valueLabel.textContent='Value';valueRow.append(valueLabel,value);
    const shareRow=document.createElement('div'),shareLabel=document.createElement('span'),share=document.createElement('b');shareLabel.textContent='Share of total';shareRow.append(shareLabel,share);
    const hint=document.createElement('small');hint.textContent='Click to open supporting records';tooltip.append(heading,valueRow,shareRow,hint);
    function hide(){tooltip.hidden=true;surface.classList.remove('is-inspecting');items.forEach(item=>{item.node.classList.remove('is-active');item.segment?.classList.remove('is-active');});}
    function show(item,event){
      label.textContent=item.label;dot.style.background=item.color;value.textContent=item.value.toLocaleString('en-IN')+' documents';share.textContent=(total?item.value/total*100:0).toLocaleString('en-IN',{maximumFractionDigits:1})+'%';share.style.color=item.color;
      tooltip.hidden=false;surface.classList.add('is-inspecting');items.forEach(other=>{other.node.classList.toggle('is-active',other===item);other.segment?.classList.toggle('is-active',other===item);});
      const bounds=surface.getBoundingClientRect(),box=tooltip.getBoundingClientRect();
      const hasPointer=event&&Number.isFinite(event.clientX)&&event.type.startsWith('pointer');
      const x=hasPointer?event.clientX-bounds.left+16:(bounds.width-box.width)/2,y=hasPointer?event.clientY-bounds.top-box.height-14:(bounds.height-box.height)/2;
      tooltip.style.left=Math.max(8,Math.min(x,bounds.width-box.width-8))+'px';tooltip.style.top=Math.max(8,Math.min(y,bounds.height-box.height-8))+'px';
    }
    function connect(node,item){
      node.setAttribute('aria-describedby',tooltip.id);
      node.addEventListener('pointerenter',event=>show(item,event));node.addEventListener('pointermove',event=>show(item,event));node.addEventListener('pointerleave',hide);
      node.addEventListener('focus',event=>show(item,event));node.addEventListener('blur',hide);
      if(node.namespaceURI===svgNS)node.addEventListener('click',event=>{event.preventDefault();window.location.assign(node.getAttribute('href'));});
      node.addEventListener('keydown',event=>{if(event.key==='Escape')hide();if(event.key==='Enter'&&node.namespaceURI===svgNS){event.preventDefault();window.location.assign(node.getAttribute('href'));}});
    }
    svg.append(svgNode('circle',{cx:170,cy:130,r:86,fill:'none',stroke:'#eef0f7','stroke-width':37}));let offset=0;
    for(const item of items){connect(item.node,item);if(!item.value)continue;const share=item.value/total*100,a=svgNode('a',{href:item.node.getAttribute('href'),tabindex:0,class:'ec-mix-segment','aria-label':item.label+': '+item.value.toLocaleString('en-IN')+' documents; '+share.toFixed(1)+' percent. Open source register.'});a.append(svgNode('circle',{cx:170,cy:130,r:86,pathLength:100,fill:'none',stroke:item.color,'stroke-width':37,'stroke-dasharray':Math.max(0,share-.25)+' '+(100-Math.max(0,share-.25)),'stroke-dashoffset':-offset,transform:'rotate(-90 170 130)'}));item.segment=a;connect(a,item);svg.append(a);offset+=share;}
    svg.append(svgNode('text',{x:170,y:111,'text-anchor':'middle',class:'ec-donut-label'},'SELECTED TYPES'),svgNode('text',{x:170,y:145,'text-anchor':'middle',class:'ec-donut-total'},total.toLocaleString('en-IN')),svgNode('text',{x:170,y:169,'text-anchor':'middle',class:'ec-donut-label'},'documents'));
    surface.append(svg,tooltip);table.before(surface);table.dataset.chartReady='yes';
  }
  function partySparklines(){
    document.querySelectorAll('.ec-sparkline[data-ec-values]').forEach(host=>{
      if(host.dataset.ready)return;
      const values=host.dataset.ecValues.split(',').map(Number);
      if(values.length!==7||values.some(v=>!Number.isFinite(v)))return;
      const start=new Date(host.dataset.ecStart+'T00:00:00Z');
      const labels=values.map((value,index)=>{
        const day=new Date(start.getTime()+index*86400000);
        return day.toLocaleDateString('en-GB',{day:'2-digit',month:'short',timeZone:'UTC'})+': ₹ '+value.toLocaleString('en-IN',{maximumFractionDigits:2})+' lakh';
      });
      const low=Math.min(0,...values),high=Math.max(0,...values),range=high-low||1;
      const X=i=>6+i*11,Y=v=>35-(v-low)/range*28;
      const svg=svgNode('svg',{viewBox:'0 0 78 42',role:'img','aria-label':labels.join('; ')});
      svg.append(svgNode('title',{},labels.join('\n')),svgNode('polyline',{points:values.map((v,i)=>X(i)+','+Y(v)).join(' '),fill:'none',stroke:'currentColor','stroke-width':2,'stroke-linejoin':'round','stroke-linecap':'round'}),svgNode('circle',{cx:X(6),cy:Y(values[6]),r:2.5,fill:'currentColor'}));
      host.title=labels.join('\n');host.replaceChildren(svg);host.dataset.ready='yes';
    });
  }
  function observePartySparklines(root){
    if(root.dataset.sparklineObserverReady)return;
    const observer=new MutationObserver(mutations=>{
      const hasRankingData=mutations.some(mutation=>[...mutation.addedNodes].some(node=>node.nodeType===1&&(node.matches?.('.ec-sparkline[data-ec-values]')||node.querySelector?.('.ec-sparkline[data-ec-values]'))));
      if(hasRankingData)partySparklines();
    });
    observer.observe(root,{childList:true,subtree:true});
    root.dataset.sparklineObserverReady='yes';
  }
  function init() {
    controlDetails();
    if(window.apex){
      const page=document.getElementById('P728_PERIOD')?'728':'729';
      const prefix='P'+page+'_',periodItem=document.getElementById(prefix+'PERIOD');
      const bounds=document.querySelector('[data-ec-from][data-ec-to]');
      if(periodItem&&bounds&&periodItem.value!=='CUSTOM'){
        apex.item(prefix+'FROMDATE').setValue(bounds.dataset.ecFrom,null,true);
        apex.item(prefix+'TODATE').setValue(bounds.dataset.ecTo,null,true);
      }
      for(const key of ['FROMDATE','TODATE']){
        const field=document.getElementById(prefix+key);
        if(field&&periodItem)apex.jQuery(field).on('input.todayDates change.todayDates',()=>{
          apex.item(prefix+'PERIOD').setValue('CUSTOM');
          document.querySelectorAll('.ec-periods button').forEach(button=>button.setAttribute('aria-pressed','false'));
          document.querySelectorAll('.ec-evidence-periods button').forEach(button=>button.setAttribute('aria-pressed','false'));
        });
      }
      // Move only the explanatory text into the footer; all fields stay native.
      const region=document.getElementById('p'+page+'Scope');
      const body=region?.querySelector('.t-Region-body,.t-DrawerRegion-body');
      const note=region?.querySelector('.ec-filter-note');
      const form=body?.querySelector(':scope > .container');
      if(note&&form)form.append(note);
    }
    evidenceControls();
    const root=document.querySelector('.ec-dashboard');
    if(!root)return;
    trendChart();mixChart();miniIcons();partySparklines();
    // Customer and supplier ranking regions use APEX lazy loading. Observe new
    // report rows so their seven daily values become sparklines after arrival.
    observePartySparklines(root);
    document.querySelectorAll('.ec-dashboard .t-Report-report').forEach(table=>table.setAttribute('role','presentation'));
    if(!window.apex)return;
    let dirty=false,submitting=false;
    const scope=document.getElementById('p728Scope');
    const period=document.getElementById('P728_PERIOD');
    let toolbar;
    if(scope&&period&&!document.getElementById('ec-period-toolbar')){
      toolbar=document.createElement('div');toolbar.id='ec-period-toolbar';toolbar.className='ec-toolbar';
      const periods=document.createElement('div');periods.className='ec-periods';periods.setAttribute('role','group');periods.setAttribute('aria-label','Activity period');
      const actions=document.createElement('div');actions.className='ec-toolbar-actions';
      function button(label,fn){const el=document.createElement('button');el.type='button';el.textContent=label;el.addEventListener('click',fn);return el;}
      for(const [value,label] of [['TODAY','Today'],['YESTERDAY','Yesterday'],['WEEK','7 days'],['MTD','MTD']]){
        const el=button(label,()=>{if(submitting)return;apex.item('P728_PERIOD').setValue(value);apex.submit('REFRESH');});
        el.setAttribute('aria-pressed',String(period.value===value));
        if(value==='MTD')el.setAttribute('aria-label','Month to date');
        if(value==='WEEK')el.setAttribute('aria-label','Last 7 days');
        periods.append(el);
      }
      const filters=button('Filters',()=>{
        scope.hidden=!scope.hidden;filters.setAttribute('aria-expanded',String(!scope.hidden));
        if(!scope.hidden)scope.querySelector('select:not([id$="_PERIOD"])')?.focus();
      });
      filters.setAttribute('aria-controls','p728Scope');filters.setAttribute('aria-expanded','false');
      const refresh=button('Refresh data',()=>{if(!submitting)apex.submit('REFRESH');});refresh.className='ec-primary';
      actions.append(filters,refresh);toolbar.append(periods,actions);scope.before(toolbar);
      // Hide native controls only after the enhancement is fully installed.
      // The original form items, LOV dependencies, submit and checksums stay native.
      // A period change submits the page, so always restore the closed state.
      // Only an explicit click on Filters may reveal the scope controls.
      scope.classList.add('ec-enhanced');scope.hidden=true;
      filters.setAttribute('aria-expanded','false');
      scope.addEventListener('keydown',event=>{if(event.key==='Escape'){scope.hidden=true;filters.setAttribute('aria-expanded','false');filters.focus();}});
    }
    const control=document.createElement('label');
    control.className='ec-refresh-control';
    const toggle=document.createElement('input');toggle.type='checkbox';
    try{toggle.checked=sessionStorage.getItem('ec-auto-refresh')==='yes';}catch(_){toggle.checked=false;}
    const text=document.createTextNode('Refresh every 5 minutes');
    const status=document.createElement('span');status.className='ec-refresh-status';status.setAttribute('role','status');
    control.append(toggle,text,status);if(toolbar)toolbar.after(control);else root.after(control);
    function update(){status.textContent=dirty?'Paused: apply your filter changes':document.hidden?'Paused while this tab is hidden':toggle.checked?'Enabled':'Manual refresh';}
    toggle.addEventListener('change',()=>{try{sessionStorage.setItem('ec-auto-refresh',toggle.checked?'yes':'no');}catch(_){}update();});
    document.addEventListener('visibilitychange',update);
    document.querySelectorAll('[id^="P728_"]').forEach(el=>apex.jQuery(el).on('input.todayDirty change.todayDirty',()=>{dirty=true;update();}));
    window.setInterval(()=>{if(toggle.checked&&!dirty&&!submitting&&!document.hidden&&!apex.jQuery('.ui-dialog:visible').length)apex.submit('REFRESH');},300000);
    apex.jQuery(document).on('apexbeforepagesubmit.today',()=>{submitting=true;const busy=document.createElement('div');busy.className='ec-loading';busy.setAttribute('role','status');busy.textContent='Refreshing enterprise evidence…';document.body.append(busy);});
    update();
  }
  function controlDetails(){
    const table=document.querySelector('.ec-controls-panel .t-Report-report');
    if(!table||table.dataset.detailsReady)return;
    const rows=[...table.tBodies[0].rows].filter(row=>row.querySelector('.ec-control-cols,.ec-control-note'));
    const count=rows.filter(row=>row.querySelector('.ec-data-row')).length;
    if(!count)return;
    const details=document.createElement('details');details.className='ec-control-details';
    const summary=document.createElement('summary');summary.textContent='View all '+count+' checks and supporting details';
    const detailTable=document.createElement('table');detailTable.className='t-Report-report';detailTable.setAttribute('role','presentation');
    const body=document.createElement('tbody');body.append(...rows);detailTable.append(body);details.append(summary,detailTable);table.after(details);table.dataset.detailsReady='yes';
  }
  function evidenceControls(){
    const scope=document.getElementById('p729Scope');
    if(!scope||!window.apex?.theme)return;
    const header=document.querySelector('.ec-evidence-overview'),trigger=header?.querySelector('[data-evidence-filters]');
    if(trigger){
      scope.classList.add('ec-evidence-enhanced');
      trigger.addEventListener('click',()=>apex.theme.openRegion('p729Scope'));
      apex.jQuery(scope).on('dialogopen.todayEvidence',()=>trigger.setAttribute('aria-expanded','true'));
      apex.jQuery(scope).on('dialogclose.todayEvidence',()=>{trigger.setAttribute('aria-expanded','false');trigger.focus();});
      const status=document.createElement('p');status.className='ec-evidence-dirty';status.setAttribute('role','status');header.append(status);
      apex.jQuery(scope).on('input.todayEvidence change.todayEvidence',()=>{status.textContent='Filter changes are not applied yet. Open Filters and select Apply filters.';});
    }
    document.querySelectorAll('[data-evidence-period]').forEach(button=>button.addEventListener('click',()=>{
      apex.item('P729_PERIOD').setValue(button.dataset.evidencePeriod);
      // P729_ASOF and P729_WINDOW are checksum-protected drill context. Keep
      // their signed values intact when changing only the activity period.
      apex.submit('REFRESH');
    }));
    document.querySelector('[data-evidence-refresh]')?.addEventListener('click',()=>{
      // A normal submit refreshes the live evidence without altering protected
      // session state in the browser.
      apex.submit('REFRESH');
    });
    if(document.querySelector('.a-Notification--error,.t-Alert--danger'))window.setTimeout(()=>apex.theme.openRegion('p729Scope'),0);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
}());
